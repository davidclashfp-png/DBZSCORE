package com.dbzscore.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var paginaPronta = false
    private var hashPendente: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Serve assets/www em https://appassets.androidplatform.net/assets/www/...
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#08090F"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val req = request ?: return null
                    val uri = req.url ?: return null
                    // Dados da ESPN: busca pelo app (sem CORS) e devolve com o cabeçalho liberado
                    proxyEspn(req)?.let { return it }
                    return loader.shouldInterceptRequest(uri)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                    // Links externos (ex.: YouTube) abrem fora do app
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: ActivityNotFoundException) {
                    }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    paginaPronta = true
                    hashPendente?.let { irPara(it) }
                    hashPendente = null
                }
            }
            webChromeClient = WebChromeClient()

            // Ponte JS -> notificações nativas (AndroidNotify.show(...))
            addJavascriptInterface(NotificationBridge(this@MainActivity), "AndroidNotify")
        }
        setContentView(webView)

        pedirPermissaoDeNotificacao()

        // Abriu o app tocando numa notificação (app estava fechado)
        hashPendente = NotificationBridge.hashDoIntent(intent)

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onStart() {
        super.onStart()
        NotificationBridge.appVisivel = true
    }

    override fun onStop() {
        NotificationBridge.appVisivel = false
        super.onStop()
    }

    // Abriu tocando numa notificação com o app já em execução (launchMode=singleTask)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        NotificationBridge.hashDoIntent(intent)?.let { irPara(it) }
    }

    private val hostsEspn = setOf(
        "site.web.api.espn.com",
        "site.api.espn.com",
        "sports.core.api.espn.com",
        "cdn.espn.com"
    )

    // Transfermarkt (valor de mercado, contrato, agente): só páginas HTML, lidas pelo app.
    private val hostsTransfermarkt = setOf(
        "www.transfermarkt.com.br",
        "www.transfermarkt.com"
    )

    private val userAgentChrome =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    // Evita "Failed to fetch": a página roda em appassets.androidplatform.net e a ESPN
    // (e o Transfermarkt) não liberam CORS. Aqui a requisição sai pelo app e volta com a liberação.
    private fun proxyEspn(req: WebResourceRequest): WebResourceResponse? {
        if (!req.method.equals("GET", ignoreCase = true)) return null
        val uri = req.url
        val ehTransfermarkt = uri.host in hostsTransfermarkt
        if (uri.scheme != "https" || (uri.host !in hostsEspn && !ehTransfermarkt)) return null
        return try {
            val c = (URL(uri.toString()).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 20000
                if (ehTransfermarkt) {
                    // O Transfermarkt recusa clientes sem um User-Agent de navegador comum
                    setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
                    setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.8")
                    setRequestProperty("User-Agent", userAgentChrome)
                } else {
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty(
                        "Accept-Language",
                        req.requestHeaders["Accept-Language"] ?: "pt-BR,pt;q=0.9"
                    )
                    setRequestProperty(
                        "User-Agent",
                        req.requestHeaders["User-Agent"] ?: userAgentChrome
                    )
                }
            }
            val code = c.responseCode
            val stream = (if (code in 200..299) c.inputStream else c.errorStream) ?: return null
            val mime = (c.contentType ?: (if (ehTransfermarkt) "text/html" else "application/json")).substringBefore(";").trim()
            val reason = c.responseMessage?.takeIf { it.isNotBlank() } ?: "OK"
            WebResourceResponse(
                mime, "utf-8", code, reason,
                mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"),
                stream
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun irPara(hash: String) {
        if (!paginaPronta) {
            hashPendente = hash
            return
        }
        // O hash já foi validado por NotificationBridge.hashDoIntent (só letras, números, . _ - /)
        webView.evaluateJavascript("location.hash='$hash'", null)
    }

    private fun pedirPermissaoDeNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
