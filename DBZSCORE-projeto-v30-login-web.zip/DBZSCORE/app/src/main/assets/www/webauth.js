/* ===================================================================================
   DBZSCORE · Volta do login com Google pelo navegador (site / iPhone)
   Fluxo: botão "Entrar com Google" -> Supabase (/auth/v1/authorize) -> Google -> Supabase -> de volta ao site com
   "#access_token=...&refresh_token=..." no endereço. Este arquivo roda ANTES do app.js: guarda esses dados e troca
   o endereço por "#/conta" (o app usa o # para as telas e não entenderia os tokens). Quem transforma isso em
   sessão é o app.js (auWebFinish). No app Android este arquivo não faz nada (o login lá é nativo).
   =================================================================================== */
(function () {
  "use strict";
  try {
    var h = location.hash || "";
    if (h.charAt(1) === "/") return;                       /* rota normal (#/jogo/...), nada a fazer */
    var p = new URLSearchParams(h.replace(/^#/, ""));
    var guardou = false;
    if (p.get("access_token")) {
      localStorage.setItem("dbzscore-auth-pending", JSON.stringify({
        t: p.get("access_token"), r: p.get("refresh_token") || "", e: Number(p.get("expires_in")) || 3600
      }));
      guardou = true;
    } else if (p.get("error") || p.get("error_description")) {
      localStorage.setItem("dbzscore-auth-err", (p.get("error_description") || p.get("error") || "erro").replace(/\+/g, " ").slice(0, 160));
      guardou = true;
    }
    if (guardou) {
      try { history.replaceState(null, "", location.pathname + location.search + "#/conta"); }
      catch (e) { location.hash = "#/conta"; }
    }
  } catch (e) {}
})();
