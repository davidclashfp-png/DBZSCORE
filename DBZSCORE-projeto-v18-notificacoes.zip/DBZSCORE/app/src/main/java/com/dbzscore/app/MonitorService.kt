package com.dbzscore.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Serviço em primeiro plano: consulta a API da ESPN a cada ~25 s (jogo ao vivo) ou ~60 s
 * e avisa gols, cartões, fim do 1º tempo e fim de jogo dos favoritos, mesmo com o app fechado.
 * Com o app aberto ele não notifica (o próprio app mostra o banner).
 */
class MonitorService : Service() {

    private class Estado(
        var golsCasa: Int,
        var golsFora: Int,
        var intervalo: Boolean,
        var fim: Boolean
    ) {
        val vistos = HashSet<String>()
        var base = false
    }

    private val estados = HashMap<String, Estado>()

    /** Últimas linhas "ao vivo" mostradas na notificação fixa (evita atualizar à toa). */
    @Volatile
    private var ultimoServico: List<String> = emptyList()

    @Volatile
    private var rodando = false
    private var thread: Thread? = null
    private lateinit var ponte: NotificationBridge

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ponte = NotificationBridge(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val canal = NotificationChannel(
                CANAL_SERVICO, "Acompanhamento de jogos", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notificacao = montarServico(ultimoServico)
        try {
            ServiceCompat.startForeground(
                this, ID_SERVICO, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } catch (e: Exception) {
            // O Android não permitiu iniciar em primeiro plano agora (ex.: app em segundo plano)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!rodando) {
            rodando = true
            thread = Thread { laco() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        rodando = false
        thread?.interrupt()
        ponte.fechar()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ laço principal

    private fun laco() {
        while (rodando) {
            var espera = 60_000L
            try {
                val cfg = Prefs.ler(this)
                if (!cfg.bg) {
                    stopSelf()
                    return
                }
                if (verificar(cfg)) espera = 25_000L
            } catch (e: Exception) {
                // falha de rede: tenta de novo no próximo ciclo
            }
            try {
                Thread.sleep(espera)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    /** Retorna true se existe jogo ao vivo entre os favoritos (consulta com mais frequência). */
    private fun verificar(cfg: Config): Boolean {
        val ligas = HashSet<String>(cfg.ligas)
        for (t in cfg.times) ligas.add(t.first)

        val formato = SimpleDateFormat("yyyyMMdd", Locale.US)
        formato.timeZone = TimeZone.getTimeZone("America/Sao_Paulo")
        val hoje = formato.format(Date())

        var vivo = false
        var algumOk = false
        val vivos = ArrayList<String>()
        for (liga in ligas) {
            if (!LIGA_OK.matches(liga)) continue
            val raiz = try {
                JSONObject(baixar("$BASE/$liga/scoreboard?dates=$hoje&lang=pt&region=br"))
            } catch (e: Exception) {
                continue
            }
            algumOk = true
            val infoLiga = raiz.optJSONArray("leagues")?.optJSONObject(0)
            var sigla = infoLiga?.optString("abbreviation").orEmpty()
            if (sigla.isEmpty()) sigla = infoLiga?.optString("name").orEmpty()
            if (sigla.isEmpty()) sigla = liga

            val eventos = raiz.optJSONArray("events") ?: continue
            for (i in 0 until eventos.length()) {
                val ev = eventos.optJSONObject(i) ?: continue
                if (processar(ev, liga, sigla, cfg, vivos)) vivo = true
            }
        }
        if (algumOk) atualizarServico(vivos)
        return vivo
    }

    /** Processa um jogo. Retorna true se ele está ao vivo. */
    private fun processar(
        ev: JSONObject, liga: String, sigla: String, cfg: Config, vivos: MutableList<String>
    ): Boolean {
        val id = ev.optString("id")
        if (id.isEmpty()) return false
        val comp = ev.optJSONArray("competitions")?.optJSONObject(0) ?: return false
        val competidores = comp.optJSONArray("competitors") ?: return false

        var casaTmp: JSONObject? = null
        var foraTmp: JSONObject? = null
        for (i in 0 until competidores.length()) {
            val t = competidores.optJSONObject(i) ?: continue
            if (t.optString("homeAway") == "away") foraTmp = t else casaTmp = t
        }
        val casa = casaTmp ?: return false
        val fora = foraTmp ?: return false

        val idCasa = casa.optJSONObject("team")?.optString("id").orEmpty()
        val idFora = fora.optJSONObject("team")?.optString("id").orEmpty()

        val favorito = cfg.ligas.contains(liga) ||
            cfg.times.any { it.first == liga && (it.second == idCasa || it.second == idFora) }
        if (!favorito) return false

        val status = ev.optJSONObject("status") ?: comp.optJSONObject("status")
        val tipo = status?.optJSONObject("type")
        val situacao = tipo?.optString("state").orEmpty()          // pre | in | post
        val nome = tipo?.optString("name").orEmpty()
        val encerrado = situacao == "post" || tipo?.optBoolean("completed") == true
        val aoVivo = situacao == "in"

        val gc = casa.optString("score").toIntOrNull() ?: 0
        val gf = fora.optString("score").toIntOrNull() ?: 0
        val placar = "${nomeCurto(casa)} $gc\u2013$gf ${nomeCurto(fora)}"
        val relogio = if (nome == "STATUS_HALFTIME") "Intervalo" else status?.optString("displayClock").orEmpty()

        val primeira = estados[id] == null
        val st = estados.getOrPut(id) { Estado(gc, gf, nome == "STATUS_HALFTIME", encerrado) }

        if (!primeira) {
            if (!st.intervalo && nome == "STATUS_HALFTIME") {
                st.intervalo = true
                avisar(cfg, "ht", "FIM DO 1º TEMPO", placar, "", sigla, "", liga, id)
            }
            if (!st.fim && encerrado) {
                st.fim = true
                avisar(cfg, "ft", "FIM DE JOGO", placar, "", sigla, "", liga, id)
            }
            if (gc + gf > st.golsCasa + st.golsFora) {
                val marcou = if (gc > st.golsCasa) casa else fora
                val lance = ultimoGol(liga, id)
                val tipoLance = lance?.optJSONObject("type")?.optString("type").orEmpty()
                val contra = lance?.optBoolean("ownGoal") == true || tipoLance.contains("own-goal")
                val penalti = lance?.optBoolean("penaltyKick") == true || tipoLance.contains("penalty")
                val detalhe = if (lance != null) jogadorEMinuto(lance) else ""
                when {
                    contra -> avisar(cfg, "goal", "GOL CONTRA", placar, detalhe, sigla, logo(marcou), liga, id)
                    penalti -> avisar(cfg, "penalty", "PÊNALTI \u00b7 GOL!", placar, detalhe, sigla, logo(marcou), liga, id)
                    else -> avisar(cfg, "goal", "GOL!", placar, detalhe, sigla, logo(marcou), liga, id)
                }
            }
        }
        st.golsCasa = gc
        st.golsFora = gf

        if (aoVivo) vivos.add(if (relogio.isEmpty()) placar else "$placar \u00b7 $relogio")
        if (aoVivo) cartoes(cfg, st, liga, id, placar, sigla, casa, fora, idCasa)
        return aoVivo
    }

    // ------------------------------------------------------------------ detalhes do jogo (summary)

    private fun resumo(liga: String, id: String): JSONObject? = try {
        JSONObject(baixar("$BASE/$liga/summary?event=$id"))
    } catch (e: Exception) {
        null
    }

    private fun jogadorEMinuto(ke: JSONObject): String {
        val jogador = ke.optJSONArray("participants")?.optJSONObject(0)
            ?.optJSONObject("athlete")?.optString("displayName").orEmpty()
        val minuto = ke.optJSONObject("clock")?.optString("displayValue").orEmpty()
        return "$jogador $minuto".trim()
    }

    /** Lance do gol mais recente (para jogador, minuto, pênalti ou gol contra), ou null se o resumo ainda não tem. */
    private fun ultimoGol(liga: String, id: String): JSONObject? {
        val chaves = resumo(liga, id)?.optJSONArray("keyEvents") ?: return null
        var achado: JSONObject? = null
        for (i in 0 until chaves.length()) {
            val ke = chaves.optJSONObject(i) ?: continue
            if (!ke.optBoolean("scoringPlay")) continue
            if (jogadorEMinuto(ke).isNotEmpty()) achado = ke
        }
        return achado
    }

    /** Cartões amarelos/vermelhos novos. Na primeira leitura só registra os que já existem. */
    private fun cartoes(
        cfg: Config, st: Estado, liga: String, id: String, placar: String, sigla: String,
        casa: JSONObject, fora: JSONObject, idCasa: String
    ) {
        val chaves = resumo(liga, id)?.optJSONArray("keyEvents") ?: return
        for (i in 0 until chaves.length()) {
            val ke = chaves.optJSONObject(i) ?: continue
            val kid = ke.optString("id")
            if (kid.isEmpty() || !st.vistos.add(kid)) continue
            if (!st.base) continue

            val tipo = ke.optJSONObject("type")?.optString("type").orEmpty()
            val vermelho = ke.optBoolean("redCard") || tipo == "red-card" || tipo == "yellow-red-card"
            val amarelo = !vermelho && (ke.optBoolean("yellowCard") || tipo == "yellow-card")
            if (!vermelho && !amarelo) continue

            val quem = jogadorEMinuto(ke)
            val idTime = ke.optJSONObject("team")?.optString("id").orEmpty()
            val avatar = if (idTime == idCasa) logo(casa) else logo(fora)
            avisar(
                cfg,
                if (vermelho) "red" else "yellow",
                if (vermelho) "CARTÃO VERMELHO" else "CARTÃO AMARELO",
                placar, quem, sigla, avatar, liga, id
            )
        }
        st.base = true
    }

    // ------------------------------------------------------------------ utilidades

    private fun avisar(
        cfg: Config, tipo: String, titulo: String, placar: String, detalhe: String,
        sigla: String, avatar: String, liga: String, id: String
    ) {
        if (cfg.desligados.contains(tipo)) return
        if (NotificationBridge.appVisivel) return      // app aberto: o banner da própria tela já avisa
        ponte.notificar(tipo, titulo, placar, detalhe, sigla, avatar, liga, id)
    }

    // ------------------------------------------------------------------ notificação fixa do serviço

    /** Notificação fixa: discreta quando não há jogo; com jogo ao vivo mostra placar e minuto. */
    private fun montarServico(linhas: List<String>): Notification {
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val titulo = when (linhas.size) {
            0 -> "DBZSCORE"
            1 -> "1 jogo ao vivo"
            else -> "${linhas.size} jogos ao vivo"
        }
        val texto = if (linhas.isEmpty()) "Acompanhando seus jogos favoritos" else linhas[0]
        val b = NotificationCompat.Builder(this, CANAL_SERVICO)
            .setSmallIcon(R.drawable.ic_stat_dbz)
            .setColor(NotificationBridge.COR_MARCA)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(abrir)
        if (linhas.size > 1) {
            val estilo = NotificationCompat.InboxStyle()
            for (l in linhas.take(6)) estilo.addLine(l)
            b.setStyle(estilo)
        }
        return b.build()
    }

    private fun atualizarServico(vivos: List<String>) {
        if (!rodando || vivos == ultimoServico) return
        ultimoServico = ArrayList(vivos)
        try {
            getSystemService(NotificationManager::class.java).notify(ID_SERVICO, montarServico(ultimoServico))
        } catch (e: Exception) {
        }
    }

    private fun nomeCurto(competidor: JSONObject): String {
        val time = competidor.optJSONObject("team") ?: return "Time"
        for (chave in arrayOf("shortDisplayName", "abbreviation", "displayName", "name")) {
            val v = time.optString(chave)
            if (v.isNotEmpty()) return v
        }
        return "Time"
    }

    private fun logo(competidor: JSONObject): String =
        competidor.optJSONObject("team")?.optString("logo").orEmpty().replace("http://", "https://")

    private fun baixar(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    companion object {
        private const val BASE = "https://site.web.api.espn.com/apis/site/v2/sports/soccer"
        private const val CANAL_SERVICO = "monitor"
        private const val ID_SERVICO = 4242
        private val LIGA_OK = Regex("^[A-Za-z0-9][A-Za-z0-9._-]*$")
    }
}
