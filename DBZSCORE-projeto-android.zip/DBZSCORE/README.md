# DBZSCORE (projeto Android)

## Opção A: gerar o APK na nuvem (sem instalar nada)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow** (ele também roda a cada push).
3. Quando terminar (uns 3 a 6 min), abra a execução e baixe **DBZSCORE-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`, já assinado com a chave de debug e instalável.

## Opção B: Android Studio
1. File > Open e escolha a pasta `DBZSCORE`; aguarde o Gradle Sync (não use `./gradlew`).
2. Build > Build Bundle(s) / APK(s) > Build APK(s). O arquivo sai em `app/build/outputs/apk/debug/`.

## Depois de instalar
- Permita as notificações (Android 13+) e toque em "▶ Testar" nas configurações de alertas.
- Se o Android recusar a instalação por assinatura diferente, desinstale a versão antiga antes (os favoritos serão perdidos).

## O que mudou em relação ao APK original
- `NotificationBridge.kt`: notificações no estilo conversa (MessagingStyle); cada partida é uma conversa.
- `MainActivity.kt`: registra a ponte `AndroidNotify`, pede `POST_NOTIFICATIONS` e abre a partida ao tocar na notificação.
- `assets/www/app.js`: `fxNative` envia os alertas (gol, cartão, intervalo, fim) e o botão "Testar" para a notificação nativa.
- `AndroidManifest.xml`: permissão `POST_NOTIFICATIONS`.
