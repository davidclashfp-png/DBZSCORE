package com.dbzscore.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var paginaPronta = false
    private var hashPendente: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Serve assets/www em https://appassets.androidplatform.net/assets/www/...
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#08090F"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    return loader.shouldInterceptRequest(uri)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                    // Links externos (ex.: YouTube) abrem fora do app
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: ActivityNotFoundException) {
                    }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    paginaPronta = true
                    hashPendente?.let { irPara(it) }
                    hashPendente = null
                }
            }
            webChromeClient = WebChromeClient()

            // Ponte JS -> notificações nativas (AndroidNotify.show(...))
            addJavascriptInterface(NotificationBridge(this@MainActivity), "AndroidNotify")
        }
        setContentView(webView)

        pedirPermissaoDeNotificacao()

        // Abriu o app tocando numa notificação (app estava fechado)
        hashPendente = NotificationBridge.hashDoIntent(intent)

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    // Abriu tocando numa notificação com o app já em execução (launchMode=singleTask)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        NotificationBridge.hashDoIntent(intent)?.let { irPara(it) }
    }

    private fun irPara(hash: String) {
        if (!paginaPronta) {
            hashPendente = hash
            return
        }
        // O hash já foi validado por NotificationBridge.hashDoIntent (só letras, números, . _ - /)
        webView.evaluateJavascript("location.hash='$hash'", null)
    }

    private fun pedirPermissaoDeNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
