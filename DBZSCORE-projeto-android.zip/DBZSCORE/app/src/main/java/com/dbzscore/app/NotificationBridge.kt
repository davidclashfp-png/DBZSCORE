package com.dbzscore.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.net.URL
import java.util.concurrent.Executors

/**
 * Ponte JS -> Android. No JS: AndroidNotify.show(titulo, texto, urlAvatar, slug, matchId)
 * Cada partida vira uma "conversa": gols seguintes entram na mesma notificação.
 */
class NotificationBridge(context: Context) {

    private val app = context.applicationContext
    private val io = Executors.newSingleThreadExecutor()

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            val canal = NotificationChannel(CANAL, "Alertas de jogos", NotificationManager.IMPORTANCE_HIGH)
            app.getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
        }
    }

    @JavascriptInterface
    fun show(titulo: String, texto: String, avatarUrl: String?, slug: String?, matchId: String?) {
        io.execute {
            try {
                publicar(titulo, texto, avatarUrl, slug.orEmpty(), matchId.orEmpty())
            } catch (e: Exception) {
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun publicar(titulo: String, texto: String, avatarUrl: String?, slug: String, matchId: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val chave = "jogo_" + matchId.ifEmpty { "geral" }
        val avatar = avatarUrl?.takeIf { it.startsWith("https://") }?.let { baixar(it) }

        // Remetente = quem "fala" na conversa (ex.: "GOL!"). Usuário = "Você", separado do remetente.
        val remetente = Person.Builder().setName(titulo).setKey(chave)
            .apply { avatar?.let { setIcon(IconCompat.createWithBitmap(it)) } }
            .build()
        val eu = Person.Builder().setName("Você").build()

        publicarAtalho(chave, remetente)

        val id = chave.hashCode()
        val nm = app.getSystemService(NotificationManager::class.java)

        // Reaproveita a conversa já aberta dessa partida (empilha os alertas)
        val existente = nm.activeNotifications.firstOrNull { it.id == id }?.notification
        val estilo = existente?.let {
            NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(it)
        } ?: NotificationCompat.MessagingStyle(eu)
        estilo.addMessage(texto, System.currentTimeMillis(), remetente)

        val notificacao = NotificationCompat.Builder(app, CANAL)
            .setSmallIcon(R.drawable.ic_stat_dbz)
            .setColor(0xFFFF7A00.toInt())
            .setStyle(estilo)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(chave)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(abrirJogo(id, slug, matchId))
            .build()

        NotificationManagerCompat.from(app).notify(id, notificacao)
    }

    // Android 11+ só trata como "conversa" (avatar grande) se houver atalho de longa duração
    private fun publicarAtalho(chave: String, pessoa: Person) {
        val intent = Intent(app, MainActivity::class.java).setAction(Intent.ACTION_VIEW)
        val atalho = ShortcutInfoCompat.Builder(app, chave)
            .setShortLabel(pessoa.name ?: "Jogo")
            .setLongLived(true)
            .setIntent(intent)
            .setPerson(pessoa)
            .apply { pessoa.icon?.let { setIcon(it) } }
            .build()
        ShortcutManagerCompat.pushDynamicShortcut(app, atalho)
    }

    private fun abrirJogo(id: Int, slug: String, matchId: String): PendingIntent {
        val intent = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (slug.isNotEmpty() && matchId.isNotEmpty()) putExtra(EXTRA_HASH, "#/jogo/$slug/$matchId")
        }
        return PendingIntent.getActivity(
            app, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun baixar(url: String): Bitmap? = try {
        URL(url).openStream().use { BitmapFactory.decodeStream(it) }
            ?.let { Bitmap.createScaledBitmap(it, 192, 192, true) }
    } catch (e: Exception) {
        null
    }

    companion object {
        const val CANAL = "partidas"
        const val EXTRA_HASH = "hash"
        private val HASH_OK = Regex("^#/jogo/[A-Za-z0-9._-]+/[A-Za-z0-9_-]+$")

        /** Chame em onCreate/onNewIntent da MainActivity para abrir a partida tocada. */
        fun hashDoIntent(intent: Intent?): String? =
            intent?.getStringExtra(EXTRA_HASH)?.takeIf { HASH_OK.matches(it) }
    }
}
