# DBZSCORE (projeto Android)

## Opção A: gerar o APK na nuvem (sem instalar nada)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow** (ele também roda a cada push).
3. Quando terminar (uns 3 a 6 min), abra a execução e baixe **DBZSCORE-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`, já assinado com a chave de debug e instalável.

## Opção B: Android Studio
1. File > Open e escolha a pasta `DBZSCORE`; aguarde o Gradle Sync (não use `./gradlew`).
2. Build > Build Bundle(s) / APK(s) > Build APK(s). O arquivo sai em `app/build/outputs/apk/debug/`.

## Depois de instalar
- Permita as notificações (Android 13+) e toque em "▶ Testar" nas configurações de alertas.
- Se o Android recusar a instalação por assinatura diferente, desinstale a versão antiga antes (os favoritos serão perdidos).

## O que mudou em relação ao APK original
- `NotificationBridge.kt`: notificações no estilo conversa (MessagingStyle); cada partida é uma conversa.
- `MainActivity.kt`: registra a ponte `AndroidNotify`, pede `POST_NOTIFICATIONS` e abre a partida ao tocar na notificação.
- `assets/www/app.js`: `fxNative` envia os alertas (gol, cartão, intervalo, fim) e o botão "Testar" para a notificação nativa.
- `AndroidManifest.xml`: permissões de notificação e de serviço em primeiro plano, e o `MonitorService`.

## Alertas com o app fechado
O app agora tem um serviço em segundo plano (`MonitorService`) que consulta os jogos favoritos a cada 25 a 60 s e avisa gols, cartões, fim do 1º tempo e fim de jogo, mesmo com o app fechado.
- Aparece uma notificação fixa discreta ("Acompanhando seus jogos favoritos"); é exigência do Android.
- Dá para desligar em **Alertas > Notificações e sons > Alertas com o app fechado**.
- Para o Android não encerrar o serviço, desative a economia de bateria do app (Configurações > Apps > DBZSCORE > Bateria > Sem restrições). Em Samsung, tire o app de "Apps em suspensão".
- Com o app aberto, o serviço não notifica (o banner da própria tela avisa).

## Página do time (nova)
Ao tocar num time (Favoritos, tabela da liga ou tela da partida) abrem as abas:
- **Detalhes**: jogo ao vivo / próximo / último, posição na tabela, forma recente e próximos jogos.
- **Partidas**: alterna entre **Lista** e **Calendário** (casa = claro, fora = escuro; toque no dia para abrir o jogo).
- **Classificações**: tabela da competição com o time destacado, faixas de classificação/rebaixamento e seletor de temporada.
- **Estatísticas**: resumo, ataque, defesa e casa × fora, calculados a partir dos resultados (com filtro por competição).
- **Equipe**: treinador e elenco por posição, com filtros Geral / Idade / Altura.
- **Melhores jogadores**: artilheiros e assistentes do time entre os líderes da competição.

## Correção do "Failed to fetch"
- `MainActivity.kt`: as chamadas à API da ESPN agora saem pelo próprio app (`proxyEspn`) e voltam com o CORS liberado.
- `app.js`: se um servidor falhar, tenta o servidor alternativo; se tudo falhar, mostra mensagem clara com botão "Tentar de novo".

## Busca e página do jogador (nova)
- Ícone de busca no topo: pesquisa times, competições e jogadores, com histórico recente.
- Página do jogador (toque num jogador na busca, no elenco ou nos artilheiros), com favoritar jogador pela estrela.
- Só mudaram `assets/www/app.js` e `assets/www/styles.css`; o código Kotlin e o manifesto continuam iguais.

## Tema claro e escuro (novo, versão 1.2.0)
- Botão de sol/lua no cabeçalho (ao lado da busca) alterna entre o tema escuro e o claro.
- A escolha fica salva no aparelho; o padrão continua sendo o tema escuro.
- Só mudaram `index.html`, `styles.css` e `app.js` (as cores agora são variáveis em `:root` e `:root[data-theme="light"]`).

## Versão para iPhone (site instalável / PWA)
O iPhone não roda APK. Esta versão é o mesmo app como site, que se instala pela tela de início.
- `web/build_site.py` monta o site (copia `assets/www`, junta os ícones e injeta as tags do iPhone).
- `.github/workflows/pages.yml` publica o site no GitHub Pages a cada envio (ou em Actions > Run workflow).
- Ative uma vez em **Settings > Pages > Build and deployment > Source: GitHub Actions**.
- No iPhone: abra o link no **Safari** > Compartilhar > **Adicionar à Tela de Início**.
- Limitação: no iPhone os alertas (banner e som) só funcionam com o app aberto. Notificação com o app fechado exigiria um servidor de push ou um app nativo com conta de desenvolvedor Apple.

## Página de lances renovada (versão 1.3.0)
Na tela da partida, a aba **Lances** foi refeita e ganhou uma aba **Comentário**:
- **Fluxo da partida**: gráfico de pressão de cada time ao longo do jogo, com marcadores de gols e cartões, linha do intervalo e cursor vermelho do minuto atual (ao vivo). Toque ou arraste para ver a pressão de cada minuto.
- **Mapa de lances**: campo com gols, chutes, escanteios, faltas e cartões, com filtros. A bola mostra o último lance e quem o fez; toque num ícone para ver o lance.
- **Linha do tempo**: casa à esquerda, visitante à direita, separada por tempo, com placar a cada gol, assistência, substituições (quem entrou e quem saiu) e filtros (Tudo, Gols, Cartões, Substituições). Toque no jogador para abrir a página dele.
- **Comentário**: lance a lance (principais ou todos), do mais recente ao mais antigo.
- Último lance (gol ou cartão) logo abaixo do placar, link da competição e rodada, e atualização automática a cada 30 s nos jogos ao vivo.
- Limites: o fluxo é uma estimativa calculada pelos lances e as posições no campo são aproximadas (a ESPN não envia coordenadas). Se a fonte não trouxer o comentário de um jogo, o app avisa.
- Só mudaram `assets/www/app.js` e `styles.css`.
