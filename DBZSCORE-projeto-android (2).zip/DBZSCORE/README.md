# DBZSCORE (projeto Android)

## Opção A: gerar o APK na nuvem (sem instalar nada)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow** (ele também roda a cada push).
3. Quando terminar (uns 3 a 6 min), abra a execução e baixe **DBZSCORE-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`, já assinado com a chave de debug e instalável.

## Opção B: Android Studio
1. File > Open e escolha a pasta `DBZSCORE`; aguarde o Gradle Sync (não use `./gradlew`).
2. Build > Build Bundle(s) / APK(s) > Build APK(s). O arquivo sai em `app/build/outputs/apk/debug/`.

## Depois de instalar
- Permita as notificações (Android 13+) e toque em "▶ Testar" nas configurações de alertas.
- Se o Android recusar a instalação por assinatura diferente, desinstale a versão antiga antes (os favoritos serão perdidos).

## O que mudou em relação ao APK original
- `NotificationBridge.kt`: notificações no estilo conversa (MessagingStyle); cada partida é uma conversa.
- `MainActivity.kt`: registra a ponte `AndroidNotify`, pede `POST_NOTIFICATIONS` e abre a partida ao tocar na notificação.
- `assets/www/app.js`: `fxNative` envia os alertas (gol, cartão, intervalo, fim) e o botão "Testar" para a notificação nativa.
- `AndroidManifest.xml`: permissões de notificação e de serviço em primeiro plano, e o `MonitorService`.

## Alertas com o app fechado
O app agora tem um serviço em segundo plano (`MonitorService`) que consulta os jogos favoritos a cada 25 a 60 s e avisa gols, cartões, fim do 1º tempo e fim de jogo, mesmo com o app fechado.
- Aparece uma notificação fixa discreta ("Acompanhando seus jogos favoritos"); é exigência do Android.
- Dá para desligar em **Alertas > Notificações e sons > Alertas com o app fechado**.
- Para o Android não encerrar o serviço, desative a economia de bateria do app (Configurações > Apps > DBZSCORE > Bateria > Sem restrições). Em Samsung, tire o app de "Apps em suspensão".
- Com o app aberto, o serviço não notifica (o banner da própria tela avisa).

## Página do time (nova)
Ao tocar num time (Favoritos, tabela da liga ou tela da partida) abrem as abas:
- **Detalhes**: jogo ao vivo / próximo / último, posição na tabela, forma recente e próximos jogos.
- **Partidas**: alterna entre **Lista** e **Calendário** (casa = claro, fora = escuro; toque no dia para abrir o jogo).
- **Classificações**: tabela da competição com o time destacado, faixas de classificação/rebaixamento e seletor de temporada.
- **Estatísticas**: resumo, ataque, defesa e casa × fora, calculados a partir dos resultados (com filtro por competição).
- **Equipe**: treinador e elenco por posição, com filtros Geral / Idade / Altura.
- **Melhores jogadores**: artilheiros e assistentes do time entre os líderes da competição.

## Correção do "Failed to fetch"
- `MainActivity.kt`: as chamadas à API da ESPN agora saem pelo próprio app (`proxyEspn`) e voltam com o CORS liberado.
- `app.js`: se um servidor falhar, tenta o servidor alternativo; se tudo falhar, mostra mensagem clara com botão "Tentar de novo".
