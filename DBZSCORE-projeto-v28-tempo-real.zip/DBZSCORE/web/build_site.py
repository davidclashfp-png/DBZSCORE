#!/usr/bin/env python3
"""Monta o site do DBZSCORE (instalável no iPhone) a partir do app.

Uso:  python3 web/build_site.py [pasta_de_saida]     (padrão: ./site)

Copia app/src/main/assets/www, junta os ícones e injeta no index.html as
tags que o iPhone precisa para "Adicionar à Tela de Início".
"""
import json
import os
import pathlib
import shutil
import sys

AQUI = pathlib.Path(__file__).resolve().parent
WWW = AQUI.parent / "app" / "src" / "main" / "assets" / "www"
SAIDA = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site")

TAGS = """    <link rel="manifest" href="manifest.webmanifest" />
    <link rel="apple-touch-icon" href="apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-title" content="DBZSCORE" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="format-detection" content="telephone=no" />
    <script src="ios.js" defer></script>
    <style>
      html { -webkit-text-size-adjust: 100%; touch-action: manipulation; }
      body { -webkit-touch-callout: none; overscroll-behavior-y: none; }
      input, textarea { -webkit-user-select: text; user-select: text; }
      /* o login com Google só existe no app Android */
      #autop { display: none !important; }
    </style>
"""

MANIFEST = {
    "name": "DBZSCORE",
    "short_name": "DBZSCORE",
    "description": "Placares de futebol ao vivo, classificação e alertas de gol.",
    "lang": "pt-BR",
    "start_url": "./",
    "scope": "./",
    "display": "standalone",
    "orientation": "portrait",
    "id": "./",
    "background_color": "#09080f",
    "theme_color": "#09080f",
    "icons": [
        {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
    ],
}


def telas_de_abertura() -> str:
    """<link> das imagens de abertura (iPhone e iPad), para não aparecer tela branca ao abrir."""
    idx = AQUI / "splash" / "index.json"
    if not idx.exists():
        return ""
    linhas = []
    for arq, cw, ch, dpr in json.loads(idx.read_text()):
        linhas.append(
            f'    <link rel="apple-touch-startup-image" href="splash/{arq}" '
            f'media="(device-width: {cw}px) and (device-height: {ch}px) and '
            f'(-webkit-device-pixel-ratio: {dpr}) and (orientation: portrait)" />\n'
        )
    return "".join(linhas)


def main() -> None:
    if not (WWW / "index.html").exists():
        sys.exit(f"index.html não encontrado em {WWW}")

    if SAIDA.exists():
        shutil.rmtree(SAIDA)
    shutil.copytree(WWW, SAIDA)

    for icone in (AQUI / "icons").glob("*.png"):
        shutil.copy(icone, SAIDA / icone.name)

    shutil.copy(AQUI / "ios.js", SAIDA / "ios.js")
    if (AQUI / "splash").exists():
        shutil.copytree(AQUI / "splash", SAIDA / "splash", ignore=shutil.ignore_patterns("index.json"))

    # Na versão do site, quem usa são vários aparelhos com a MESMA chave da API-Football
    # (cota de 100/dia compartilhada). Limita as buscas de foto por aparelho. Mude com DBZ_AF_FOTOS_SITE=<n>.
    fotos = os.environ.get("DBZ_AF_FOTOS_SITE", "20")
    with open(SAIDA / "config.js", "a", encoding="utf-8") as f:
        f.write(
            "\n/* versão do site (iPhone): limite de buscas de foto por aparelho */\n"
            f"window.DBZ_AF_FOTOS_POR_DIA = Math.min(Number(window.DBZ_AF_FOTOS_POR_DIA) || 60, {int(fotos)});\n"
        )

    html_path = SAIDA / "index.html"
    html = html_path.read_text(encoding="utf-8")
    if "</head>" not in html:
        sys.exit("index.html sem </head>")
    if "manifest.webmanifest" not in html:
        html = html.replace("</head>", TAGS + telas_de_abertura() + "  </head>", 1)
    html_path.write_text(html, encoding="utf-8")

    (SAIDA / "manifest.webmanifest").write_text(
        json.dumps(MANIFEST, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (SAIDA / ".nojekyll").write_text("")

    total = sum(1 for f in SAIDA.rglob("*") if f.is_file())
    print(f"Site gerado em '{SAIDA}' ({total} arquivos)")


if __name__ == "__main__":
    main()
