/* DBZSCORE no iPhone: só entra na versão do site (web/build_site.py). Não vai para o APK.
   - Mostra um guia curto para instalar na Tela de Início (Safari > Compartilhar > Adicionar à Tela de Início).
   - Se o link foi aberto dentro de outro app (WhatsApp, Instagram...), avisa para abrir no Safari. */
(function () {
  "use strict";
  var ua = navigator.userAgent || "";
  var ios = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  if (!ios) return;
  document.documentElement.classList.add("is-ios");

  var standalone = window.navigator.standalone === true ||
    (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches);
  if (standalone) { document.documentElement.classList.add("is-standalone"); return; }

  var KEY = "dbzscore-ios-hint";
  try { if (localStorage.getItem(KEY) === "1") return; } catch (e) {}

  var lang = (navigator.language || "pt").slice(0, 2).toLowerCase();
  var T = {
    pt: {
      t: "Instale o DBZSCORE no iPhone",
      s: ["Toque em <b>Compartilhar</b> <span class=\"ioi\">↑</span> (barra do Safari)", "Role e toque em <b>Adicionar à Tela de Início</b>", "Toque em <b>Adicionar</b>"],
      w: "Você abriu por dentro de outro app. Toque em <b>⋯</b> ou no ícone da bússola e escolha <b>Abrir no Safari</b>; só lá dá para instalar.",
      ok: "Entendi"
    },
    en: {
      t: "Install DBZSCORE on your iPhone",
      s: ["Tap <b>Share</b> <span class=\"ioi\">↑</span> in Safari", "Scroll and tap <b>Add to Home Screen</b>", "Tap <b>Add</b>"],
      w: "You opened this inside another app. Tap <b>⋯</b> or the compass icon and choose <b>Open in Safari</b>; you can only install from there.",
      ok: "Got it"
    },
    es: {
      t: "Instala DBZSCORE en tu iPhone",
      s: ["Toca <b>Compartir</b> <span class=\"ioi\">↑</span> en Safari", "Desplázate y toca <b>Añadir a pantalla de inicio</b>", "Toca <b>Añadir</b>"],
      w: "Abriste esto dentro de otra app. Toca <b>⋯</b> o la brújula y elige <b>Abrir en Safari</b>; solo allí se puede instalar.",
      ok: "Entendido"
    }
  };
  var L = T[lang] || T.pt;
  var inApp = !/Safari\//.test(ua) || /FBAN|FBAV|Instagram|Line\/|MicroMessenger|GSA\//.test(ua);

  var css = document.createElement("style");
  css.textContent =
    "#ioshint{position:fixed;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));z-index:99999;" +
    "background:#17141f;color:#f3f1f8;border:1px solid rgba(37,201,100,.55);border-radius:14px;padding:14px 16px;" +
    "box-shadow:0 10px 40px rgba(0,0,0,.55);font:500 14px/1.4 -apple-system,system-ui,sans-serif}" +
    "#ioshint h4{margin:0 0 8px;font-size:15px;font-weight:700;color:#25c964}" +
    "#ioshint ol{margin:0 0 12px;padding-left:20px}#ioshint li{margin:3px 0}#ioshint p{margin:0 0 12px}" +
    "#ioshint button{width:100%;height:40px;border:0;border-radius:10px;background:#25c964;color:#062411;font:700 15px -apple-system,system-ui,sans-serif}" +
    "#ioshint .ioi{display:inline-block;padding:0 5px;border:1px solid #8b8798;border-radius:5px;font-size:12px}";
  document.head.appendChild(css);

  function show() {
    var d = document.createElement("div");
    d.id = "ioshint";
    d.setAttribute("role", "dialog");
    d.innerHTML = "<h4>" + L.t + "</h4>" +
      (inApp ? "<p>" + L.w + "</p>" : "<ol><li>" + L.s.join("</li><li>") + "</li></ol>") +
      "<button type=\"button\">" + L.ok + "</button>";
    d.querySelector("button").addEventListener("click", function () {
      try { localStorage.setItem(KEY, "1"); } catch (e) {}
      d.remove();
    });
    document.body.appendChild(d);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { setTimeout(show, 2800); });
  else setTimeout(show, 2800);
})();
