/* Chave da API-Football (fotos dos jogadores e fonte reserva quando a ESPN falha).
   Para trocar a chave: edite o texto entre aspas abaixo e salve. Deixe "" para desligar a API-Football. */
window.DBZ_APIFOOTBALL_KEY = "2463f9b78a0e08dc1ab68b0e541fcaac";

/* Fotos de jogadores pela API-Football: máximo de pedidos por dia gastos só com fotos
   (as imagens em si não gastam cota; cada time novo custa ~2 pedidos e fica guardado no aparelho por 7 a 30 dias).
   Use 0 para voltar a usar só as fotos da ESPN. A chave acima é a mesma da fonte reserva, então o limite diário
   (100 no plano gratuito) é compartilhado; o app sempre guarda 35 pedidos para a fonte reserva.
   Se o seu plano for pago, pode aumentar este número. */
window.DBZ_AF_FOTOS_POR_DIA = 60;
