/* ===================================================================================
   DBZSCORE · Aviso de falta de conexão
   O app só funciona com Wi-Fi ou Dados Móveis. Sem nenhum dos dois, aparece uma tela de aviso por cima de
   tudo; ao voltar a conexão ela some sozinha e a tela atual é recarregada.
   - No Android: a ponte nativa AndroidNet.online() (ConnectivityManager) diz se há Wi-Fi/dados móveis e o
     app avisa mudanças chamando window.dbzNet().
   - No navegador (site): usa navigator.onLine e os eventos online/offline.
   Textos em português do Brasil; o i18n.js traduz (linhas "Sem conexão…" em ROWS).
   =================================================================================== */
(function () {
  "use strict";
  var DELAY = 1200;            /* só avisa se ficar sem rede por mais de 1,2 s (evita piscar ao trocar de rede) */
  var shown = false, timer = null, clearSt = null;

  function hasNative() { try { return !!(window.AndroidNet && typeof window.AndroidNet.online === "function"); } catch (e) { return false; } }
  function isOn() {
    try { if (hasNative()) return !!window.AndroidNet.online(); } catch (e) {}
    return navigator.onLine !== false;
  }

  var ICON = '<svg viewBox="0 0 24 24" width="46" height="46" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<path d="M2 8.8a15 15 0 0 1 4.3-2.7M22 8.8a15 15 0 0 0-8.7-3.7"/><path d="M5 12.6a10 10 0 0 1 3.7-2.2M19 12.6a10 10 0 0 0-3.8-2.3"/>' +
    '<path d="M8.6 16.2a5 5 0 0 1 6.8 0"/><circle cx="12" cy="19.6" r="1" fill="currentColor"/><path d="M3 3l18 18"/></svg>';

  function build() {
    var o = document.createElement("div");
    o.id = "net-ov";
    o.className = "net-ov";
    o.setAttribute("role", "alertdialog");
    o.setAttribute("aria-modal", "true");
    o.setAttribute("aria-labelledby", "net-t");
    o.setAttribute("aria-describedby", "net-d");
    o.innerHTML = '<div class="net-card">' +
      '<div class="net-ic">' + ICON + '</div>' +
      '<h2 class="net-t" id="net-t">Sem conexão</h2>' +
      '<p class="net-d" id="net-d">Conecte-se a uma rede Wi-Fi ou ative os dados móveis para usar o DBZSCORE.</p>' +
      '<button type="button" class="net-btn" data-net="retry">Tentar de novo</button>' +
      (hasNative() ? '<button type="button" class="net-btn ghost" data-net="cfg">Abrir configurações de rede</button>' : "") +
      '<p class="net-st" id="net-st" aria-live="polite"></p>' +
      '</div>';
    return o;
  }

  function show() {
    if (shown || !document.body) return;
    shown = true;
    var o = build();
    document.body.appendChild(o);
    document.documentElement.classList.add("net-lock");
    var b = o.querySelector('[data-net="retry"]');
    if (b) try { b.focus(); } catch (e) {}
  }

  function hide() {
    if (!shown) return;
    shown = false;
    var o = document.getElementById("net-ov");
    if (o) o.remove();
    document.documentElement.classList.remove("net-lock");
    /* voltou a conexão: recarrega a tela atual para buscar os dados de novo */
    try { window.dispatchEvent(new HashChangeEvent("hashchange")); } catch (e) {}
  }

  function check() {
    if (isOn()) {
      if (timer) { clearTimeout(timer); timer = null; }
      hide();
      return;
    }
    if (!shown && !timer) {
      timer = setTimeout(function () { timer = null; if (!isOn()) show(); }, DELAY);
    }
  }

  document.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-net]") : null;
    if (!t) return;
    var act = t.getAttribute("data-net");
    if (act === "cfg") { try { window.AndroidNet.abrirConfig(); } catch (e) {} return; }
    if (act === "retry") {
      if (isOn()) { hide(); return; }
      var st = document.getElementById("net-st");
      if (st) {
        st.textContent = "Ainda sem conexão.";
        clearTimeout(clearSt);
        clearSt = setTimeout(function () { var s = document.getElementById("net-st"); if (s) s.textContent = ""; }, 2500);
      }
    }
  });

  window.dbzNet = check;                                  /* chamado pelo Android quando a rede muda */
  window.addEventListener("online", check);
  window.addEventListener("offline", check);
  document.addEventListener("visibilitychange", check);
  window.addEventListener("focus", check);
  setInterval(check, 3000);                               /* garantia extra, caso algum aviso se perca */
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", check); else check();
})();
