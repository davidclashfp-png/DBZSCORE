package com.dbzscore.app

import android.content.Context
import org.json.JSONObject

/** Configuração que o JS envia via AndroidNotify.sync(...) */
data class Config(
    val bg: Boolean,                          // alertas com o app fechado ligados?
    val ligas: Set<String>,                   // competições favoritas (slug)
    val times: List<Pair<String, String>>,    // times favoritos: (slug da liga, id do time)
    val desligados: Set<String>               // tipos de alerta desativados (goal, ht, ft, yellow, red)
)

object Prefs {
    private const val ARQUIVO = "dbzscore"
    private const val CHAVE = "cfg"

    private val VAZIA = Config(false, emptySet(), emptyList(), emptySet())

    fun salvar(ctx: Context, json: String) {
        ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE).edit().putString(CHAVE, json).apply()
    }

    fun ler(ctx: Context): Config {
        val texto = ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE).getString(CHAVE, null)
            ?: return VAZIA
        return try {
            val o = JSONObject(texto)

            val ligas = HashSet<String>()
            val arrLigas = o.optJSONArray("leagues")
            if (arrLigas != null) {
                for (i in 0 until arrLigas.length()) ligas.add(arrLigas.optString(i))
            }

            val times = ArrayList<Pair<String, String>>()
            val arrTimes = o.optJSONArray("teams")
            if (arrTimes != null) {
                for (i in 0 until arrTimes.length()) {
                    val t = arrTimes.optJSONObject(i) ?: continue
                    times.add(Pair(t.optString("league"), t.optString("id")))
                }
            }

            val desligados = HashSet<String>()
            val kinds = o.optJSONObject("kinds")
            if (kinds != null) {
                val nomes = kinds.keys()
                while (nomes.hasNext()) {
                    val nome = nomes.next()
                    if (kinds.optInt(nome, 1) == 0) desligados.add(nome)
                }
            }

            Config(o.optInt("bg", 1) != 0, ligas, times, desligados)
        } catch (e: Exception) {
            VAZIA
        }
    }
}
