package com.dbzscore.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Diz ao app se o aparelho está com Wi-Fi ou Dados Móveis (o app só funciona com um dos dois).
 *
 * JS -> AndroidNet.online()        true se há Wi-Fi, dados móveis (ou VPN por cima deles) com internet
 * JS -> AndroidNet.abrirConfig()   abre as configurações de rede do aparelho
 * Android -> JS: window.dbzNet()   chamado sempre que a rede muda (rede.js decide se mostra o aviso)
 */
class RedeBridge(private val activity: Activity, private val webView: WebView) {

    private val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var registrado = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { avisar() }
        override fun onLost(network: Network) { avisar() }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { avisar() }
    }

    private fun avisar() {
        webView.post { webView.evaluateJavascript("window.dbzNet&&window.dbzNet()", null) }
    }

    fun iniciar() {
        if (registrado) return
        try {
            cm.registerDefaultNetworkCallback(callback)
            registrado = true
        } catch (e: Exception) {
            // sem o aviso instantâneo; o rede.js continua conferindo a cada 3 s
        }
    }

    fun parar() {
        if (!registrado) return
        try {
            cm.unregisterNetworkCallback(callback)
        } catch (e: Exception) {
        }
        registrado = false
    }

    @JavascriptInterface
    fun online(): Boolean {
        return try {
            val rede = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(rede) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
        } catch (e: Exception) {
            true // se não der para consultar, não bloqueia o app
        }
    }

    @JavascriptInterface
    fun abrirConfig() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            } catch (e: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (e2: Exception) {
                }
            }
        }
    }
}
