package com.dbzscore.app

import android.app.Activity
import android.os.CancellationSignal
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Ponte do login com Google.
 *
 * JS  -> AndroidAuth.signIn("idDaChamada", "nonceBruto")
 * Kotlin abre a janela de contas do Google (Credential Manager) e responde com
 *      window.__auNative("idDaChamada", '{"idToken":"..."}')   ou   '{"error":"..."}'
 * O app envia o idToken ao Supabase, que valida com o Google.
 */
class AuthBridge(private val activity: Activity, private val webView: WebView) {

    @JavascriptInterface
    fun signIn(id: String, rawNonce: String) {
        activity.runOnUiThread {
            try {
                val opcao = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .setNonce(sha256Hex(rawNonce))
                    .build()
                val pedido = GetCredentialRequest.Builder().addCredentialOption(opcao).build()

                CredentialManager.create(activity).getCredentialAsync(
                    activity,
                    pedido,
                    CancellationSignal(),
                    ContextCompat.getMainExecutor(activity),
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val cred = result.credential
                            if (cred is CustomCredential &&
                                cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                            ) {
                                try {
                                    val g = GoogleIdTokenCredential.createFrom(cred.data)
                                    responder(id, JSONObject().put("idToken", g.idToken))
                                } catch (e: Exception) {
                                    responder(id, erro("Resposta do Google invalida"))
                                }
                            } else {
                                responder(id, erro("Tipo de credencial nao suportado"))
                            }
                        }

                        override fun onError(e: GetCredentialException) {
                            val msg = when (e) {
                                is GetCredentialCancellationException -> "cancelado"
                                is NoCredentialException -> "Nenhuma conta Google encontrada no aparelho"
                                else -> "Falha no login (${e.type})"
                            }
                            responder(id, erro(msg))
                        }
                    }
                )
            } catch (e: Exception) {
                responder(id, erro("Falha ao iniciar o login: ${e.javaClass.simpleName}"))
            }
        }
    }

    private fun erro(msg: String) = JSONObject().put("error", msg)

    private fun responder(id: String, dados: JSONObject) {
        val js = "window.__auNative&&window.__auNative(" +
            JSONObject.quote(id) + "," + JSONObject.quote(dados.toString()) + ")"
        activity.runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    private fun sha256Hex(texto: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(texto.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    companion object {
        // ID do cliente "Aplicativo da Web" criado no Google Cloud (nao e segredo)
        private const val WEB_CLIENT_ID =
            "40210375025-9re9c9ratm3c0g3lnbjfjagmmdaf47t3.apps.googleusercontent.com"
    }
}
