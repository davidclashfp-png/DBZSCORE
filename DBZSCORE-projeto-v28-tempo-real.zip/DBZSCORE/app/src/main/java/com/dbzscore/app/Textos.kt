package com.dbzscore.app

import android.content.Context
import java.util.Locale

/**
 * Textos das notificações nativas nos idiomas do app (pt-BR, pt-PT, en, es).
 * O app (JS) grava o idioma escolhido em AndroidNotify.setIdioma(codigo); o serviço em segundo
 * plano lê o mesmo valor, então os avisos com o app fechado saem no idioma certo.
 */
object Textos {
    private const val ARQUIVO = "dbzscore"
    private const val CHAVE = "idioma"
    private val IDIOMAS = listOf("pt-BR", "pt-PT", "en", "es")

    @Volatile
    private var cache: String? = null

    /** Idioma escolhido; se nunca escolheu, segue o do aparelho (pt-BR no caso de dúvida). */
    fun idioma(ctx: Context): String {
        cache?.let { return it }
        val salvo = ctx.applicationContext.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE)
            .getString(CHAVE, null)
        val valor = if (salvo != null && salvo in IDIOMAS) salvo else doAparelho()
        cache = valor
        return valor
    }

    fun salvar(ctx: Context, codigo: String) {
        if (codigo !in IDIOMAS) return
        cache = codigo
        ctx.applicationContext.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE)
            .edit().putString(CHAVE, codigo).apply()
    }

    private fun doAparelho(): String {
        val l = Locale.getDefault()
        return when (l.language) {
            "pt" -> if (l.country.isEmpty() || l.country.equals("BR", ignoreCase = true)) "pt-BR" else "pt-PT"
            "es" -> "es"
            "en" -> "en"
            else -> "pt-BR"
        }
    }

    private fun coluna(ctx: Context): Int = IDIOMAS.indexOf(idioma(ctx)).coerceAtLeast(0)

    // chave -> [pt-BR, pt-PT, en, es]
    private val TABELA: Map<String, Array<String>> = mapOf(
        "servico" to arrayOf("Acompanhamento de jogos", "Acompanhamento de jogos", "Match tracking", "Seguimiento de partidos"),
        "grupo" to arrayOf("Alertas de jogos", "Alertas de jogos", "Match alerts", "Alertas de partidos"),
        "c_goal" to arrayOf("Gols", "Golos", "Goals", "Goles"),
        "c_penalty" to arrayOf("Pênaltis", "Penáltis", "Penalties", "Penales"),
        "c_ht" to arrayOf("Intervalo", "Intervalo", "Half-time", "Descanso"),
        "c_yellow" to arrayOf("Cartões amarelos", "Cartões amarelos", "Yellow cards", "Tarjetas amarillas"),
        "c_red" to arrayOf("Cartões vermelhos", "Cartões vermelhos", "Red cards", "Tarjetas rojas"),
        "c_ft" to arrayOf("Fim de jogo", "Fim de jogo", "Full time", "Final del partido"),
        "intervalo" to arrayOf("Intervalo", "Intervalo", "Half-time", "Descanso"),
        "t_ht" to arrayOf("FIM DO 1º TEMPO", "FIM DA 1.ª PARTE", "END OF 1ST HALF", "FIN DEL 1.ER TIEMPO"),
        "t_ft" to arrayOf("FIM DE JOGO", "FIM DE JOGO", "FULL TIME", "FINAL DEL PARTIDO"),
        "t_og" to arrayOf("GOL CONTRA", "AUTOGOLO", "OWN GOAL", "GOL EN CONTRA"),
        "t_pengoal" to arrayOf("PÊNALTI · GOL!", "PENÁLTI · GOLO!", "PENALTY · GOAL!", "PENAL · ¡GOL!"),
        "t_goal" to arrayOf("GOL!", "GOLO!", "GOAL!", "¡GOL!"),
        "t_red" to arrayOf("CARTÃO VERMELHO", "CARTÃO VERMELHO", "RED CARD", "TARJETA ROJA"),
        "t_yellow" to arrayOf("CARTÃO AMARELO", "CARTÃO AMARELO", "YELLOW CARD", "TARJETA AMARILLA"),
        "parado" to arrayOf("Acompanhando seus jogos favoritos", "A acompanhar os seus jogos favoritos", "Following your favorite matches", "Siguiendo tus partidos favoritos"),
        "vivo1" to arrayOf("1 jogo ao vivo", "1 jogo em direto", "1 live match", "1 partido en vivo"),
        "vivoN" to arrayOf("{n} jogos ao vivo", "{n} jogos em direto", "{n} live matches", "{n} partidos en vivo"),
        "novo1" to arrayOf("1 jogo com novidades", "1 jogo com novidades", "1 match with updates", "1 partido con novedades"),
        "novoN" to arrayOf("{n} jogos com novidades", "{n} jogos com novidades", "{n} matches with updates", "{n} partidos con novedades"),
        "voce" to arrayOf("Você", "Eu", "You", "Tú")
    )

    fun t(ctx: Context, chave: String): String =
        TABELA[chave]?.getOrNull(coluna(ctx)) ?: chave

    fun t(ctx: Context, chave: String, n: Int): String = t(ctx, chave).replace("{n}", n.toString())
}
