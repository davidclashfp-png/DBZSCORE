package com.dbzscore.app

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Lê páginas do Transfermarkt usando um WebView escondido (navegador de verdade).
 * O Transfermarkt costuma barrar requisições "cruas" do Java (HttpURLConnection); um WebView
 * se apresenta como o Chrome do aparelho, guarda cookies e resolve desafios de JavaScript.
 *
 * JS -> AndroidTM.fetch("/caminho", "id")   e depois   window.__tfNative(id, html)
 */
class TransfermarktBridge(private val activity: Activity, private val principal: WebView) {

    private val ui = Handler(Looper.getMainLooper())
    private var escondido: WebView? = null
    private val fila = mutableListOf<Pair<String, String>>()
    private var ocupado = false

    // Só caminhos do próprio site (nada de outro domínio) e sem aspas/espaços
    private val caminhoValido = Regex("^/[A-Za-z0-9._~%/?=&+-]{1,300}$")

    @JavascriptInterface
    fun fetch(caminho: String, id: String) {
        val idOk = Regex("^[A-Za-z0-9_-]{1,40}$").matches(id)
        if (!idOk) return
        if (!caminhoValido.matches(caminho)) {
            ui.post { entregar(id, "") }
            return
        }
        ui.post {
            fila.add(caminho to id)
            proximo()
        }
    }

    fun destruir() {
        escondido?.destroy()
        escondido = null
    }

    private fun criar(): WebView {
        val w = WebView(activity)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = true
        w.settings.userAgentString = USER_AGENT
        w.alpha = 0.01f
        w.isFocusable = false
        activity.addContentView(w, FrameLayout.LayoutParams(1, 1))
        return w
    }

    private fun proximo() {
        if (ocupado || fila.isEmpty()) return
        val (caminho, id) = fila.removeAt(0)
        ocupado = true
        val w = escondido ?: criar().also { escondido = it }
        var fim = false
        val limite = arrayOfNulls<Runnable>(1)

        fun terminar(html: String) {
            if (fim) return
            fim = true
            limite[0]?.let { ui.removeCallbacks(it) }
            w.stopLoading()
            w.loadUrl("about:blank")
            ocupado = false
            entregar(id, html)
            proximo()
        }

        fun ler() {
            w.evaluateJavascript(JS_HTML) { v -> terminar(decodificar(v)) }
        }

        fun sondar(vezes: Int) {
            if (fim) return
            w.evaluateJavascript("document.title") { t ->
                val titulo = decodificar(t).lowercase()
                val desafio = titulo.isEmpty() || titulo.contains("just a moment") ||
                    titulo.contains("attention required") || titulo.contains("access denied") ||
                    titulo.contains("verifying")
                if (desafio && vezes < 20) ui.postDelayed({ sondar(vezes + 1) }, 700)
                else ler()
            }
        }

        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (fim || url == null || !url.startsWith("https://www.transfermarkt")) return
                sondar(0)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) terminar("")
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val u = request?.url ?: return true
                return !(u.scheme == "https" && (u.host ?: "").endsWith("transfermarkt.com.br"))
            }
        }

        val relogio = Runnable { terminar("") }
        limite[0] = relogio
        ui.postDelayed(relogio, 25000)
        w.loadUrl(
            "https://www.transfermarkt.com.br$caminho",
            mapOf("Accept-Language" to "pt-BR,pt;q=0.9,en;q=0.8")
        )
    }

    private fun decodificar(v: String?): String {
        if (v == null || v == "null") return ""
        return try {
            (JSONTokener(v).nextValue() as? String) ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    // Deve rodar na thread principal
    private fun entregar(id: String, html: String) {
        val js = "window.__tfNative&&window.__tfNative(" + JSONObject.quote(id) + "," +
            JSONObject.quote(html) + ")"
        principal.evaluateJavascript(js, null)
    }

    companion object {
        const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        // HTML da página sem scripts e estilos (bem menor para trafegar)
        private const val JS_HTML =
            """(function(){return document.documentElement.outerHTML.replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<style[\s\S]*?<\/style>/gi,'')})()"""
    }
}
