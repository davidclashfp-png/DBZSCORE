import UIKit
import WebKit

final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandlerWithReply {

    private let fundo = UIColor(red: 8.0 / 255.0, green: 9.0 / 255.0, blue: 15.0 / 255.0, alpha: 1.0)

    // Mesmos servidores que o app Android deixa passar pelo proxy nativo
    private let hostsEspn: Set<String> = [
        "site.web.api.espn.com",
        "site.api.espn.com",
        "sports.core.api.espn.com",
        "cdn.espn.com"
    ]

    private var webView: WKWebView!

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = fundo

        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(AssetSchemeHandler(), forURLScheme: "dbz")
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        // fetch() dos dados da ESPN passa pelo app (URLSession), sem restrição de CORS
        config.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "espn")
        config.userContentController.addUserScript(
            WKUserScript(source: WebViewController.ponteJS, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        )

        let wv = WKWebView(frame: .zero, configuration: config)
        wv.translatesAutoresizingMaskIntoConstraints = false
        wv.isOpaque = false
        wv.backgroundColor = fundo
        wv.scrollView.backgroundColor = fundo
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        wv.allowsBackForwardNavigationGestures = true
        wv.navigationDelegate = self
        wv.uiDelegate = self
        view.addSubview(wv)

        // Topo abaixo da barra de status; a base vai até a borda (o CSS do app cuida da área do indicador inicial)
        NSLayoutConstraint.activate([
            wv.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            wv.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            wv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        webView = wv
        if let url = URL(string: "dbz://app/index.html") {
            wv.load(URLRequest(url: url))
        }
    }

    // MARK: - Ponte da ESPN

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage,
        replyHandler: @escaping (Any?, String?) -> Void
    ) {
        guard let texto = message.body as? String,
              let url = URL(string: texto),
              url.scheme == "https",
              let host = url.host,
              hostsEspn.contains(host) else {
            replyHandler(nil, "URL não permitida")
            return
        }

        var pedido = URLRequest(url: url, timeoutInterval: 20)
        pedido.setValue("application/json", forHTTPHeaderField: "Accept")
        pedido.setValue("pt-BR,pt;q=0.9", forHTTPHeaderField: "Accept-Language")

        URLSession.shared.dataTask(with: pedido) { dados, resposta, erro in
            DispatchQueue.main.async {
                if let erro = erro {
                    replyHandler(nil, erro.localizedDescription)
                    return
                }
                let status = (resposta as? HTTPURLResponse)?.statusCode ?? 0
                let corpo = dados.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                let resultado: [String: Any] = ["status": status, "body": corpo]
                replyHandler(resultado, nil)
            }
        }.resume()
    }

    private static let ponteJS = #"""
    (function () {
      var h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.espn;
      if (!h) return;
      var original = window.fetch.bind(window);
      var permitido = /^https:\/\/(site\.web\.api|site\.api|sports\.core\.api)\.espn\.com\//;
      window.fetch = function (input, init) {
        var url = typeof input === 'string' ? input : ((input && input.url) || '');
        if (!permitido.test(url)) return original(input, init);
        return h.postMessage(url).then(function (r) {
          var s = r && r.status;
          if (!s) throw new TypeError('Failed to fetch');
          var semCorpo = (s === 204 || s === 205 || s === 304);
          return new Response(semCorpo ? null : r.body, {
            status: s,
            headers: { 'Content-Type': 'application/json' }
          });
        });
      };
    })();
    """#

    // MARK: - Links externos (YouTube, ESPN, etc.) abrem fora do app

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.scheme == "dbz" || url.scheme == "about" {
            decisionHandler(.allow)
            return
        }
        if url.scheme == "https" || url.scheme == "http" {
            UIApplication.shared.open(url)
        }
        decisionHandler(.cancel)
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        if let url = navigationAction.request.url, url.scheme == "https" || url.scheme == "http" {
            UIApplication.shared.open(url)
        }
        return nil
    }
}
