import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let janela = UIWindow(frame: UIScreen.main.bounds)
        janela.backgroundColor = UIColor(red: 8.0 / 255.0, green: 9.0 / 255.0, blue: 15.0 / 255.0, alpha: 1.0)
        janela.rootViewController = WebViewController()
        janela.makeKeyAndVisible()
        window = janela
        return true
    }
}
