import Foundation
import WebKit

/// Entrega os arquivos de www/ (empacotados no app) em dbz://app/...
/// Necessário porque o app usa fetch() para carregar os sons, e isso não funciona em file://.
final class AssetSchemeHandler: NSObject, WKURLSchemeHandler {

    private let raiz: URL = Bundle.main.resourceURL!
        .appendingPathComponent("www", isDirectory: true)
        .standardizedFileURL

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }

        var caminho = url.path
        if caminho.isEmpty || caminho == "/" { caminho = "/index.html" }
        let relativo = String(caminho.dropFirst())

        // Não deixa sair da pasta www (ex.: ../)
        let arquivo = raiz.appendingPathComponent(relativo).standardizedFileURL
        guard arquivo.path.hasPrefix(raiz.path),
              let dados = try? Data(contentsOf: arquivo) else {
            responder(urlSchemeTask, url: url, status: 404, tipo: "text/plain", dados: Data("Not found".utf8))
            return
        }

        responder(urlSchemeTask, url: url, status: 200, tipo: Self.tipoMime(arquivo.pathExtension), dados: dados)
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    private func responder(_ tarefa: WKURLSchemeTask, url: URL, status: Int, tipo: String, dados: Data) {
        let cabecalhos = [
            "Content-Type": tipo,
            "Content-Length": String(dados.count),
            "Cache-Control": "no-cache"
        ]
        if let resposta = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: cabecalhos) {
            tarefa.didReceive(resposta)
        }
        tarefa.didReceive(dados)
        tarefa.didFinish()
    }

    private static func tipoMime(_ extensao: String) -> String {
        switch extensao.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js": return "application/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "svg": return "image/svg+xml"
        case "mp3": return "audio/mpeg"
        case "json", "webmanifest": return "application/json"
        default: return "application/octet-stream"
        }
    }
}
