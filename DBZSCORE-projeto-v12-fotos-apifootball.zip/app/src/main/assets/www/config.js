/* Chave da API-Football (fonte reserva, usada só quando a ESPN falha).
   Para trocar a chave: edite o texto entre aspas abaixo e salve. Deixe "" para desligar a fonte reserva. */
window.DBZ_APIFOOTBALL_KEY = "2463f9b78a0e08dc1ab68b0e541fcaac";

/* Fotos de jogadores pela API-Football: máximo de buscas por dia (as imagens em si não gastam cota).
   Use 0 para desligar. A chave acima é a mesma da fonte reserva, então o limite diário de 100 é compartilhado. */
window.DBZ_AF_FOTOS_POR_DIA = 40;
