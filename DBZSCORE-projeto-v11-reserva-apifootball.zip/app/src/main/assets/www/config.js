/* Chave da API-Football (fonte reserva, usada só quando a ESPN falha).
   Para trocar a chave: edite o texto entre aspas abaixo e salve. Deixe "" para desligar a fonte reserva. */
window.DBZ_APIFOOTBALL_KEY = "2463f9b78a0e08dc1ab68b0e541fcaac";
