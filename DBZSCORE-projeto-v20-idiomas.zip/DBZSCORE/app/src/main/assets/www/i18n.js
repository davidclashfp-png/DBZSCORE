/* ===================================================================================
   DBZSCORE · Idiomas
   O texto-base do app é o português do Brasil. Este arquivo traduz o que aparece na tela:
     - Português (Brasil)    padrão do app, sem troca
     - Português (Portugal)  vocabulário e ortografia de Portugal (equipa, golo, ecrã, "a carregar"…)
     - English
     - Español
   Como funciona: uma tabela de frases (ROWS: [pt-BR, pt-PT, en, es]) e uma lista de modelos para frases
   com números e nomes (PATS). Um observador do DOM traduz tudo o que o app desenha. Se uma frase não estiver
   na tabela, ela continua em português do Brasil (nada quebra).
   Para acrescentar um texto: ponha uma linha em ROWS. Em pt-PT, use 0 quando for igual ao pt-BR.
   Os textos de jogos, times e jogadores vêm da ESPN já no idioma escolhido (parâmetro lang).
   =================================================================================== */
(function () {
  "use strict";
  var KEY = "dbzscore-lang";

  var LANGS = [
    { code: "pt-BR", name: "Português (Brasil)", short: "BR", locale: "pt-BR", espn: "lang=pt&region=br", al: "pt-BR,pt;q=0.9,en;q=0.7", col: 0 },
    { code: "pt-PT", name: "Português (Portugal)", short: "PT", locale: "pt-PT", espn: "lang=pt&region=br", al: "pt-PT,pt;q=0.9,en;q=0.7", col: 1 },
    { code: "en", name: "English", short: "EN", locale: "en-GB", espn: "lang=en&region=us", al: "en-GB,en;q=0.9", col: 2 },
    { code: "es", name: "Español", short: "ES", locale: "es-ES", espn: "lang=es&region=us", al: "es-ES,es;q=0.9,en;q=0.7", col: 3 }
  ];
  var BY = {};
  LANGS.forEach(function (l) { BY[l.code] = l; });

  /* idioma do aparelho (só vale até a pessoa escolher um): "pt" puro e pt-BR = Brasil; pt-PT, pt-AO… = Portugal */
  function detect() {
    var l = "";
    try { l = String((navigator.languages && navigator.languages[0]) || navigator.language || "").toLowerCase(); } catch (e) {}
    if (l.indexOf("pt") === 0) return l === "pt" || l === "pt-br" ? "pt-BR" : "pt-PT";
    if (l.indexOf("es") === 0) return "es";
    if (l.indexOf("en") === 0) return "en";
    return "pt-BR";
  }
  function stored() { try { var s = localStorage.getItem(KEY); return s && BY[s] ? s : ""; } catch (e) { return ""; } }
  var code = stored() || detect();
  var L = BY[code];
  var col = L.col;

  /* fuso horário: no Brasil continua Brasília; nos outros idiomas vale o fuso do aparelho */
  function deviceTz() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) { return ""; } }
  var tz = code === "pt-BR" ? "America/Sao_Paulo" : deviceTz() || (code === "pt-PT" ? "Europe/Lisbon" : "America/Sao_Paulo");

  /* ---------- tabela ---------- */
  var ROWS = [
  ["Copa do Mundo FIFA", "Campeonato do Mundo FIFA", "FIFA World Cup", "Copa Mundial de la FIFA"],
  ["Copa do Mundo", "Campeonato do Mundo", "World Cup", "Copa Mundial"],
  ["Copa do Mundo Feminina", "Campeonato do Mundo Feminino", "Women's World Cup", "Copa Mundial Femenina"],
  ["Copa Feminina", "Mundial Feminino", "Women's WC", "Mundial Femenino"],
  ["Mundial de Clubes FIFA", "Mundial de Clubes FIFA", "FIFA Club World Cup", "Mundial de Clubes de la FIFA"],
  ["Mundial de Clubes", 0, "Club World Cup", "Mundial de Clubes"],
  ["Liga dos Campeões da UEFA", 0, "UEFA Champions League", "Liga de Campeones de la UEFA"],
  ["Champions League", 0, "Champions League", "Champions League"],
  ["Liga Europa", 0, "Europa League", "Europa League"],
  ["Liga Conferência", 0, "Conference League", "Conference League"],
  ["Supercopa da UEFA", "Supertaça Europeia", "UEFA Super Cup", "Supercopa de la UEFA"],
  ["Supercopa UEFA", "Supertaça UEFA", "UEFA Super Cup", "Supercopa UEFA"],
  ["Liga das Nações da UEFA", 0, "UEFA Nations League", "Liga de Naciones de la UEFA"],
  ["Nations League", 0, "Nations League", "Nations League"],
  ["Eurocopa", "Campeonato da Europa", "European Championship", "Eurocopa"],
  ["Copa Libertadores", "Taça Libertadores", "Copa Libertadores", "Copa Libertadores"],
  ["Libertadores", 0, "Libertadores", "Libertadores"],
  ["Copa Sul-Americana", "Taça Sul-Americana", "Copa Sudamericana", "Copa Sudamericana"],
  ["Sul-Americana", 0, "Sudamericana", "Sudamericana"],
  ["Recopa Sul-Americana", 0, "Recopa Sudamericana", "Recopa Sudamericana"],
  ["Copa América", "Taça América", "Copa América", "Copa América"],
  ["Copa dos Campeões da CONCACAF", "Liga dos Campeões da CONCACAF", "CONCACAF Champions Cup", "Copa de Campeones de la CONCACAF"],
  ["Copa Ouro", "Taça Ouro", "Gold Cup", "Copa Oro"],
  ["Liga dos Campeões da CAF", 0, "CAF Champions League", "Liga de Campeones de la CAF"],
  ["CAF Champions", 0, "CAF Champions", "CAF Champions"],
  ["Copa das Nações Africanas", "Taça das Nações Africanas", "Africa Cup of Nations", "Copa Africana de Naciones"],
  ["Liga dos Campeões da AFC", 0, "AFC Champions League", "Liga de Campeones de la AFC"],
  ["AFC Champions", 0, "AFC Champions", "AFC Champions"],
  ["Copa da Ásia", "Taça da Ásia", "Asian Cup", "Copa Asiática"],
  ["Copa da Liga Inglesa", "Taça da Liga Inglesa", "EFL Cup", "Copa de la Liga Inglesa"],
  ["Carabao Cup", 0, "Carabao Cup", "Carabao Cup"],
  ["Copa del Rey", "Taça do Rei", "Copa del Rey", "Copa del Rey"],
  ["Taça de Portugal", 0, "Portuguese Cup", "Copa de Portugal"],
  ["Primeira Liga", 0, "Primeira Liga", "Primeira Liga"],
  ["Bundesliga Austríaca", 0, "Austrian Bundesliga", "Bundesliga Austríaca"],
  ["Bundesliga AUT", 0, "Austrian Bundesliga", "Bundesliga AUT"],
  ["Super Liga Grega", 0, "Greek Super League", "Superliga Griega"],
  ["Super League Grega", 0, "Greek Super League", "Superliga Griega"],
  ["Superliga Dinamarquesa", 0, "Danish Superliga", "Superliga Danesa"],
  ["Premier League Russa", 0, "Russian Premier League", "Premier League Rusa"],
  ["Premier Liga", 0, "Premier Liga", "Premier Liga"],
  ["Liga dos Campeões Feminina", 0, "Women's Champions League", "Liga de Campeones Femenina"],
  ["Brasileirão Série A", 0, "Brasileirão Série A", "Brasileirão Serie A"],
  ["Brasileirão Série B", 0, "Brasileirão Série B", "Brasileirão Serie B"],
  ["Série B", 0, "Série B", "Serie B"],
  ["Copa do Brasil", "Taça do Brasil", "Copa do Brasil", "Copa do Brasil"],
  ["Liga Profissional Argentina", 0, "Argentine Primera División", "Liga Profesional Argentina"],
  ["Liga Argentina", 0, "Argentine League", "Liga Argentina"],
  ["Copa Argentina", "Taça Argentina", "Copa Argentina", "Copa Argentina"],
  ["Campeonato Chileno", 0, "Chilean Primera División", "Campeonato Chileno"],
  ["Liga Colombiana", 0, "Colombian Primera A", "Liga Colombiana"],
  ["Campeonato Uruguaio", 0, "Uruguayan Primera División", "Campeonato Uruguayo"],
  ["Liga Pro Equador", 0, "Ecuadorian Serie A", "Liga Pro Ecuador"],
  ["Primera División Paraguai", 0, "Paraguayan Primera División", "Primera División Paraguay"],
  ["Primera PY", 0, "Paraguay Primera", "Primera PY"],
  ["Liga 1 Peru", 0, "Peruvian Liga 1", "Liga 1 Perú"],
  ["Major League Soccer", 0, "Major League Soccer", "Major League Soccer"],
  ["Copa das Confederações da CAF", 0, "CAF Confederation Cup", "Copa Confederación de la CAF"],
  ["Saudi Pro League", 0, "Saudi Pro League", "Liga Profesional Saudí"],
  ["Indian Super League", 0, "Indian Super League", "Superliga de la India"],
  ["Chinese Super League", 0, "Chinese Super League", "Superliga China"],
  ["Women's Super League", 0, "Women's Super League", "Women's Super League"],
  ["Premier Soccer League", 0, "Premier Soccer League", "Premier Soccer League"],
  ["Mundo", 0, "World", "Mundo"],
  ["Inglaterra", 0, "England", "Inglaterra"],
  ["Espanha", 0, "Spain", "España"],
  ["Itália", 0, "Italy", "Italia"],
  ["Alemanha", 0, "Germany", "Alemania"],
  ["França", 0, "France", "Francia"],
  ["Portugal", 0, "Portugal", "Portugal"],
  ["Países Baixos", 0, "Netherlands", "Países Bajos"],
  ["Bélgica", 0, "Belgium", "Bélgica"],
  ["Escócia", 0, "Scotland", "Escocia"],
  ["Turquia", 0, "Turkey", "Turquía"],
  ["Áustria", 0, "Austria", "Austria"],
  ["Grécia", 0, "Greece", "Grecia"],
  ["Dinamarca", 0, "Denmark", "Dinamarca"],
  ["Rússia", 0, "Russia", "Rusia"],
  ["Brasil", 0, "Brazil", "Brasil"],
  ["Argentina", 0, "Argentina", "Argentina"],
  ["Chile", 0, "Chile", "Chile"],
  ["Colômbia", 0, "Colombia", "Colombia"],
  ["Uruguai", 0, "Uruguay", "Uruguay"],
  ["Equador", 0, "Ecuador", "Ecuador"],
  ["Paraguai", 0, "Paraguay", "Paraguay"],
  ["Peru", 0, "Peru", "Perú"],
  ["Estados Unidos", 0, "United States", "Estados Unidos"],
  ["México", 0, "Mexico", "México"],
  ["África do Sul", 0, "South Africa", "Sudáfrica"],
  ["Arábia Saudita", 0, "Saudi Arabia", "Arabia Saudita"],
  ["Japão", 0, "Japan", "Japón"],
  ["Austrália", 0, "Australia", "Australia"],
  ["Índia", 0, "India", "India"],
  ["China", 0, "China", "China"],
  ["Internacionais", 0, "International", "Internacionales"],
  ["Europa", 0, "Europe", "Europa"],
  ["América do Sul", 0, "South America", "Sudamérica"],
  ["América do Norte e Central", 0, "North & Central America", "Norte y Centroamérica"],
  ["África", 0, "Africa", "África"],
  ["Ásia", 0, "Asia", "Asia"],
  ["Ásia e Oceania", 0, "Asia & Oceania", "Asia y Oceanía"],
  ["América do Norte", 0, "North America", "Norteamérica"],
  ["Oitavas", "Oitavos", "Round of 16", "Octavos"],
  ["Quartas", "Quartos", "Quarter-finals", "Cuartos"],
  ["Semifinais", "Meias-finais", "Semi-finals", "Semifinales"],
  ["Final", 0, "Final", "Final"],
  ["Finais", 0, "Finals", "Finales"],
  ["Eliminatória", 0, "Qualifying round", "Eliminatoria"],
  ["Playoffs", 0, "Playoffs", "Playoffs"],
  ["Ida", "1.ª mão", "1st leg", "Ida"],
  ["Volta", "2.ª mão", "2nd leg", "Vuelta"],
  ["Jogador", 0, "Player", "Jugador"],
  ["Evento", 0, "Event", "Evento"],
  ["Encerrado", "Terminado", "Finished", "Finalizado"],
  ["Jogos", 0, "Matches", "Partidos"],
  ["Ligas", 0, "Leagues", "Ligas"],
  ["Buscar", "Pesquisar", "Search", "Buscar"],
  ["Alertas", 0, "Alerts", "Alertas"],
  ["Favoritos", 0, "Favorites", "Favoritos"],
  ["DBZSCORE — início", 0, "DBZSCORE — home", "DBZSCORE — inicio"],
  ["Buscar jogos", "Pesquisar jogos", "Search matches", "Buscar partidos"],
  ["Buscar time ou competição", "Pesquisar equipa ou competição", "Search team or competition", "Buscar equipo o competición"],
  ["Buscar competição", "Pesquisar competição", "Search competition", "Buscar competición"],
  ["Procurar", "Pesquisar", "Search", "Buscar"],
  ["Dia anterior", 0, "Previous day", "Día anterior"],
  ["Próximo dia", "Dia seguinte", "Next day", "Día siguiente"],
  ["Mês anterior", 0, "Previous month", "Mes anterior"],
  ["Próximo mês", "Mês seguinte", "Next month", "Mes siguiente"],
  ["Todos", 0, "All", "Todos"],
  ["Ao vivo", "Em direto", "Live", "En vivo"],
  ["Melhores momentos", "Resumos", "Highlights", "Mejores momentos"],
  ["Nenhum jogo neste filtro.", 0, "No matches in this filter.", "Ningún partido en este filtro."],
  ["DBZSCORE você vive o jogo", "DBZSCORE vives o jogo", "DBZSCORE live the game", "DBZSCORE vive el juego"],
  ["Rodada em curso", "Jornada em curso", "Matchday in progress", "Jornada en curso"],
  ["Resultados, tabelas e os melhores momentos no YouTube assim que cada jogo termina.", "Resultados, tabelas e os resumos no YouTube assim que cada jogo termina.", "Scores, tables and the best moments on YouTube as soon as each match ends.", "Resultados, tablas y los mejores momentos en YouTube en cuanto termina cada partido."],
  ["Competições", 0, "Competitions", "Competiciones"],
  ["Competição", 0, "Competition", "Competición"],
  ["Ligas do mundo", "Ligas do mundo", "Leagues of the world", "Ligas del mundo"],
  ["Nenhuma competição encontrada.", 0, "No competitions found.", "No se encontró ninguna competición."],
  ["★ Favorita", 0, "★ Favorite", "★ Favorita"],
  ["☆ Favoritar", 0, "☆ Add to favorites", "☆ Añadir a favoritos"],
  ["Favoritar", "Adicionar aos favoritos", "Add to favorites", "Añadir a favoritos"],
  ["▶ YouTube", 0, "▶ YouTube", "▶ YouTube"],
  ["A definir", "Por definir", "TBD", "Por definir"],
  ["Fim", 0, "FT", "Fin"],
  ["Fim (prorrog.)", "Fim (prolong.)", "FT (ET)", "Fin (prórr.)"],
  ["Fim (pênaltis)", "Fim (g. penalidades)", "FT (pens.)", "Fin (penales)"],
  ["Intervalo", 0, "Half-time", "Descanso"],
  ["Adiado", 0, "Postponed", "Aplazado"],
  ["Cancelado", 0, "Cancelled", "Cancelado"],
  ["Abandonado", 0, "Abandoned", "Suspendido"],
  ["Suspenso", 0, "Suspended", "Suspendido"],
  ["Agora", "Agora", "Now", "Ahora"],
  ["agora", 0, "now", "ahora"],
  ["Tabela", "Classificação", "Table", "Tabla"],
  ["Artilheiros", "Melhores marcadores", "Top scorers", "Goleadores"],
  ["Classificação", 0, "Standings", "Clasificación"],
  ["Classificação indisponível.", 0, "Standings not available.", "Clasificación no disponible."],
  ["Sem dados.", 0, "No data.", "Sin datos."],
  ["Sem jogos nesta data.", 0, "No matches on this date.", "Sin partidos en esta fecha."],
  ["Gols", "Golos", "Goals", "Goles"],
  ["Assistências", 0, "Assists", "Asistencias"],
  ["Time", "Equipa", "Team", "Equipo"],
  ["Times", "Equipas", "Teams", "Equipos"],
  ["Jogadores", 0, "Players", "Jugadores"],
  ["th:#", 0, "#", "#"],
  ["th:P", "Pts", "Pts", "Pts"],
  ["th:PTS", "Pts", "Pts", "Pts"],
  ["th:J", 0, "MP", "PJ"],
  ["th:V", 0, "W", "G"],
  ["th:E", 0, "D", "E"],
  ["th:D", 0, "L", "P"],
  ["th:SG", "DG", "GD", "DG"],
  ["th:Gols", "Golos", "Goals", "Goles"],
  ["th:Temporada", 0, "Season", "Temporada"],
  ["Gol", "Golo", "Goal", "Gol"],
  ["GOL!", "GOLO!", "GOAL!", "¡GOL!"],
  ["gol", "golo", "goal", "gol"],
  ["Pênalti", "Penálti", "Penalty", "Penal"],
  ["Cartão amarelo", 0, "Yellow card", "Tarjeta amarilla"],
  ["Cartão vermelho", 0, "Red card", "Tarjeta roja"],
  ["Substituição", "Substituição", "Substitution", "Sustitución"],
  ["Substituições", "Substituições", "Substitutions", "Sustituciones"],
  ["Substituído", 0, "Substituted", "Sustituido"],
  ["Entrou", 0, "Came on", "Entró"],
  ["Chute no alvo", "Remate enquadrado", "Shot on target", "Tiro a puerta"],
  ["Finalização", "Remate", "Shot", "Remate"],
  ["Finalizações", "Remates", "Shots", "Remates"],
  ["Chutes", "Remates", "Shots", "Tiros"],
  ["Cartões", 0, "Cards", "Tarjetas"],
  ["Escanteio", "Canto", "Corner", "Córner"],
  ["Escanteios", "Cantos", "Corners", "Córners"],
  ["Falta", 0, "Foul", "Falta"],
  ["Faltas", 0, "Fouls", "Faltas"],
  ["Impedimento", "Fora de jogo", "Offside", "Fuera de juego"],
  ["Impedimentos", "Foras de jogo", "Offsides", "Fueras de juego"],
  ["Tiro livre", "Livre", "Free kick", "Tiro libre"],
  ["Gol contra", "Autogolo", "Own goal", "Gol en contra"],
  ["Gol de pênalti", "Golo de penálti", "Penalty goal", "Gol de penal"],
  ["Assistência", 0, "Assist", "Asistencia"],
  ["Assistência:", 0, "Assist:", "Asistencia:"],
  ["Fluxo da partida", "Fluxo do jogo", "Match flow", "Flujo del partido"],
  ["Pressão no jogo", "Pressão no jogo", "Pressure in the match", "Presión en el partido"],
  ["Ainda não há lances suficientes para desenhar o fluxo.", "Ainda não há lances suficientes para desenhar o fluxo.", "There are not enough plays yet to draw the flow.", "Aún no hay suficientes jugadas para dibujar el flujo."],
  ["Toque no gráfico para ver um minuto. Estimativa feita a partir dos lances (gols, chutes, escanteios, faltas e cartões), não é um dado oficial.", "Toque no gráfico para ver um minuto. Estimativa feita a partir dos lances (golos, remates, cantos, faltas e cartões), não é um dado oficial.", "Tap the chart to see a minute. Estimate based on the plays (goals, shots, corners, fouls and cards); it is not official data.", "Toca el gráfico para ver un minuto. Estimación a partir de las jugadas (goles, tiros, córners, faltas y tarjetas); no es un dato oficial."],
  ["Nenhum lance deste tipo até agora.", 0, "No plays of this kind so far.", "Ninguna jugada de este tipo hasta ahora."],
  ["Lance", "Lance", "Play", "Jugada"],
  ["Lances", "Lances", "Plays", "Jugadas"],
  ["Lances do jogo", 0, "Match plays", "Jugadas del partido"],
  ["Mapa de lances", 0, "Play map", "Mapa de jugadas"],
  ["Posições aproximadas: a fonte não envia coordenadas, então cada lance é posto na zona típica do seu tipo. Toque num ícone para ver o lance.", 0, "Approximate positions: the source does not send coordinates, so each play is placed in the typical zone for its type. Tap an icon to see the play.", "Posiciones aproximadas: la fuente no envía coordenadas, así que cada jugada se coloca en la zona típica de su tipo. Toca un icono para ver la jugada."],
  ["Nenhum lance neste filtro.", 0, "No plays in this filter.", "Ninguna jugada en este filtro."],
  ["Sem lances ainda.", 0, "No plays yet.", "Aún no hay jugadas."],
  ["sem lances", 0, "no plays", "sin jugadas"],
  ["1º tempo", "1.ª parte", "1st half", "1.er tiempo"],
  ["2º tempo", "2.ª parte", "2nd half", "2.º tiempo"],
  ["Prorrogação", "Prolongamento", "Extra time", "Prórroga"],
  ["Pênaltis", "Grandes penalidades", "Penalties", "Penales"],
  ["O comentário lance a lance ainda não está disponível para esta partida. Veja os lances principais na aba Lances.", "O comentário lance a lance ainda não está disponível para este jogo. Veja os lances principais no separador Lances.", "Play-by-play commentary is not available for this match yet. See the main plays in the Plays tab.", "El comentario jugada a jugada aún no está disponible para este partido. Mira las jugadas principales en la pestaña Jugadas."],
  ["Principais", 0, "Key plays", "Principales"],
  ["Todos os lances", 0, "All plays", "Todas las jugadas"],
  ["Tudo", 0, "All", "Todo"],
  ["⇅ Mais recentes primeiro", 0, "⇅ Newest first", "⇅ Más recientes primero"],
  ["⇅ Ordem do jogo", 0, "⇅ Match order", "⇅ Orden del partido"],
  ["Jogo não encontrado", 0, "Match not found", "Partido no encontrado"],
  ["Jogo não encontrado na fonte reserva", 0, "Match not found in the backup source", "Partido no encontrado en la fuente de respaldo"],
  ["▶ Melhores momentos no YouTube", "▶ Resumo no YouTube", "▶ Highlights on YouTube", "▶ Mejores momentos en YouTube"],
  ["Sem estatísticas.", 0, "No statistics.", "Sin estadísticas."],
  ["Banco", "Suplentes", "Bench", "Banquillo"],
  ["Escalação não disponível.", "Onze inicial não disponível.", "Line-up not available.", "Alineación no disponible."],
  ["Comentário", 0, "Commentary", "Comentario"],
  ["Estatísticas", 0, "Statistics", "Estadísticas"],
  ["Escalação", "Onze inicial", "Line-up", "Alineación"],
  ["Desempenho", 0, "Performance", "Rendimiento"],
  ["Posição", 0, "Position", "Posición"],
  ["Como a nota é calculada", 0, "How the rating is calculated", "Cómo se calcula la nota"],
  ["Nota estimada pelo DBZSCORE: parte de 6,3 e soma gols, assistências, chutes no gol, defesas, faltas, cartões, gols sofridos e o resultado do jogo. Não é a nota oficial de nenhum site.", "Nota estimada pelo DBZSCORE: parte de 6,3 e soma golos, assistências, remates à baliza, defesas, faltas, cartões, golos sofridos e o resultado do jogo. Não é a nota oficial de nenhum site.", "Rating estimated by DBZSCORE: it starts at 6.3 and adds goals, assists, shots on goal, saves, fouls, cards, goals conceded and the match result. It is not the official rating of any website.", "Nota estimada por DBZSCORE: parte de 6,3 y suma goles, asistencias, tiros a puerta, paradas, faltas, tarjetas, goles recibidos y el resultado del partido. No es la nota oficial de ningún sitio."],
  ["Futebol", 0, "Football", "Fútbol"],
  ["Posse de bola", 0, "Possession", "Posesión"],
  ["No alvo", "Enquadrados", "On target", "A puerta"],
  ["Cartões amarelos", 0, "Yellow cards", "Tarjetas amarillas"],
  ["Cartões vermelhos", 0, "Red cards", "Tarjetas rojas"],
  ["Passes certos", "Passes certos", "Accurate passes", "Pases precisos"],
  ["Passes", 0, "Passes", "Pases"],
  ["Precisão de passe", "Precisão de passe", "Pass accuracy", "Precisión de pase"],
  ["Defesas", 0, "Saves", "Paradas"],
  ["Goleiro", "Guarda-redes", "Goalkeeper", "Portero"],
  ["Defensor", "Defesa", "Defender", "Defensa"],
  ["Meio-campista", "Médio", "Midfielder", "Centrocampista"],
  ["Atacante", "Avançado", "Forward", "Delantero"],
  ["Goleiros", "Guarda-redes", "Goalkeepers", "Porteros"],
  ["Defensores", "Defesas", "Defenders", "Defensas"],
  ["Meio-campistas", "Médios", "Midfielders", "Centrocampistas"],
  ["Atacantes", "Avançados", "Forwards", "Delanteros"],
  ["Outros", 0, "Others", "Otros"],
  ["Fonte principal fora do ar. Usando a fonte reserva (API-Football). Alguns dados podem faltar. Toque para fechar.", "Fonte principal indisponível. A usar a fonte de reserva (API-Football). Alguns dados podem faltar. Toque para fechar.", "Main source is offline. Using the backup source (API-Football). Some data may be missing. Tap to close.", "La fuente principal no responde. Usando la fuente de respaldo (API-Football). Pueden faltar algunos datos. Toca para cerrar."],
  ["Fonte reserva indisponível", "Fonte de reserva indisponível", "Backup source unavailable", "Fuente de respaldo no disponible"],
  ["Limite diário da fonte reserva atingido", "Limite diário da fonte de reserva atingido", "Daily limit of the backup source reached", "Se alcanzó el límite diario de la fuente de respaldo"],
  ["Competição sem equivalente na fonte reserva", "Competição sem equivalente na fonte de reserva", "Competition has no equivalent in the backup source", "Competición sin equivalente en la fuente de respaldo"],
  ["Tabela indisponível na fonte reserva", "Tabela indisponível na fonte de reserva", "Table unavailable in the backup source", "Tabla no disponible en la fuente de respaldo"],
  ["Sem equivalente na fonte reserva", "Sem equivalente na fonte de reserva", "No equivalent in the backup source", "Sin equivalente en la fuente de respaldo"],
  ["Sem conexão com os dados. Verifique a internet e tente de novo.", "Sem ligação aos dados. Verifique a internet e tente novamente.", "No connection to the data. Check your internet and try again.", "Sin conexión con los datos. Revisa internet e inténtalo de nuevo."],
  ["Competição inválida", 0, "Invalid competition", "Competición no válida"],
  ["Tentar de novo", "Tentar novamente", "Try again", "Intentar de nuevo"],
  ["Não foi possível montar esta aba.", "Não foi possível montar este separador.", "This tab could not be built.", "No se pudo armar esta pestaña."],
  ["Não foi possível carregar o time.", "Não foi possível carregar a equipa.", "Could not load the team.", "No se pudo cargar el equipo."],
  ["Não foi possível carregar agora.", 0, "Could not load right now.", "No se pudo cargar ahora."],
  ["Carregando…", "A carregar…", "Loading…", "Cargando…"],
  ["· Encerrado", "· Terminado", "· Finished", "· Finalizado"],
  ["Último jogo", 0, "Last match", "Último partido"],
  ["Próximo jogo", 0, "Next match", "Próximo partido"],
  ["Pontos", 0, "Points", "Puntos"],
  ["Saldo", "Diferença", "Goal difference", "Diferencia"],
  ["Forma recente", 0, "Recent form", "Forma reciente"],
  ["O mais recente fica à direita.", 0, "The most recent is on the right.", "El más reciente queda a la derecha."],
  ["Próximos jogos", 0, "Upcoming matches", "Próximos partidos"],
  ["Sem informações deste time por enquanto.", "Sem informações desta equipa por enquanto.", "No information about this team yet.", "Aún no hay información de este equipo."],
  ["Lista", 0, "List", "Lista"],
  ["Calendário", 0, "Calendar", "Calendario"],
  ["dom.", 0, "Sun", "dom."],
  ["seg.", 0, "Mon", "lun."],
  ["ter.", 0, "Tue", "mar."],
  ["qua.", 0, "Wed", "mié."],
  ["qui.", 0, "Thu", "jue."],
  ["sex.", 0, "Fri", "vie."],
  ["sáb.", 0, "Sat", "sáb."],
  ["Casa", 0, "Home", "Local"],
  ["Fora", 0, "Away", "Visitante"],
  ["Casa × Fora", 0, "Home × Away", "Local × Visitante"],
  ["Próximos", 0, "Upcoming", "Próximos"],
  ["Resultados", 0, "Results", "Resultados"],
  ["Sem jogos.", 0, "No matches.", "Sin partidos."],
  ["Todas as competições", 0, "All competitions", "Todas las competiciones"],
  ["Sem jogos encerrados nesta temporada.", "Sem jogos terminados nesta época.", "No finished matches this season.", "Sin partidos finalizados esta temporada."],
  ["Temporada", "Época", "Season", "Temporada"],
  ["Resumo", 0, "Summary", "Resumen"],
  ["Partidas", "Jogos", "Matches", "Partidos"],
  ["Vitórias", 0, "Wins", "Victorias"],
  ["Empates", 0, "Draws", "Empates"],
  ["Derrotas", 0, "Losses", "Derrotas"],
  ["Gols marcados", "Golos marcados", "Goals scored", "Goles a favor"],
  ["Gols sofridos", "Golos sofridos", "Goals conceded", "Goles en contra"],
  ["Saldo de gols", "Diferença de golos", "Goal difference", "Diferencia de goles"],
  ["Aproveitamento", 0, "Points won", "Aprovechamiento"],
  ["Atacando", 0, "Attack", "Ataque"],
  ["Gols por jogo", "Golos por jogo", "Goals per match", "Goles por partido"],
  ["Jogos marcando", "Jogos a marcar", "Matches scoring", "Partidos marcando"],
  ["Jogos sem marcar", 0, "Matches without scoring", "Partidos sin marcar"],
  ["Maior vitória", 0, "Biggest win", "Mayor victoria"],
  ["Defendendo", "A defender", "Defence", "Defensa"],
  ["Gols sofridos por jogo", "Golos sofridos por jogo", "Goals conceded per match", "Goles en contra por partido"],
  ["Jogos sem sofrer gol", "Jogos sem sofrer golos", "Clean sheets", "Partidos sin recibir gol"],
  ["Jogos sofrendo gol", "Jogos a sofrer golos", "Matches conceding", "Partidos recibiendo gol"],
  ["Elenco indisponível.", "Plantel indisponível.", "Squad not available.", "Plantilla no disponible."],
  ["Idade", 0, "Age", "Edad"],
  ["Altura", 0, "Height", "Altura"],
  ["Treinador", 0, "Coach", "Entrenador"],
  ["Estádio:", 0, "Stadium:", "Estadio:"],
  ["Nenhum jogador do time entre os líderes da competição.", "Nenhum jogador da equipa entre os líderes da competição.", "No player from the team among the competition leaders.", "Ningún jugador del equipo entre los líderes de la competición."],
  ["Posição no ranking de gols", "Posição no ranking de golos", "Rank in goals", "Puesto en goles"],
  ["Posição no ranking de assistências", 0, "Rank in assists", "Puesto en asistencias"],
  ["Detalhes", 0, "Details", "Detalles"],
  ["Classificações", 0, "Standings", "Clasificaciones"],
  ["Equipe", "Plantel", "Squad", "Plantilla"],
  ["Melhores jogadores", 0, "Top players", "Mejores jugadores"],
  ["★ Favorito", 0, "★ Favorite", "★ Favorito"],
  ["Sua lista", "A sua lista", "Your list", "Tu lista"],
  ["Nenhuma liga favorita. Marque em Competições.", 0, "No favorite leagues. Mark them in Competitions.", "Ninguna liga favorita. Márcalas en Competiciones."],
  ["Nenhum time favorito ainda.", "Nenhuma equipa favorita ainda.", "No favorite teams yet.", "Ningún equipo favorito todavía."],
  ["Nenhum jogador favorito ainda.", 0, "No favorite players yet.", "Ningún jugador favorito todavía."],
  ["Gols, pênaltis, cartões, intervalo e fim de jogo.", "Golos, penáltis, cartões, intervalo e fim de jogo.", "Goals, penalties, cards, half-time and full-time.", "Goles, penales, tarjetas, descanso y final del partido."],
  ["Limpar histórico", 0, "Clear history", "Borrar historial"],
  ["Nenhum alerta ainda.", 0, "No alerts yet.", "Ninguna alerta todavía."],
  ["Favorite times e competições (★) para receber gols, cartões, intervalo e fim de jogo.", "Favorite equipas e competições (★) para receber golos, cartões, intervalo e fim de jogo.", "Favorite teams and competitions (★) to get goals, cards, half-time and full-time alerts.", "Marca equipos y competiciones (★) como favoritos para recibir goles, tarjetas, descanso y final del partido."],
  ["PÊNALTI", "PENÁLTI", "PENALTY", "PENAL"],
  ["FIM DO 1º TEMPO", "FIM DA 1.ª PARTE", "END OF 1ST HALF", "FIN DEL 1.ER TIEMPO"],
  ["CARTÃO AMARELO", 0, "YELLOW CARD", "TARJETA AMARILLA"],
  ["CARTÃO VERMELHO", 0, "RED CARD", "TARJETA ROJA"],
  ["FIM DE JOGO", 0, "FULL TIME", "FINAL DEL PARTIDO"],
  ["GOL CONTRA", "AUTOGOLO", "OWN GOAL", "GOL EN CONTRA"],
  ["PÊNALTI · GOL!", "PENÁLTI · GOLO!", "PENALTY · GOAL!", "PENAL · ¡GOL!"],
  ["PÊNALTI PERDIDO", "PENÁLTI FALHADO", "PENALTY MISSED", "PENAL FALLADO"],
  ["Fechar", 0, "Close", "Cerrar"],
  ["Voltar", 0, "Back", "Volver"],
  ["Remover", 0, "Remove", "Quitar"],
  ["Ativar tema escuro", 0, "Switch to dark theme", "Activar tema oscuro"],
  ["Ativar tema claro", 0, "Switch to light theme", "Activar tema claro"],
  ["Idioma", 0, "Language", "Idioma"],
  ["API-Football: limite do dia", 0, "API-Football: daily limit", "API-Football: límite del día"],
  ["Escolha o idioma do aplicativo.", "Escolha o idioma da aplicação.", "Choose the app language.", "Elige el idioma de la aplicación."],
  ["O aplicativo recarrega ao trocar o idioma. Nomes de times e jogos seguem o idioma escolhido.", "A aplicação recarrega ao mudar o idioma. Nomes de equipas e jogos seguem o idioma escolhido.", "The app reloads when you change the language. Team and match names follow the chosen language.", "La aplicación se recarga al cambiar el idioma. Los nombres de equipos y partidos siguen el idioma elegido."],
  ["Notificações e sons", 0, "Notifications and sounds", "Notificaciones y sonidos"],
  ["Geral", 0, "General", "General"],
  ["Som", 0, "Sound", "Sonido"],
  ["Aviso na tela", "Aviso no ecrã", "On-screen banner", "Aviso en pantalla"],
  ["Alertas com o app fechado", "Alertas com a aplicação fechada", "Alerts with the app closed", "Alertas con la app cerrada"],
  ["Tipos de alerta", 0, "Alert types", "Tipos de alerta"],
  ["⚽ Gol", "⚽ Golo", "⚽ Goal", "⚽ Gol"],
  ["🎯 Pênalti", "🎯 Penálti", "🎯 Penalty", "🎯 Penal"],
  ["⏸️ Fim do 1º tempo", "⏸️ Fim da 1.ª parte", "⏸️ End of 1st half", "⏸️ Fin del 1.er tiempo"],
  ["🟨 Cartão amarelo", 0, "🟨 Yellow card", "🟨 Tarjeta amarilla"],
  ["🟥 Cartão vermelho", 0, "🟥 Red card", "🟥 Tarjeta roja"],
  ["🏁 Fim de jogo", 0, "🏁 Full time", "🏁 Final del partido"],
  ["▶ Testar", 0, "▶ Test", "▶ Probar"],
  ["Valem para as competições e times favoritados (★).", "Valem para as competições e equipas favoritas (★).", "They apply to your favorite competitions and teams (★).", "Valen para las competiciones y equipos favoritos (★)."],
  ["Com Alertas com o app fechado ativo, os avisos chegam mesmo com o app fechado.", "Com Alertas com a aplicação fechada ativo, os avisos chegam mesmo com a aplicação fechada.", "With Alerts with the app closed turned on, alerts arrive even when the app is closed.", "Con Alertas con la app cerrada activado, los avisos llegan aunque la app esté cerrada."],
  ["Mantenha o app aberto durante os jogos.", "Mantenha a aplicação aberta durante os jogos.", "Keep the app open during matches.", "Mantén la app abierta durante los partidos."],
  ["Som e vibração no Android", 0, "Sound and vibration on Android", "Sonido y vibración en Android"],
  ["Exemplo · DBZSCORE", 0, "Example · DBZSCORE", "Ejemplo · DBZSCORE"],
  ["Entrar no DBZSCORE", "Entrar no DBZSCORE", "Enter DBZSCORE", "Entrar en DBZSCORE"],
  ["Toque para entrar", 0, "Tap to enter", "Toca para entrar"],
  ["Partida", "Jogo", "Match", "Partido"],
  ["Campeonato", 0, "Championship", "Campeonato"],
  ["Recente", 0, "Recent", "Reciente"],
  ["Popular", 0, "Popular", "Popular"],
  ["Digite o nome de um jogador para buscar.", "Escreva o nome de um jogador para pesquisar.", "Type a player's name to search.", "Escribe el nombre de un jugador para buscar."],
  ["Digite o nome de um time para buscar partidas (ontem, hoje e amanhã).", "Escreva o nome de uma equipa para pesquisar jogos (ontem, hoje e amanhã).", "Type a team name to search matches (yesterday, today and tomorrow).", "Escribe el nombre de un equipo para buscar partidos (ayer, hoy y mañana)."],
  ["Não foi possível buscar agora. Verifique a internet e tente de novo.", "Não foi possível pesquisar agora. Verifique a internet e tente novamente.", "Could not search right now. Check your internet and try again.", "No se pudo buscar ahora. Revisa internet e inténtalo de nuevo."],
  ["A busca online de times e jogadores está indisponível agora.", "A pesquisa online de equipas e jogadores está indisponível agora.", "Online search for teams and players is unavailable right now.", "La búsqueda en línea de equipos y jugadores no está disponible ahora."],
  ["Carreira", 0, "Career", "Carrera"],
  ["Nacionalidade", 0, "Nationality", "Nacionalidad"],
  ["Pé preferido", "Pé preferencial", "Preferred foot", "Pie preferido"],
  ["Número da camisa", "Número da camisola", "Shirt number", "Número de camiseta"],
  ["Esquerdo", 0, "Left", "Izquierdo"],
  ["Direito", 0, "Right", "Derecho"],
  ["Ambidestro", 0, "Both feet", "Ambidiestro"],
  ["Desconhecido", 0, "Unknown", "Desconocido"],
  ["Valor de mercado", 0, "Market value", "Valor de mercado"],
  ["Buscando no Transfermarkt…", "A pesquisar no Transfermarkt…", "Searching Transfermarkt…", "Buscando en Transfermarkt…"],
  ["Fonte: Transfermarkt", 0, "Source: Transfermarkt", "Fuente: Transfermarkt"],
  ["Sem valor de mercado no Transfermarkt.", 0, "No market value on Transfermarkt.", "Sin valor de mercado en Transfermarkt."],
  ["Ver no Transfermarkt ›", 0, "View on Transfermarkt ›", "Ver en Transfermarkt ›"],
  ["Buscar no Transfermarkt ›", "Pesquisar no Transfermarkt ›", "Search on Transfermarkt ›", "Buscar en Transfermarkt ›"],
  ["Sem perfil deste jogador no Transfermarkt (ou o nome é diferente lá).", 0, "No profile for this player on Transfermarkt (or the name is different there).", "Sin perfil de este jugador en Transfermarkt (o el nombre es diferente allí)."],
  ["Não foi possível consultar o Transfermarkt agora.", 0, "Could not check Transfermarkt right now.", "No se pudo consultar Transfermarkt ahora."],
  ["Agente:", 0, "Agent:", "Agente:"],
  ["Compartilhar", "Partilhar", "Share", "Compartir"],
  ["Link copiado", "Ligação copiada", "Link copied", "Enlace copiado"],
  ["Partidas deste jogador indisponíveis na fonte de dados.", "Jogos deste jogador indisponíveis na fonte de dados.", "This player's matches are unavailable in the data source.", "Los partidos de este jugador no están disponibles en la fuente de datos."],
  ["Estatísticas deste jogador indisponíveis na fonte de dados.", 0, "This player's statistics are unavailable in the data source.", "Las estadísticas de este jugador no están disponibles en la fuente de datos."],
  ["Adversário", 0, "Opponent", "Rival"],
  ["Assist.", 0, "Ast.", "Asist."],
  ["Amarelos", 0, "Yellows", "Amarillas"],
  ["Vermelhos", 0, "Reds", "Rojas"],
  ["Contrato até", 0, "Contract until", "Contrato hasta"],
  ["Contrato:", 0, "Contract:", "Contrato:"],
  ["Emprestado de", "Emprestado por", "On loan from", "Cedido por"],
  ["· contrato lá até", "· contrato aí até", "· contract there until", "· contrato allí hasta"],
  ["Atualizado em", 0, "Updated on", "Actualizado el"],
  ["às", 0, "at", "a las"],
  ["Sua conta", "A sua conta", "Your account", "Tu cuenta"],
  ["Conta", 0, "Account", "Cuenta"],
  ["Conectado", "Ligado", "Signed in", "Conectado"],
  ["Favoritos na nuvem", "Favoritos na nuvem", "Favorites in the cloud", "Favoritos en la nube"],
  ["Última sincronização:", 0, "Last sync:", "Última sincronización:"],
  ["Sincronizando…", "A sincronizar…", "Syncing…", "Sincronizando…"],
  ["Sincronizar agora", 0, "Sync now", "Sincronizar ahora"],
  ["Sair da conta", "Terminar sessão", "Sign out", "Cerrar sesión"],
  ["Seus favoritos são salvos automaticamente e aparecem em qualquer aparelho em que você entrar com esta conta.", "Os seus favoritos são guardados automaticamente e aparecem em qualquer dispositivo onde inicie sessão com esta conta.", "Your favorites are saved automatically and appear on any device where you sign in with this account.", "Tus favoritos se guardan automáticamente y aparecen en cualquier dispositivo donde inicies sesión con esta cuenta."],
  ["Entrar", "Iniciar sessão", "Sign in", "Iniciar sesión"],
  ["Entre com sua conta Google para guardar seus favoritos (ligas, times e jogadores) na nuvem e usá-los em outros aparelhos.", "Inicie sessão com a sua conta Google para guardar os seus favoritos (ligas, equipas e jogadores) na nuvem e usá-los noutros dispositivos.", "Sign in with your Google account to keep your favorites (leagues, teams and players) in the cloud and use them on other devices.", "Inicia sesión con tu cuenta de Google para guardar tus favoritos (ligas, equipos y jugadores) en la nube y usarlos en otros dispositivos."],
  ["Abrindo…", "A abrir…", "Opening…", "Abriendo…"],
  ["Entrar com Google", "Iniciar sessão com o Google", "Sign in with Google", "Iniciar sesión con Google"],
  ["Sem entrar, tudo continua funcionando e os favoritos ficam só neste aparelho.", "Sem iniciar sessão, tudo continua a funcionar e os favoritos ficam só neste dispositivo.", "Without signing in, everything keeps working and favorites stay only on this device.", "Sin iniciar sesión, todo sigue funcionando y los favoritos quedan solo en este dispositivo."],
  ["Não foi possível sincronizar agora. Tentaremos de novo.", "Não foi possível sincronizar agora. Tentaremos novamente.", "Could not sync right now. We will try again.", "No se pudo sincronizar ahora. Lo intentaremos de nuevo."],
  ["Não foi possível sincronizar agora.", 0, "Could not sync right now.", "No se pudo sincronizar ahora."],
  ["O login com Google funciona no app Android.", "O início de sessão com o Google funciona na aplicação Android.", "Google sign-in works in the Android app.", "El inicio de sesión con Google funciona en la app de Android."],
  ["Tempo esgotado", 0, "Timed out", "Tiempo agotado"],
  ["Login indisponível neste aparelho", "Início de sessão indisponível neste dispositivo", "Sign-in unavailable on this device", "Inicio de sesión no disponible en este dispositivo"],
  ["Resposta inválida", 0, "Invalid response", "Respuesta no válida"],
  ["Nenhuma conta Google encontrada no aparelho", "Nenhuma conta Google encontrada no dispositivo", "No Google account found on the device", "No se encontró ninguna cuenta de Google en el dispositivo"],
  ["Bayern de Munique", 0, "Bayern Munich", "Bayern de Múnich"],
  ["Inter de Milão", 0, "Inter Milan", "Inter de Milán"],
  ["Milan", 0, "AC Milan", "Milan"],
  ["Atlético de Madrid", 0, "Atlético Madrid", "Atlético de Madrid"],
  ["São Paulo", 0, "São Paulo", "São Paulo"]
  ];
  var PATS = [
  ["^Fonte de dados fora do ar\\. Mostrando dados salvos às (.+) \\(toque para fechar\\)$", "Fonte de dados indisponível. A mostrar dados guardados às $1 (toque para fechar)", "Data source is offline. Showing data saved at $1 (tap to close)", "Fuente de datos sin respuesta. Mostrando datos guardados a las $1 (toca para cerrar)"],
  ["^(\\d+) jogo ao vivo$", "$1 jogo em direto", "$1 live match", "$1 partido en vivo"],
  ["^(\\d+) jogos ao vivo$", "$1 jogos em direto", "$1 live matches", "$1 partidos en vivo"],
  ["^há (\\d+) min$", 0, "$1 min ago", "hace $1 min"],
  ["^hoje (\\d{1,2}:\\d{2})$", 0, "today $1", "hoy $1"],
  ["^(\\d+) ligas$", 0, "$1 leagues", "$1 ligas"],
  ["^(\\d+) times$", "$1 equipas", "$1 teams", "$1 equipos"],
  ["^(\\d+) jogadores$", 0, "$1 players", "$1 jugadores"],
  ["^(\\d+) anos$", 0, "$1 years", "$1 años"],
  ["^(\\d+)º$", "@ord($1)", "@ord($1)", "@ord($1)"],
  ["^Nada encontrado para “(.+)”\\.$", 0, "Nothing found for “$1”.", "No se encontró nada para “$1”."],
  ["^Não foi possível carregar dados \\((.+)\\)\\.?$", 0, "Could not load data ($1).", "No se pudieron cargar los datos ($1)."],
  ["^Última sincronização: (.+)$", 0, "Last sync: $1", "Última sincronización: $1"],
  ["^Estádio: (.+)$", 0, "Stadium: $1", "Estadio: $1"],
  ["^Assistência: (.+)$", 0, "Assist: $1", "Asistencia: $1"],
  ["^Contrato até (.+)$", 0, "Contract until $1", "Contrato hasta $1"],
  ["^Contrato: (.+)$", 0, "Contract: $1", "Contrato: $1"],
  ["^Emprestado de (.+)$", "Emprestado por $1", "On loan from $1", "Cedido por $1"],
  ["^contrato lá até (.+)$", "contrato aí até $1", "contract there until $1", "contrato allí hasta $1"],
  ["^Atualizado em (.+)$", 0, "Updated on $1", "Actualizado el $1"],
  ["^Gols (\\d+)$", "Golos $1", "Goals $1", "Goles $1"],
  ["^Assist\\. (\\d+)$", 0, "Ast. $1", "Asist. $1"],
  ["^Amarelos (\\d+)$", 0, "Yellows $1", "Amarillas $1"],
  ["^Vermelhos (\\d+)$", 0, "Reds $1", "Rojas $1"],
  ["^Pênalti perdido: (.+)$", "Penálti falhado: $1", "Penalty missed: $1", "Penal fallado: $1"],
  ["^Gol contra! (.+)$", "Autogolo! $1", "Own goal! $1", "¡Gol en contra! $1"],
  ["^Gol de pênalti! (.+)$", "Golo de penálti! $1", "Penalty scored! $1", "¡Gol de penal! $1"],
  ["^Fotos \\(API-Football\\): (\\d+) de (\\d+) buscas hoje$", 0, "Photos (API-Football): $1 of $2 searches today", "Fotos (API-Football): $1 de $2 búsquedas hoy"],
  ["^consultas do dia: (\\d+) de (\\d+)$", 0, "requests today: $1 of $2", "consultas del día: $1 de $2"],
  ["^último aviso: (.+)$", 0, "last notice: $1", "último aviso: $1"],
  ["^Futebol, (.+)$", 0, "Football, $1", "Fútbol, $1"],
  ["^Gol! (.+?) Assistência de (.+)$", "Golo! $1 Assistência de $2", "Goal! $1 Assist by $2", "¡Gol! $1 Asistencia de $2"],
  ["^Gol! (.+)$", "Golo! $1", "Goal! $1", "¡Gol! $1"],
  ["^Cartão amarelo para (.+)$", 0, "Yellow card for $1", "Tarjeta amarilla para $1"],
  ["^Cartão vermelho para (.+)$", 0, "Red card for $1", "Tarjeta roja para $1"],
  ["^Substituição\\. (.+)$", 0, "Substitution. $1", "Sustitución. $1"],
  ["^Fonte reserva: HTTP (.+)$", "Fonte de reserva: HTTP $1", "Backup source: HTTP $1", "Fuente de respaldo: HTTP $1"],
  ["^Fonte reserva recusou o pedido: (.+)$", "Fonte de reserva recusou o pedido: $1", "Backup source refused the request: $1", "La fuente de respaldo rechazó la solicitud: $1"],
  ["^O Supabase recusou o login: (.+)$", "O Supabase recusou o início de sessão: $1", "Supabase refused the sign-in: $1", "Supabase rechazó el inicio de sesión: $1"],
  ["^Login feito, mas a sincronização falhou: (.+)$", "Sessão iniciada, mas a sincronização falhou: $1", "Signed in, but syncing failed: $1", "Sesión iniciada, pero la sincronización falló: $1"],
  ["^Falha no login: (.+)$", "Falha no início de sessão: $1", "Sign-in failed: $1", "Error al iniciar sesión: $1"]
  ];

  var MAP = Object.create(null);
  ROWS.forEach(function (r) { MAP[r[0]] = r; });
  var PRE = PATS.map(function (p) {
    var re = null;
    try { re = new RegExp(p[0]); } catch (e) {}
    return { re: re, t: [p[1], p[2], p[3]] };
  }).filter(function (p) { return p.re; });

  function ord(n, c) {
    n = +n;
    if (c === 2) { var m = n % 100, d = n % 10; return n + (m >= 11 && m <= 13 ? "th" : d === 1 ? "st" : d === 2 ? "nd" : d === 3 ? "rd" : "th"); }
    if (c === 3 || c === 1) return n + ".º";
    return n + "º";
  }
  function fill(tpl, m) {
    return tpl.replace(/@ord\(\$(\d)\)/g, function (_, i) { return ord(m[+i], col); }).replace(/\$(\d)/g, function (_, i) { return m[+i] == null ? "" : m[+i]; });
  }

  function core(s, scope) {
    var r;
    if (scope) { r = MAP[scope + s]; if (r) return pick(r, s); }
    r = MAP[s];
    if (r) return pick(r, s);
    for (var i = 0; i < PRE.length; i++) {
      var m = PRE[i].re.exec(s);
      if (m) {
        var t = PRE[i].t[col - 1];
        if (col === 0 || t === 0 || t == null) return s;
        return fill(t, m);
      }
    }
    return null;
  }
  function pick(r, s) {
    if (col === 0) return s;
    var v = r[col];
    return v === 0 || v == null ? s : v;
  }

  /* devolve o texto traduzido (ou o mesmo texto, se não houver tradução) */
  function tr(text, scope) {
    if (col === 0 || text == null) return text;
    var s0 = String(text);
    var lead = s0.match(/^\s*/)[0], trail = s0.match(/\s*$/)[0];
    var s = s0.replace(/\s+/g, " ").trim();
    if (!s) return s0;
    var out = core(s, scope);
    if (out == null && s.indexOf(" · ") > 0) {
      var changed = false;
      out = s.split(" · ").map(function (p) { var q = core(p, ""); if (q != null && q !== p) { changed = true; return q; } return p; }).join(" · ");
      if (!changed) out = null;
    }
    if (out == null) {
      var sent = s.match(/[^.!?]+[.!?]*\s*/g);
      if (sent && sent.length > 1) {
        var ch = false;
        out = sent.map(function (p) {
          var q = core(p.trim(), "");
          if (q != null && q !== p.trim()) { ch = true; return q + (/\s$/.test(p) ? " " : ""); }
          return p;
        }).join("").trim();
        if (!ch) out = null;
      }
    }
    if (out == null || out === s) return s0;
    return lead + out + trail;
  }

  /* ---------- tradutor do DOM ---------- */
  var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, NOSCRIPT: 1, INPUT: 1 };
  var ATTRS = ["aria-label", "title", "placeholder"];
  var LAST = new WeakMap(), LASTA = new WeakMap();

  function doText(n) {
    var p = n.parentNode;
    if (!p || SKIP[p.nodeName]) return;
    var v = n.nodeValue;
    if (!v || !/\S/.test(v) || LAST.get(n) === v) return;
    var t = tr(v, p.nodeName === "TH" ? "th:" : "");
    if (t !== v) { LAST.set(n, t); n.nodeValue = t; }
  }
  function doAttrs(el) {
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i], v = el.getAttribute(a);
      if (!v) continue;
      var memo = LASTA.get(el);
      if (memo && memo[a] === v) continue;
      var t = tr(v);
      if (t !== v) { if (!memo) { memo = {}; LASTA.set(el, memo); } memo[a] = t; el.setAttribute(a, t); }
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1) return;
    if (root.nodeName === "SCRIPT" || root.nodeName === "STYLE") return;
    doAttrs(root);
    var w = document.createTreeWalker(root, 1 | 4, null), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) doText(n);
      else doAttrs(n);
    }
  }

  function start() {
    document.documentElement.setAttribute("lang", L.code);
    if (col === 0) return;
    var mo = new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) {
        var m = ms[i];
        if (m.type === "childList") { for (var j = 0; j < m.addedNodes.length; j++) walk(m.addedNodes[j]); }
        else if (m.type === "characterData") doText(m.target);
        else if (m.type === "attributes" && m.target.nodeType === 1) doAttrs(m.target);
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    walk(document.documentElement);
  }

  /* ---------- seletor de idioma ---------- */
  var GLOBE = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>';
  function btn() {
    return '<button class="bell-btn lang-btn" id="lang-btn" type="button" aria-label="Idioma" title="Idioma" aria-haspopup="dialog">' + GLOBE + '<i class="lang-code">' + L.short + '</i></button>';
  }
  function setLang(c) {
    if (!BY[c]) return;
    if (c === code) { closeSheet(); return; }
    try { localStorage.setItem(KEY, c); } catch (e) {}
    try { window.AndroidNotify && AndroidNotify.setIdioma && AndroidNotify.setIdioma(c); } catch (e) {}
    location.reload();
  }
  function closeSheet() {
    var o = document.getElementById("lang-ov");
    if (o) { o.classList.add("out"); setTimeout(function () { o.remove(); }, 180); }
  }
  function openSheet() {
    if (document.getElementById("lang-ov")) return;
    var o = document.createElement("div");
    o.id = "lang-ov";
    o.className = "lang-ov";
    o.innerHTML = '<div class="lang-sheet" role="dialog" aria-modal="true" aria-label="Idioma">' +
      '<h2 class="sec">Idioma</h2><p class="lang-sub">Escolha o idioma do aplicativo.</p>' +
      '<div class="lang-list">' + LANGS.map(function (l) {
        return '<button type="button" class="lang-opt' + (l.code === code ? " on" : "") + '" data-lang="' + l.code + '" lang="' + l.code + '"><span class="lang-n">' + l.name + '</span><i class="lang-ck">' + (l.code === code ? "✓" : "") + '</i></button>';
      }).join("") + '</div>' +
      '<p class="lang-note">O aplicativo recarrega ao trocar o idioma. Nomes de times e jogos seguem o idioma escolhido.</p>' +
      '<button type="button" class="lang-close" data-lang-close="1">Fechar</button></div>';
    document.body.appendChild(o);
    var f = o.querySelector(".lang-opt.on") || o.querySelector(".lang-opt");
    if (f) try { f.focus(); } catch (e) {}
  }
  document.addEventListener("click", function (ev) {
    var t = ev.target;
    if (!t || !t.closest) return;
    var b = t.closest("#lang-btn");
    if (b) { ev.preventDefault(); openSheet(); return; }
    var o = t.closest(".lang-opt");
    if (o) { ev.preventDefault(); setLang(o.getAttribute("data-lang")); return; }
    if (t.closest("[data-lang-close]") || t.id === "lang-ov") closeSheet();
  });
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape") closeSheet(); });

  window.DBZ_I18N = { code: code, lang: code, locale: L.locale, tz: tz, espn: L.espn, al: L.al, col: col, langs: LANGS, tr: tr, btn: btn, set: setLang, walk: walk, rows: ROWS, pats: PATS };

  try { window.AndroidNotify && AndroidNotify.setIdioma && AndroidNotify.setIdioma(code); } catch (e) {}
  start();
  document.addEventListener("DOMContentLoaded", function () { walk(document.documentElement); });
})();
