package com.dbzscore.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationChannelGroup
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.min

/**
 * Tipos de alerta. Cada um tem o próprio canal do Android (som, vibração e cor), então dá para
 * silenciar só os cartões amarelos, por exemplo, em Configurações > Apps > DBZSCORE > Notificações.
 * As cores são as mesmas do banner dentro do app (styles.css).
 */
enum class Alerta(
    val chave: String,          // mesmo nome usado no JS (goal, penalty, ht, yellow, red, ft)
    val nomeCanal: String,
    val emoji: String,
    val cor: Int,
    val somRes: Int,
    val vibracao: LongArray
) {
    GOL("goal", "Gols", "\u26BD", 0xFF2ECC71.toInt(), R.raw.som_gol, longArrayOf(0, 220, 110, 220, 110, 520)),
    PENALTI("penalty", "Pênaltis", "\uD83C\uDFAF", 0xFFA66BFF.toInt(), R.raw.som_penalti, longArrayOf(0, 300, 150, 300)),
    INTERVALO("ht", "Intervalo", "\u23F8\uFE0F", 0xFF35D6E8.toInt(), R.raw.som_intervalo, longArrayOf(0, 350)),
    AMARELO("yellow", "Cartões amarelos", "\uD83D\uDFE8", 0xFFFFD60A.toInt(), R.raw.som_amarelo, longArrayOf(0, 160, 90, 160)),
    VERMELHO("red", "Cartões vermelhos", "\uD83D\uDFE5", 0xFFE5383B.toInt(), R.raw.som_vermelho, longArrayOf(0, 500, 120, 500)),
    FIM("ft", "Fim de jogo", "\uD83C\uDFC1", 0xFFFF7A00.toInt(), R.raw.som_fim, longArrayOf(0, 200, 100, 450));

    val canal: String get() = "alerta_$chave"

    companion object {
        fun de(chave: String?): Alerta = values().firstOrNull { it.chave == chave } ?: GOL
    }
}

/**
 * Ponte JS -> Android. No JS: AndroidNotify.showRico(tipo, titulo, placar, detalhe, liga, urlEscudo, slug, matchId)
 * Cada partida vira uma "conversa": os alertas seguintes entram na mesma notificação, e as
 * partidas ficam agrupadas num resumo quando há mais de uma.
 */
class NotificationBridge(context: Context) {

    private val app = context.applicationContext
    private val io = Executors.newSingleThreadExecutor()

    init {
        criarCanais(app)
    }

    @JavascriptInterface
    fun showRico(
        tipo: String, titulo: String, placar: String, detalhe: String, liga: String,
        avatarUrl: String?, slug: String?, matchId: String?
    ) {
        notificar(tipo, titulo, placar, detalhe, liga, avatarUrl, slug.orEmpty(), matchId.orEmpty())
    }

    /** AndroidNotify.setIdioma("pt-BR" | "pt-PT" | "en" | "es"): idioma das notificações nativas. */
    @JavascriptInterface
    fun setIdioma(codigo: String) {
        try {
            Textos.salvar(app, codigo)
            criarCanais(app) // renomeia os canais (Configurações > Notificações) no idioma novo
        } catch (e: Exception) {
        }
    }

    /** AndroidNotify.sync(json): guarda favoritos/opções e liga ou desliga o serviço de segundo plano. */
    @JavascriptInterface
    fun sync(json: String) {
        try {
            Prefs.salvar(app, json)
            val intent = Intent(app, MonitorService::class.java)
            if (Prefs.ler(app).bg) ContextCompat.startForegroundService(app, intent) else app.stopService(intent)
        } catch (e: Exception) {
            // ex.: Android não permite iniciar serviço em primeiro plano agora
        }
    }

    /** AndroidNotify.abrirAjustes(): abre as configurações de notificação do app (som e vibração por tipo). */
    @JavascriptInterface
    fun abrirAjustes() {
        try {
            val intent = Intent("android.settings.APP_NOTIFICATION_SETTINGS")
                .putExtra("android.provider.extra.APP_PACKAGE", app.packageName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
        } catch (e: Exception) {
        }
    }

    /** Usado também pelo MonitorService (não é exposto ao JS). */
    fun notificar(
        tipo: String, titulo: String, placar: String, detalhe: String, liga: String,
        avatarUrl: String?, slug: String, matchId: String
    ) {
        try {
            io.execute {
                try {
                    publicar(tipo, titulo, placar, detalhe, liga, avatarUrl, slug, matchId)
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
            // executor já encerrado
        }
    }

    fun fechar() {
        io.shutdown()
    }

    @SuppressLint("MissingPermission")
    private fun publicar(
        tipo: String, titulo: String, placar: String, detalhe: String, liga: String,
        avatarUrl: String?, slug: String, matchId: String
    ) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val alerta = Alerta.de(tipo)
        val chave = "jogo_" + matchId.ifEmpty { "geral" }
        val logo = avatarUrl?.takeIf { it.startsWith("https://") }?.let { baixar(it) }
        val avatar = montarAvatar(logo, alerta)

        // Remetente = o tipo do lance (ex.: "⚽ GOL!"), com o escudo do time dentro de um anel colorido.
        val remetente = Person.Builder()
            .setName(alerta.emoji + " " + titulo)
            .setKey(chave)
            .setIcon(IconCompat.createWithBitmap(avatar))
            .build()
        val eu = Person.Builder().setName(Textos.t(app, "voce")).build()

        publicarAtalho(chave, remetente, placar.ifEmpty { "Jogo" })

        // Texto: placar em negrito + jogador e minuto. Cada linha do histórico se explica sozinha.
        val corpo = SpannableStringBuilder()
        if (placar.isNotEmpty()) {
            val ini = corpo.length
            corpo.append(placar)
            corpo.setSpan(StyleSpan(Typeface.BOLD), ini, corpo.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (detalhe.isNotEmpty()) {
            if (corpo.isNotEmpty()) corpo.append("  \u00b7  ")
            corpo.append(detalhe)
        }
        if (corpo.isEmpty()) corpo.append(titulo)

        val id = chave.hashCode()
        val nm = app.getSystemService(NotificationManager::class.java)

        // Reaproveita a conversa já aberta dessa partida (empilha os alertas)
        val existente = nm.activeNotifications.firstOrNull { it.id == id }?.notification
        val estilo = existente?.let {
            NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(it)
        } ?: NotificationCompat.MessagingStyle(eu)
        estilo.addMessage(corpo, System.currentTimeMillis(), remetente)

        val builder = NotificationCompat.Builder(app, alerta.canal)
            .setSmallIcon(R.drawable.ic_stat_dbz)
            .setColor(alerta.cor)
            .setLargeIcon(avatar)
            .setStyle(estilo)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(chave)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setGroup(GRUPO)
            .setAutoCancel(true)
            .setContentIntent(abrirJogo(id, slug, matchId))
        if (liga.isNotEmpty()) builder.setSubText(liga)
        if (Build.VERSION.SDK_INT < 26) {
            // Antes do Android 8 não existem canais: som e vibração vão na própria notificação
            builder.setSound(Uri.parse("android.resource://${app.packageName}/${alerta.somRes}"))
            builder.setVibrate(alerta.vibracao)
        }

        NotificationManagerCompat.from(app).notify(id, builder.build())
        publicarResumo(nm, alerta, id)
    }

    /** Resumo do grupo: com mais de uma partida, o Android junta tudo num único cartão. */
    @SuppressLint("MissingPermission")
    private fun publicarResumo(nm: NotificationManager, alerta: Alerta, idAtual: Int) {
        val jogos = nm.activeNotifications.count {
            it.id != ID_RESUMO && it.id != idAtual && it.notification.group == GRUPO
        } + 1
        val texto = if (jogos == 1) Textos.t(app, "novo1") else Textos.t(app, "novoN", jogos)
        val resumo = NotificationCompat.Builder(app, alerta.canal)
            .setSmallIcon(R.drawable.ic_stat_dbz)
            .setColor(COR_MARCA)
            .setContentTitle("DBZSCORE")
            .setContentText(texto)
            .setStyle(NotificationCompat.InboxStyle().setSummaryText(texto))
            .setGroup(GRUPO)
            .setGroupSummary(true)
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setAutoCancel(true)
            .setContentIntent(abrirApp())
            .build()
        NotificationManagerCompat.from(app).notify(ID_RESUMO, resumo)
    }

    // Android 11+ só trata como "conversa" (avatar grande) se houver atalho de longa duração
    private fun publicarAtalho(chave: String, pessoa: Person, rotulo: String) {
        val intent = Intent(app, MainActivity::class.java).setAction(Intent.ACTION_VIEW)
        val atalho = ShortcutInfoCompat.Builder(app, chave)
            .setShortLabel(rotulo)
            .setLongLived(true)
            .setIntent(intent)
            .setPerson(pessoa)
            .apply { pessoa.icon?.let { setIcon(it) } }
            .build()
        ShortcutManagerCompat.pushDynamicShortcut(app, atalho)
    }

    /**
     * Avatar redondo: escudo (sem distorcer) sobre fundo claro, com anel na cor do lance.
     * Sem escudo (intervalo, fim de jogo), mostra o emoji do lance no lugar.
     */
    private fun montarAvatar(logo: Bitmap?, alerta: Alerta): Bitmap {
        val t = 192
        val bmp = Bitmap.createBitmap(t, t, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pincel = Paint(Paint.ANTI_ALIAS_FLAG)

        pincel.style = Paint.Style.FILL
        pincel.color = 0xFFF4EFE4.toInt()
        c.drawCircle(t / 2f, t / 2f, t / 2f, pincel)

        if (logo != null && logo.width > 0 && logo.height > 0) {
            val caixa = t * 0.58f
            val escala = min(caixa / logo.width, caixa / logo.height)
            val w = logo.width * escala
            val h = logo.height * escala
            val destino = RectF((t - w) / 2f, (t - h) / 2f, (t + w) / 2f, (t + h) / 2f)
            c.drawBitmap(logo, null, destino, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } else {
            val texto = Paint(Paint.ANTI_ALIAS_FLAG)
            texto.textSize = t * 0.5f
            texto.textAlign = Paint.Align.CENTER
            val y = t / 2f - (texto.descent() + texto.ascent()) / 2f
            c.drawText(alerta.emoji, t / 2f, y, texto)
        }

        pincel.style = Paint.Style.STROKE
        pincel.strokeWidth = t * 0.075f
        pincel.color = alerta.cor
        c.drawCircle(t / 2f, t / 2f, t / 2f - pincel.strokeWidth / 2f, pincel)
        return bmp
    }

    private fun abrirApp(): PendingIntent {
        val intent = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            app, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun abrirJogo(id: Int, slug: String, matchId: String): PendingIntent {
        val intent = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (slug.isNotEmpty() && matchId.isNotEmpty()) putExtra(EXTRA_HASH, "#/jogo/$slug/$matchId")
        }
        return PendingIntent.getActivity(
            app, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun baixar(url: String): Bitmap? = try {
        URL(url).openStream().use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        null
    }

    companion object {
        const val EXTRA_HASH = "hash"
        const val COR_MARCA = 0xFFFF7A00.toInt()
        private const val GRUPO = "partidas"
        private const val ID_RESUMO = 4243
        private const val GRUPO_CANAIS = "alertas_jogos"

        /** true enquanto o app está na tela (o serviço não notifica nesse caso). */
        @Volatile
        var appVisivel = false
        private val HASH_OK = Regex("^#/jogo/[A-Za-z0-9._-]+/[A-Za-z0-9_-]+$")

        /** Chame em onCreate/onNewIntent da MainActivity para abrir a partida tocada. */
        fun hashDoIntent(intent: Intent?): String? =
            intent?.getStringExtra(EXTRA_HASH)?.takeIf { HASH_OK.matches(it) }

        /** Um canal por tipo de alerta, agrupados em "Alertas de jogos". Pode ser chamado várias vezes. */
        fun criarCanais(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannelGroup(NotificationChannelGroup(GRUPO_CANAIS, Textos.t(ctx, "grupo")))
            val som = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            for (a in Alerta.values()) {
                val canal = NotificationChannel(a.canal, Textos.t(ctx, "c_" + a.chave), NotificationManager.IMPORTANCE_HIGH)
                canal.group = GRUPO_CANAIS
                canal.setSound(Uri.parse("android.resource://${ctx.packageName}/${a.somRes}"), som)
                canal.enableVibration(true)
                canal.vibrationPattern = a.vibracao
                canal.enableLights(true)
                canal.lightColor = a.cor
                canal.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                nm.createNotificationChannel(canal)
            }
            // Canal único da versão anterior (substituído pelos canais por tipo)
            nm.deleteNotificationChannel("partidas")
        }
    }
}
