# DBZSCORE (projeto Android)

## Opção A: gerar o APK na nuvem (sem instalar nada)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow** (ele também roda a cada push).
3. Quando terminar (uns 3 a 6 min), abra a execução e baixe **DBZSCORE-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`, já assinado com a chave de debug e instalável.

## Opção B: Android Studio
1. File > Open e escolha a pasta `DBZSCORE`; aguarde o Gradle Sync (não use `./gradlew`).
2. Build > Build Bundle(s) / APK(s) > Build APK(s). O arquivo sai em `app/build/outputs/apk/debug/`.

## Depois de instalar
- Permita as notificações (Android 13+) e toque em "▶ Testar" nas configurações de alertas.
- Se o Android recusar a instalação por assinatura diferente, desinstale a versão antiga antes (os favoritos serão perdidos).

## O que mudou em relação ao APK original
- `NotificationBridge.kt`: notificações no estilo conversa (MessagingStyle); cada partida é uma conversa.
- `MainActivity.kt`: registra a ponte `AndroidNotify`, pede `POST_NOTIFICATIONS` e abre a partida ao tocar na notificação.
- `assets/www/app.js`: `fxNative` envia os alertas (gol, cartão, intervalo, fim) e o botão "Testar" para a notificação nativa.
- `AndroidManifest.xml`: permissões de notificação e de serviço em primeiro plano, e o `MonitorService`.

## Alertas com o app fechado
O app agora tem um serviço em segundo plano (`MonitorService`) que consulta os jogos favoritos a cada 25 a 60 s e avisa gols, cartões, fim do 1º tempo e fim de jogo, mesmo com o app fechado.
- Aparece uma notificação fixa discreta ("Acompanhando seus jogos favoritos"); é exigência do Android.
- Dá para desligar em **Alertas > Notificações e sons > Alertas com o app fechado**.
- Para o Android não encerrar o serviço, desative a economia de bateria do app (Configurações > Apps > DBZSCORE > Bateria > Sem restrições). Em Samsung, tire o app de "Apps em suspensão".
- Com o app aberto, o serviço não notifica (o banner da própria tela avisa).

## Página do time (nova)
Ao tocar num time (Favoritos, tabela da liga ou tela da partida) abrem as abas:
- **Detalhes**: jogo ao vivo / próximo / último, posição na tabela, forma recente e próximos jogos.
- **Partidas**: alterna entre **Lista** e **Calendário** (casa = claro, fora = escuro; toque no dia para abrir o jogo).
- **Classificações**: tabela da competição com o time destacado, faixas de classificação/rebaixamento e seletor de temporada.
- **Estatísticas**: resumo, ataque, defesa e casa × fora, calculados a partir dos resultados (com filtro por competição).
- **Equipe**: treinador e elenco por posição, com filtros Geral / Idade / Altura.
- **Melhores jogadores**: artilheiros e assistentes do time entre os líderes da competição.

## Correção do "Failed to fetch"
- `MainActivity.kt`: as chamadas à API da ESPN agora saem pelo próprio app (`proxyEspn`) e voltam com o CORS liberado.
- `app.js`: se um servidor falhar, tenta o servidor alternativo; se tudo falhar, mostra mensagem clara com botão "Tentar de novo".

## Busca e página do jogador (nova)
- Ícone de busca no topo: pesquisa times, competições e jogadores, com histórico recente.
- Página do jogador (toque num jogador na busca, no elenco ou nos artilheiros), com favoritar jogador pela estrela.
- Só mudaram `assets/www/app.js` e `assets/www/styles.css`; o código Kotlin e o manifesto continuam iguais.

## Tema claro e escuro (novo, versão 1.2.0)
- Botão de sol/lua no cabeçalho (ao lado da busca) alterna entre o tema escuro e o claro.
- A escolha fica salva no aparelho; o padrão continua sendo o tema escuro.
- Só mudaram `index.html`, `styles.css` e `app.js` (as cores agora são variáveis em `:root` e `:root[data-theme="light"]`).

## Versão para iPhone (site instalável / PWA)
O iPhone não roda APK. Esta versão é o mesmo app como site, que se instala pela tela de início.
- `web/build_site.py` monta o site (copia `assets/www`, junta os ícones e injeta as tags do iPhone).
- `.github/workflows/pages.yml` publica o site no GitHub Pages a cada envio (ou em Actions > Run workflow).
- Ative uma vez em **Settings > Pages > Build and deployment > Source: GitHub Actions**.
- No iPhone: abra o link no **Safari** > Compartilhar > **Adicionar à Tela de Início**.
- Limitação: no iPhone os alertas (banner e som) só funcionam com o app aberto. Notificação com o app fechado exigiria um servidor de push ou um app nativo com conta de desenvolvedor Apple.

## Página de lances renovada (versão 1.3.0)
Na tela da partida, a aba **Lances** foi refeita e ganhou uma aba **Comentário**:
- **Fluxo da partida**: gráfico de pressão de cada time ao longo do jogo, com marcadores de gols e cartões, linha do intervalo e cursor vermelho do minuto atual (ao vivo). Toque ou arraste para ver a pressão de cada minuto.
- **Mapa de lances**: campo com gols, chutes, escanteios, faltas e cartões, com filtros. A bola mostra o último lance e quem o fez; toque num ícone para ver o lance.
- **Linha do tempo**: casa à esquerda, visitante à direita, separada por tempo, com placar a cada gol, assistência, substituições (quem entrou e quem saiu) e filtros (Tudo, Gols, Cartões, Substituições). Toque no jogador para abrir a página dele.
- **Comentário**: lance a lance (principais ou todos), do mais recente ao mais antigo.
- Último lance (gol ou cartão) logo abaixo do placar, link da competição e rodada, e atualização automática a cada 30 s nos jogos ao vivo.
- Limites: o fluxo é uma estimativa calculada pelos lances e as posições no campo são aproximadas (a ESPN não envia coordenadas). Se a fonte não trouxer o comentário de um jogo, o app avisa.
- Só mudaram `assets/www/app.js` e `styles.css`.

## Formações em campo e fotos de jogadores (nova)
- **Escalação** da partida agora mostra o campo verde com os dois times (casa em cima, visitante embaixo), foto redonda de fundo branco, número e nome de cada jogador, e o esquema tático (ex.: 4-2-3-1) com a camisa do time.
- Os jogadores são posicionados por `formationPlace` + posição (esquerda/direita); se a fonte não enviar `formationPlace`, usa só a posição. Sem 2 escalações completas, mostra a lista de antes.
- Aba **Desempenho**: nota estimada pelo DBZSCORE (calculada com gols, assistências, chutes, defesas, faltas, cartões, gols sofridos e resultado; **não é nota oficial**), ícones de gol, assistência, cartão e substituição, e estrela no melhor da partida. Aba **Posição** mostra a posição de cada jogador.
- Banco de reservas de cada time embaixo do campo.
- **Fotos**: todas as fotos de jogadores do app (elenco, busca, artilheiros, página do jogador, escalação) usam o mesmo círculo de fundo branco; quem não tem foto ganha uma silhueta clara.
- Só mudaram `app.js` e `styles.css`.

## Página do jogador com Transfermarkt (nova)
Na aba **Detalhes** do jogador:
- **Valor de mercado** vindo do **Transfermarkt** (com a data da última atualização e link para o perfil dele lá).
- **Contrato até** (e "Emprestado de ..." quando for empréstimo), **pé preferido**, **agente** e o **ID do Transfermarkt**.
- A foto passa a ser a do Transfermarkt (mais atual); se não carregar, volta para a foto anterior.
- Como funciona: o app procura o jogador pelo nome no Transfermarkt, confere a **data de nascimento** (para não trazer um homônimo) e lê a página do perfil. O resultado fica salvo por 12 h no aparelho.
- Se o Transfermarkt não responder, aparece "Não foi possível consultar o Transfermarkt agora" com o botão **Tentar de novo**; o resto da página continua normal.
- Android: `MainActivity.kt` agora também busca `www.transfermarkt.com.br` pelo próprio app (sem CORS). iPhone/site: tenta direto e, se o navegador bloquear, usa proxies públicos (menos estável).
- Mudaram: `app.js`, `styles.css` e `MainActivity.kt`.

### Correção: jogador sem dados na ESPN ou com nome diferente no Transfermarkt (v6)
- A busca agora tenta o nome completo e, se não achar, o sobrenome; aceita o jogador quando o clube e parte do nome batem (e a data de nascimento, quando a ESPN tem).
- Quando a ESPN não tem dados do jogador (ex.: base de clube), nacionalidade, nascimento, posição e camisa vêm do Transfermarkt.
- Sem perfil no Transfermarkt: mensagem clara, link "Buscar no Transfermarkt" e uma linha cinza com o que a busca encontrou (ajuda a diagnosticar). "Tentar de novo" só aparece quando é falha de conexão.
- A grade de dados não aparece mais vazia.

### Correção: "Jogador não encontrado" em todos os jogadores (v7)
- Causa provável: o Transfermarkt barra requisições "cruas" do Java e devolve uma página de bloqueio/desafio que o app tratava como "sem resultados".
- Agora, no Android, `TransfermarktBridge.kt` abre as páginas num **WebView escondido** (Chrome de verdade, com cookies e JavaScript) e entrega o HTML para o app. O proxy nativo antigo e os proxies públicos ficam como reserva.
- O app só aceita páginas que realmente sejam do Transfermarkt; bloqueio ou desafio agora aparece como "Não foi possível consultar" (com "Tentar de novo"), e não mais como "jogador não encontrado".
- A linha cinza pequena embaixo do valor mostra o diagnóstico (ex.: `app: sem resposta · rota 0: HTTP 403`).
- Mudaram: `app.js`, `MainActivity.kt` e o novo `TransfermarktBridge.kt`.

## Novo visual "Aura" (versão 1.4.0)
O app ganhou uma identidade visual própria, **sem remover nenhuma função**. Só mudaram `styles.css`, `index.html`, a função do cartão de jogo, o gráfico "Fluxo da partida" e o campo da escalação em `app.js`, mais a cor de fundo (`colors.xml`, `build_site.py`).
- **Cantos "lâmina"** (assimétricos) nos cartões, botões e campos; painéis com cantos cortados e faixa de energia laranja→dourado na lateral.
- **Abas e filtros inclinados** (paralelogramo), no lugar de abas sublinhadas e pílulas.
- **Cartão de jogo "versus"**: time da casa à esquerda, visitante à direita e placar grande no centro. Jogos ao vivo têm brilho e uma **barra de ki** que enche conforme o minuto.
- **Menu inferior flutuante** com marca de energia na aba ativa.
- **Cores**: laranja da marca + dourado + ciano "ki" para o visitante (substitui o azul).
- **Fluxo da partida**: curvas suaves com brilho e gols marcados como losangos.
- **Linha do tempo** com uma coluna central e nós; gols acendem em laranja.
- **Escalação**: campo noturno com faixas, aro laranja (casa) ou ciano (visitante) em cada jogador e **notas em escala brasa → ouro** (a nota máxima brilha), no lugar do semáforo vermelho/verde.
- **Estatísticas**: barra dividida laranja × ciano.
- Tema escuro e claro continuam, e fundo/barra do sistema usam `#09080f` (escuro) e `#f5f1e8` (claro).

## Fotos dos jogadores (versão 9)
- Moldura clara em degradê (parecida com a do Sofascore) e recorte mais alto, para o rosto ficar centralizado.
- Quando a foto vem da Wikipédia (reserva), a miniatura agora é pedida em 400 px (antes 200 px), bem mais nítida.
- Só mudaram `assets/www/styles.css` e `assets/www/app.js`.

## Fotos de jogadores, fonte extra (versão 10)
- Quando a ESPN não tem a foto, o app busca primeiro no TheSportsDB (recorte do jogador) e só depois na Wikipédia.
- A chave `FXTSDBKEY` em `app.js` é a chave gratuita de testes ("3"). Para uso contínuo, crie a sua em thesportsdb.com e troque o valor.

## Nova logo
- Marca: um "Z" itálico em duas palhetas (como um placar), sobre o círculo central e a linha do meio do campo, com uma bola em órbita.
- Atualizados: `assets/www/logo.png` e `logo.svg` (cabeçalho, abertura, favicon), ícones web em `web/icons`, ícones do Android (normal, redondo e adaptativo, com fundo em `ic_launcher_background.png`) e o ícone de notificação `ic_stat_dbz.xml`.
- Pasta `branding/`: logo do ícone (SVG e PNG 1024) e logo horizontal com o nome (SVG e PNG, para fundo escuro e claro), para usar em redes sociais, loja etc.

## Dados salvos quando a fonte cai (versão 1.4.1)
- Cada resposta da ESPN que chega bem é guardada no aparelho (até 100 respostas, por até 3 dias, descartando as mais antigas).
- Se a fonte ficar fora do ar ou sem resposta, o app mostra a última cópia salva daquela tela e avisa com uma faixa: "Fonte de dados fora do ar. Mostrando dados salvos às HH:MM". Toque na faixa para fechar; ela some sozinha quando a fonte volta.
- Telas que nunca foram abertas antes não têm cópia e continuam mostrando a mensagem de erro com "Tentar de novo".
- Só mudaram `assets/www/app.js` (função `q` e funções `dbc...`) e `styles.css`.

## Fonte reserva: API-Football (versão 1.5.0)
Se a ESPN falhar (sem resposta, erro 403, 429 ou 5xx), o app passa sozinho para a API-Football e avisa numa faixa: "Fonte principal fora do ar. Usando a fonte reserva". Quando a ESPN volta, o app volta a usá-la e a faixa some.
- **O que a reserva cobre**: jogos do dia por campeonato, página do jogo (lances, placar, escalação, estatísticas) e a tabela de classificação. Não cobre páginas de time e de jogador, artilheiros nem o comentário detalhado (a aba Comentário mostra só os lances principais).
- **Chave**: fica em `assets/www/config.js` (`window.DBZ_APIFOOTBALL_KEY`). Para trocar a chave, edite esse arquivo; deixando `""` a reserva fica desligada.
- **Cota**: a conta grátis tem 100 consultas por dia. O app usa no máximo 95 por dia e junta pedidos iguais numa só consulta (um dia inteiro de jogos custa 1 consulta). O contador fica em `dbzscore-afq` no aparelho.
- **Android**: `MainActivity.kt` (`proxyEspn`) agora também atende `v3.football.api-sports.io`, trocando o parâmetro `dbzkey` da URL pelo cabeçalho `x-apisports-key`. No site/iPhone a chave vai direto no cabeçalho.
- Os jogos vindos da reserva têm identificadores próprios (começam com `af`), então favoritos de times e páginas de time/jogador só funcionam com a ESPN.
- **Cuidado**: a chave fica visível para quem abrir o APK ou o repositório. Se o repositório for público, deixe-o privado. Se a chave vazar, gere outra em dashboard.api-football.com e troque no `config.js`.
- Mudaram: `app.js`, `index.html`, `config.js` (novo) e `MainActivity.kt`.

## Fotos de jogadores pela API-Football (versão 1.6.0)
- Quando a ESPN não tem a foto de um jogador, o app agora tenta primeiro a **API-Football**; só depois TheSportsDB, Wikipédia e a silhueta.
- **As imagens (`media.api-sports.io`) são grátis e não contam na cota.** O que gasta é achar o jogador (1 busca por jogador novo). O resultado fica salvo no aparelho: foto encontrada fica guardada, e quando não acha o app só tenta de novo depois de 7 dias.
- **Limite diário:** no máximo 40 buscas por dia só para fotos (configurável em `config.js`, `DBZ_AF_FOTOS_POR_DIA`; use 0 para desligar). O app também para de buscar fotos quando sobram menos de 35 pedidos do dia, para a fonte reserva continuar funcionando.
- **Segurança contra foto errada:** só usa a foto quando o nome bate com um único jogador na API-Football. Nomes muito comuns (vários jogadores iguais) caem direto para as outras fontes.
- Mudaram: `app.js`, `config.js` e a versão (1.6.0).

## Fotos de todos os jogadores pela API-Football (versão 1.7.0)
**O que estava errado:** o app mostrava a foto da ESPN e só consultava a API-Football quando essa imagem falhava, procurando só pelo nome. Na página do jogador, a foto ainda era trocada pela do Transfermarkt, que podia achar um homônimo (foi o caso do Pedro do Flamengo, que apareceu com o rosto do Pedro da Lazio).

**Agora a API-Football é a fonte principal em todas as telas** (escalação em campo, banco, elenco do time, melhores jogadores, artilheiros, busca, favoritos e página do jogador):
- O app acha o **time** na API-Football (`/teams?search=`) e baixa o **elenco** dele (`/players/squads?team=`). O jogador é procurado **dentro do elenco do próprio time**, por **nome + número da camisa**. Assim, dois "Pedro" em times diferentes nunca se misturam. Aceita nomes no formato "G. Sobrenome" e só sobrenome quando o resto fecha.
- A ESPN (em português) traduz nomes de times (ex.: "Bayern de Munique"); há uma tabela de apelidos em `app.js` (`AFP_ALIAS`) que converte os mais comuns para o nome em inglês da API-Football. Se um time não for reconhecido, o jogador continua com a foto da ESPN (se quiser incluir mais apelidos, é só acrescentar `nome em português=nome em inglês;`).
- **Sem chute:** se não houver certeza (nome repetido no mesmo elenco sem camisa que desempate), mantém a foto da ESPN em vez de mostrar uma errada. Se a imagem da API-Football não carregar, volta para a da ESPN.
- O **Transfermarkt não troca mais a foto** do jogador. As reservas TheSportsDB/Wikipédia só entram com nome completo (nunca só "Pedro").
- **Cota:** as imagens (`media.api-sports.io`) são grátis. Cada time novo custa ~2 pedidos (time + elenco) e fica guardado no aparelho (time 30 dias, elenco 7 dias, foto de cada jogador 30 dias). Limite diário só para fotos: `DBZ_AF_FOTOS_POR_DIA = 60` em `config.js` (o app ainda reserva 35 pedidos para a fonte reserva). As buscas esperam numa fila de no máx. 8 por minuto (o plano gratuito aceita ~10), e as fotos da ESPN aparecem enquanto isso.
- Favoritos de jogador agora guardam o time para achar a foto certa; favoritos antigos reaproveitam a foto já descoberta em outra tela.
- Na primeira abertura depois de atualizar, o app descarta o cache antigo de fotos (podia ter foto errada).
- Mudaram: `app.js`, `config.js` e a versão (1.7.0).
- **Observação (não alterado):** na página do jogador, os dados do Transfermarkt (data de nascimento, valor, agente) podem vir de um homônimo quando a ESPN não informa a data de nascimento do jogador. Foi o que apareceu no Pedro do Flamengo (nascimento 1987).

## Fotos só da API-Football (versão 1.7.1)
- **Nenhuma foto de jogador vem mais da ESPN** (nem do TheSportsDB ou da Wikipédia). Enquanto a API-Football não responde, aparece a silhueta; se ela não achar o jogador com segurança, a silhueta fica (nunca uma foto "chutada").
- Fotos antigas guardadas no aparelho (favoritos, histórico de busca) que vinham da ESPN são trocadas pela silhueta e depois pela foto certa.
- **Correção do empate de times:** quando a busca devolvia times com nome parecido (ex.: "Barcelona" e "Barcelona SC", "Santos" e "Santos FC"), o app desistia e o jogador ficava sem foto. Agora o time com o mesmo nome que a ESPN informa vence.
- Logos de times, placares, tabelas, elencos e estatísticas continuam vindo da ESPN, com a API-Football como reserva. A API-Football grátis tem só 100 consultas por dia, pouco para rodar o app inteiro só com ela; se você tiver plano pago, dá para trocar tudo.
- Mudaram: `app.js` e a versão (1.7.1).

## Fotos aparecendo mais (versão 1.7.2)
**Problema:** com a ESPN fora das fotos, vários jogadores ficavam só com a silhueta. O app disparava até 8 pedidos de uma vez para a API-Football; ela recusa por limite por minuto, e o app (1) não tentava de novo e (2) ainda gastava o limite diário de fotos com os pedidos que falharam. Além disso, quando o limite acabava, guardava "time/jogador não existe" por 2 dias, o que não era verdade.
- **Fila de um pedido por vez** (máx. 9 por minuto), um jogador por vez: as fotos aparecem aos poucos, de cima para baixo, em vez de todas só no fim.
- **Nova tentativa automática:** se a API recusar (limite por minuto), espera 15 s e tenta de novo; se ainda falhar, a foto é tentada de novo depois (até 4 vezes, a cada 30 s, 60 s, ...).
- **Falha não gasta o limite diário de fotos** e **não vira "não achei"**: só guarda "sem foto" quando a busca foi mesmo feita.
- **Limite do dia da API:** se a API disser que o limite diário acabou, o app para de tentar por 1 hora.
- **Diagnóstico:** em **Alertas**, no fim do painel "Notificações e sons", aparece uma linha pequena: buscas de foto de hoje, consultas do dia e o último aviso da API (ex.: `rateLimit`, `limite do dia`).
- A primeira abertura da lista "Popular" leva uns 2 minutos para preencher todas as fotos (cada time novo = 2 consultas). Depois ficam guardadas por 30 dias.
- Mudaram: `app.js`, `styles.css` e a versão (1.7.2).
