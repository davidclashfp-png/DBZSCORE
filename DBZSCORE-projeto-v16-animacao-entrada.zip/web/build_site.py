#!/usr/bin/env python3
"""Monta o site do DBZSCORE (instalável no iPhone) a partir do app.

Uso:  python3 web/build_site.py [pasta_de_saida]     (padrão: ./site)

Copia app/src/main/assets/www, junta os ícones e injeta no index.html as
tags que o iPhone precisa para "Adicionar à Tela de Início".
"""
import json
import pathlib
import shutil
import sys

AQUI = pathlib.Path(__file__).resolve().parent
WWW = AQUI.parent / "app" / "src" / "main" / "assets" / "www"
SAIDA = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "site")

TAGS = """    <link rel="manifest" href="manifest.webmanifest" />
    <link rel="apple-touch-icon" href="apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-title" content="DBZSCORE" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="format-detection" content="telephone=no" />
"""

MANIFEST = {
    "name": "DBZSCORE",
    "short_name": "DBZSCORE",
    "description": "Placares de futebol ao vivo, classificação e alertas de gol.",
    "lang": "pt-BR",
    "start_url": "./",
    "scope": "./",
    "display": "standalone",
    "orientation": "portrait",
    "background_color": "#09080f",
    "theme_color": "#09080f",
    "icons": [
        {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
    ],
}


def main() -> None:
    if not (WWW / "index.html").exists():
        sys.exit(f"index.html não encontrado em {WWW}")

    if SAIDA.exists():
        shutil.rmtree(SAIDA)
    shutil.copytree(WWW, SAIDA)

    for icone in (AQUI / "icons").glob("*.png"):
        shutil.copy(icone, SAIDA / icone.name)

    html_path = SAIDA / "index.html"
    html = html_path.read_text(encoding="utf-8")
    if "</head>" not in html:
        sys.exit("index.html sem </head>")
    if "manifest.webmanifest" not in html:
        html = html.replace("</head>", TAGS + "  </head>", 1)
    html_path.write_text(html, encoding="utf-8")

    (SAIDA / "manifest.webmanifest").write_text(
        json.dumps(MANIFEST, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (SAIDA / ".nojekyll").write_text("")

    total = sum(1 for f in SAIDA.rglob("*") if f.is_file())
    print(f"Site gerado em '{SAIDA}' ({total} arquivos)")


if __name__ == "__main__":
    main()
