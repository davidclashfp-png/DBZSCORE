"use strict";(()=>{var we=[{slug:"fifa.world",name:"Copa do Mundo FIFA",shortName:"Copa do Mundo",country:"Mundo",countryCode:"",region:"internacional",kind:"selecao",featured:!0},{slug:"fifa.wwc",name:"Copa do Mundo Feminina",shortName:"Copa Feminina",country:"Mundo",countryCode:"",region:"internacional",kind:"selecao"},{slug:"fifa.cwc",name:"Mundial de Clubes FIFA",shortName:"Mundial de Clubes",country:"Mundo",countryCode:"",region:"internacional",kind:"continental"},{slug:"uefa.champions",name:"Liga dos Campe\xF5es da UEFA",shortName:"Champions League",country:"Europa",countryCode:"",region:"internacional",kind:"continental",featured:!0},{slug:"uefa.europa",name:"Liga Europa",shortName:"Liga Europa",country:"Europa",countryCode:"",region:"internacional",kind:"continental",featured:!0},{slug:"uefa.europa.conf",name:"Liga Confer\xEAncia",shortName:"Conference",country:"Europa",countryCode:"",region:"internacional",kind:"continental",featured:!0},{slug:"uefa.super_cup",name:"Supercopa da UEFA",shortName:"Supercopa UEFA",country:"Europa",countryCode:"",region:"internacional",kind:"continental"},{slug:"uefa.nations",name:"Liga das Na\xE7\xF5es da UEFA",shortName:"Nations League",country:"Europa",countryCode:"",region:"internacional",kind:"selecao"},{slug:"uefa.euro",name:"Eurocopa",shortName:"Euro",country:"Europa",countryCode:"",region:"internacional",kind:"selecao"},{slug:"conmebol.libertadores",name:"Copa Libertadores",shortName:"Libertadores",country:"Am\xE9rica do Sul",countryCode:"",region:"internacional",kind:"continental",featured:!0},{slug:"conmebol.sudamericana",name:"Copa Sul-Americana",shortName:"Sul-Americana",country:"Am\xE9rica do Sul",countryCode:"",region:"internacional",kind:"continental",featured:!0},{slug:"conmebol.recopa",name:"Recopa Sul-Americana",shortName:"Recopa",country:"Am\xE9rica do Sul",countryCode:"",region:"internacional",kind:"continental"},{slug:"conmebol.america",name:"Copa Am\xE9rica",shortName:"Copa Am\xE9rica",country:"Am\xE9rica do Sul",countryCode:"",region:"internacional",kind:"selecao"},{slug:"concacaf.champions",name:"Copa dos Campe\xF5es da CONCACAF",shortName:"Champions Cup",country:"Am\xE9rica do Norte",countryCode:"",region:"internacional",kind:"continental"},{slug:"concacaf.gold",name:"Copa Ouro",shortName:"Copa Ouro",country:"Am\xE9rica do Norte",countryCode:"",region:"internacional",kind:"selecao"},{slug:"caf.champions",name:"Liga dos Campe\xF5es da CAF",shortName:"CAF Champions",country:"\xC1frica",countryCode:"",region:"internacional",kind:"continental"},{slug:"caf.nations",name:"Copa das Na\xE7\xF5es Africanas",shortName:"CAN",country:"\xC1frica",countryCode:"",region:"internacional",kind:"selecao"},{slug:"afc.champions",name:"Liga dos Campe\xF5es da AFC",shortName:"AFC Champions",country:"\xC1sia",countryCode:"",region:"internacional",kind:"continental"},{slug:"afc.asian.cup",name:"Copa da \xC1sia",shortName:"Copa da \xC1sia",country:"\xC1sia",countryCode:"",region:"internacional",kind:"selecao"},{slug:"eng.1",name:"Premier League",shortName:"Premier League",country:"Inglaterra",countryCode:"gb-eng",region:"europa",kind:"liga",featured:!0},{slug:"eng.2",name:"Championship",shortName:"Championship",country:"Inglaterra",countryCode:"gb-eng",region:"europa",kind:"liga"},{slug:"eng.fa",name:"FA Cup",shortName:"FA Cup",country:"Inglaterra",countryCode:"gb-eng",region:"europa",kind:"copa"},{slug:"eng.league_cup",name:"Copa da Liga Inglesa",shortName:"Carabao Cup",country:"Inglaterra",countryCode:"gb-eng",region:"europa",kind:"copa"},{slug:"eng.w.1",name:"Women's Super League",shortName:"WSL",country:"Inglaterra",countryCode:"gb-eng",region:"europa",kind:"liga"},{slug:"esp.1",name:"LaLiga",shortName:"LaLiga",country:"Espanha",countryCode:"es",region:"europa",kind:"liga",featured:!0},{slug:"esp.2",name:"LaLiga 2",shortName:"LaLiga 2",country:"Espanha",countryCode:"es",region:"europa",kind:"liga"},{slug:"esp.copa_del_rey",name:"Copa del Rey",shortName:"Copa del Rey",country:"Espanha",countryCode:"es",region:"europa",kind:"copa"},{slug:"ita.1",name:"Serie A",shortName:"Serie A",country:"It\xE1lia",countryCode:"it",region:"europa",kind:"liga",featured:!0},{slug:"ita.2",name:"Serie B",shortName:"Serie B",country:"It\xE1lia",countryCode:"it",region:"europa",kind:"liga"},{slug:"ita.coppa_italia",name:"Coppa Italia",shortName:"Coppa Italia",country:"It\xE1lia",countryCode:"it",region:"europa",kind:"copa"},{slug:"ger.1",name:"Bundesliga",shortName:"Bundesliga",country:"Alemanha",countryCode:"de",region:"europa",kind:"liga",featured:!0},{slug:"ger.2",name:"2. Bundesliga",shortName:"2. Bundesliga",country:"Alemanha",countryCode:"de",region:"europa",kind:"liga"},{slug:"ger.dfb_pokal",name:"DFB-Pokal",shortName:"DFB-Pokal",country:"Alemanha",countryCode:"de",region:"europa",kind:"copa"},{slug:"fra.1",name:"Ligue 1",shortName:"Ligue 1",country:"Fran\xE7a",countryCode:"fr",region:"europa",kind:"liga",featured:!0},{slug:"fra.2",name:"Ligue 2",shortName:"Ligue 2",country:"Fran\xE7a",countryCode:"fr",region:"europa",kind:"liga"},{slug:"fra.coupe_de_france",name:"Coupe de France",shortName:"Coupe de France",country:"Fran\xE7a",countryCode:"fr",region:"europa",kind:"copa"},{slug:"por.1",name:"Primeira Liga",shortName:"Primeira Liga",country:"Portugal",countryCode:"pt",region:"europa",kind:"liga",featured:!0},{slug:"por.taca.portugal",name:"Ta\xE7a de Portugal",shortName:"Ta\xE7a de Portugal",country:"Portugal",countryCode:"pt",region:"europa",kind:"copa"},{slug:"ned.1",name:"Eredivisie",shortName:"Eredivisie",country:"Pa\xEDses Baixos",countryCode:"nl",region:"europa",kind:"liga",featured:!0},{slug:"bel.1",name:"Pro League",shortName:"Pro League",country:"B\xE9lgica",countryCode:"be",region:"europa",kind:"liga"},{slug:"sco.1",name:"Scottish Premiership",shortName:"Premiership",country:"Esc\xF3cia",countryCode:"gb-sct",region:"europa",kind:"liga"},{slug:"tur.1",name:"S\xFCper Lig",shortName:"S\xFCper Lig",country:"Turquia",countryCode:"tr",region:"europa",kind:"liga"},{slug:"aut.1",name:"Bundesliga Austr\xEDaca",shortName:"Bundesliga AUT",country:"\xC1ustria",countryCode:"at",region:"europa",kind:"liga"},{slug:"gre.1",name:"Super League Grega",shortName:"Super League",country:"Gr\xE9cia",countryCode:"gr",region:"europa",kind:"liga"},{slug:"den.1",name:"Superliga Dinamarquesa",shortName:"Superliga",country:"Dinamarca",countryCode:"dk",region:"europa",kind:"liga"},{slug:"rus.1",name:"Premier League Russa",shortName:"Premier Liga",country:"R\xFAssia",countryCode:"ru",region:"europa",kind:"liga"},{slug:"uefa.wchampions",name:"Liga dos Campe\xF5es Feminina",shortName:"UWCL",country:"Europa",countryCode:"",region:"europa",kind:"continental"},{slug:"bra.1",name:"Brasileir\xE3o S\xE9rie A",shortName:"Brasileir\xE3o",country:"Brasil",countryCode:"br",region:"america-sul",kind:"liga",featured:!0},{slug:"bra.2",name:"Brasileir\xE3o S\xE9rie B",shortName:"S\xE9rie B",country:"Brasil",countryCode:"br",region:"america-sul",kind:"liga"},{slug:"bra.copa_do_brazil",name:"Copa do Brasil",shortName:"Copa do Brasil",country:"Brasil",countryCode:"br",region:"america-sul",kind:"copa"},{slug:"arg.1",name:"Liga Profissional Argentina",shortName:"Liga Argentina",country:"Argentina",countryCode:"ar",region:"america-sul",kind:"liga",featured:!0},{slug:"arg.copa",name:"Copa Argentina",shortName:"Copa Argentina",country:"Argentina",countryCode:"ar",region:"america-sul",kind:"copa"},{slug:"chi.1",name:"Campeonato Chileno",shortName:"Liga Chile",country:"Chile",countryCode:"cl",region:"america-sul",kind:"liga"},{slug:"col.1",name:"Liga Colombiana",shortName:"Liga Colombia",country:"Col\xF4mbia",countryCode:"co",region:"america-sul",kind:"liga"},{slug:"uru.1",name:"Campeonato Uruguaio",shortName:"Liga Uruguay",country:"Uruguai",countryCode:"uy",region:"america-sul",kind:"liga"},{slug:"ecu.1",name:"Liga Pro Equador",shortName:"Liga Pro",country:"Equador",countryCode:"ec",region:"america-sul",kind:"liga"},{slug:"par.1",name:"Primera Divisi\xF3n Paraguai",shortName:"Primera PY",country:"Paraguai",countryCode:"py",region:"america-sul",kind:"liga"},{slug:"per.1",name:"Liga 1 Peru",shortName:"Liga 1",country:"Peru",countryCode:"pe",region:"america-sul",kind:"liga"},{slug:"usa.1",name:"Major League Soccer",shortName:"MLS",country:"Estados Unidos",countryCode:"us",region:"america-norte",kind:"liga",featured:!0},{slug:"usa.nwsl",name:"NWSL",shortName:"NWSL",country:"Estados Unidos",countryCode:"us",region:"america-norte",kind:"liga"},{slug:"mex.1",name:"Liga MX",shortName:"Liga MX",country:"M\xE9xico",countryCode:"mx",region:"america-norte",kind:"liga",featured:!0},{slug:"rsa.1",name:"Premier Soccer League",shortName:"PSL",country:"\xC1frica do Sul",countryCode:"za",region:"africa",kind:"liga"},{slug:"caf.confed",name:"Copa das Confedera\xE7\xF5es da CAF",shortName:"CAF Confed",country:"\xC1frica",countryCode:"",region:"africa",kind:"continental"},{slug:"ksa.1",name:"Saudi Pro League",shortName:"Saudi Pro League",country:"Ar\xE1bia Saudita",countryCode:"sa",region:"asia-oceania",kind:"liga"},{slug:"jpn.1",name:"J1 League",shortName:"J1 League",country:"Jap\xE3o",countryCode:"jp",region:"asia-oceania",kind:"liga"},{slug:"aus.1",name:"A-League",shortName:"A-League",country:"Austr\xE1lia",countryCode:"au",region:"asia-oceania",kind:"liga"},{slug:"ind.1",name:"Indian Super League",shortName:"ISL",country:"\xCDndia",countryCode:"in",region:"asia-oceania",kind:"liga"},{slug:"chn.1",name:"Chinese Super League",shortName:"CSL",country:"China",countryCode:"cn",region:"asia-oceania",kind:"liga"}],Re={internacional:"Internacionais",europa:"Europa","america-sul":"Am\xE9rica do Sul","america-norte":"Am\xE9rica do Norte e Central",africa:"\xC1frica","asia-oceania":"\xC1sia e Oceania"},be=we.filter(e=>e.featured).map(e=>e.slug),Nn=new Map(we.map(e=>[e.slug,e]));function P(e){return Nn.get(e)}function Ve(e,n=40){return e?`https://flagcdn.com/w${n}/${e}.png`:null}var Te=DBZ_I18N.tz;function K(e=Te){return new Intl.DateTimeFormat("en-CA",{timeZone:e,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date)}function $e(e,n){let[a,o,t]=e.split("-").map(Number),i=new Date(Date.UTC(a,o-1,t));return i.setUTCDate(i.getUTCDate()+n),i.toISOString().slice(0,10)}function xe(e){return e.replaceAll("-","")}function Pe(e){let n=new Date(e);return Number.isNaN(n.getTime())?"":new Intl.DateTimeFormat(DBZ_I18N.locale,{timeZone:Te,hour:"2-digit",minute:"2-digit"}).format(n)}function ze(e){let n=Cn(e);return new Intl.DateTimeFormat(DBZ_I18N.locale,{timeZone:Te,weekday:"long",day:"numeric",month:"long"}).format(n)}function Cn(e){if(/^\d{4}-\d{2}-\d{2}$/.test(e)){let[n,a,o]=e.split("-").map(Number);return new Date(Date.UTC(n,a-1,o,15,0,0))}return new Date(e)}function Ke(e,n,a){return e==="live"?n||"Ao vivo":e==="finished"?"Encerrado":e==="scheduled"?n||a||"A definir":a||"\u2014"}function Ze(e,n){return n||e==="post"?"finished":e==="in"?"live":e==="pre"?"scheduled":"other"}function We(e){if(!e)return;let n=e.toLowerCase();return n.includes("relegation")||n.includes("rebaix")?"relegation":n.includes("champions")?"ucl":n.includes("conference")||n.includes("confer\xEAncia")?"conference":n.includes("europa")?"europa":"other"}function _(e,n){return n||`https://a.espncdn.com/i/teamlogos/soccer/500/${e}.png`}function Be(e){return fxAv("")}function Ye(e){return e.home.aggregateScore!=null&&e.away.aggregateScore!=null}function Xe(e){return e.home.shootoutScore!=null&&e.away.shootoutScore!=null}function Qe(e){let n=[e.roundLabel,e.legLabel].filter(Boolean);return n.length?n.join(" \xB7 "):void 0}function d(e,n=""){return e==null?n:String(e)}function j(e){if(e==null||e==="")return null;let n=Number(e);return Number.isFinite(n)?n:null}function C(e){return e&&typeof e=="object"&&!Array.isArray(e)?e:void 0}function Ie(e,n){if(!e)return fxAv(n&&(n.displayName||n.fullName||n.shortName));return fxAv("")}function I(e,n,a){var t;if(!Array.isArray(e))return"\u2014";let o=e.find(i=>{if(!i||typeof i!="object")return!1;let g=i;return g.name===n||g.abbreviation===a||g.abbreviation===n});return d((t=o==null?void 0:o.displayValue)!=null?t:o==null?void 0:o.value,"\u2014")}function on(e,n){var l,s,b,y,v,f,m,k;let a=e!=null?e:{},t=(s=((l=a.leagues)!=null?l:[])[0])!=null?s:{},i=P(n),g=d(t.name,(b=i==null?void 0:i.name)!=null?b:n),c=d((y=t.abbreviation)!=null?y:t.shortName,(v=i==null?void 0:i.shortName)!=null?v:g),u=(f=t.logos)!=null?f:[],r=(m=u.find(w=>{var $;return($=w.rel)==null?void 0:$.includes("dark")}))!=null?m:u[0],p=(k=a.events)!=null?k:[];return{leagueSlug:n,leagueName:g,leagueShortName:c,leagueLogo:r==null?void 0:r.href,matches:p.map(w=>ve(w,n,g,c,r==null?void 0:r.href)).filter(Boolean)}}function sn(e){var i,g,c,u,r;let a=(g=((i=C(e))!=null?i:{}).sports)!=null?g:[],o=(c=a.find(p=>d(p.slug).toLowerCase()==="soccer"))!=null?c:a[0];return((r=(u=C(o))==null?void 0:u.leagues)!=null?r:[]).map(p=>{var m,k,w,$,L;let l=d((m=p.slug)!=null?m:p.tag).toLowerCase();if(!l)return null;let s=P(l),b=(k=s==null?void 0:s.name)!=null?k:d(p.name,l),y=($=s==null?void 0:s.shortName)!=null?$:d((w=p.shortName)!=null?w:p.abbreviation,b),f=((L=p.events)!=null?L:[]).map(E=>ve(E,l,b,y)).filter(E=>!!E);return f.length===0?null:{leagueSlug:l,leagueName:b,leagueShortName:y,matches:f}}).filter(p=>!!p)}function ve(e,n,a,o,t){var J,G,Z,W,Y,X,Q,ee,ne,ae,te,oe,se,re,ie,ce,le,ue,de,ge,N;let g=(G=((J=e.competitions)!=null?J:[])[0])!=null?G:e,c=(Z=g.competitors)!=null?Z:[],u=(W=c.find(A=>A.homeAway==="home"))!=null?W:c[0],r=(Y=c.find(A=>A.homeAway==="away"))!=null?Y:c[1];if(!u||!r)return null;let p=(Q=(X=C(e.fullStatus))!=null?X:C(g.fullStatus))!=null?Q:{},l=(ne=(ee=C(e.status))!=null?ee:C(g.status))!=null?ne:p,s=(te=(ae=C(l.type))!=null?ae:C(p.type))!=null?te:{},b=d(s.state)||(typeof e.status=="string"?e.status:"")||d(e.summary),y=Ze(b,!!s.completed),v=(se=(oe=g.notes)!=null?oe:e.notes)!=null?se:[],f=(ie=(re=C(g.venue))!=null?re:C(e.venue))!=null?ie:{},m=d(f.displayName||f.fullName||e.location)||void 0,k=d(l.displayClock||p.displayClock||s.shortDetail||e.clock||e.summary),w=Sn((ce=g.series)!=null?ce:e.series),$=Mn(v,g,e),L=en(u,w),E=en(r,w);En(L,E,$);let F=Tn(g,e,w,$);return{id:d((le=e.id)!=null?le:g.id),leagueSlug:n,leagueName:a,leagueShortName:o,leagueLogo:t,date:d((de=(ue=e.date)!=null?ue:g.date)!=null?de:g.startDate),status:y,clock:y==="live"?k||"Ao vivo":y==="scheduled"?void 0:d(s.shortDetail||s.detail||e.summary),detail:d(s.detail||s.shortDetail||s.description||e.summary),venue:m,home:L,away:E,note:$,period:(N=j((ge=l.period)!=null?ge:p.period))!=null?N:void 0,statusName:d(s.name)||void 0,statusDescription:d(s.description)||void 0,...F}}function en(e,n){var p,l,s,b,y,v,f,m,k,w,$,L,E,F,J;let a=(p=C(e.team))!=null?p:e,o=d((l=a.id)!=null?l:e.id),t=(s=e.records)!=null?s:[],i=d((v=(y=(b=a.logoDark)!=null?b:e.logoDark)!=null?y:a.logo)!=null?v:e.logo)||void 0,c=((f=n==null?void 0:n.competitors)!=null?f:[]).find(G=>d(G.id)===o),u=j(e.aggregateScore);u==null&&(u=j(c==null?void 0:c.aggregateScore));let r=!!e.winner;return n!=null&&n.completed&&c&&"winner"in c&&(r=!!c.winner),{id:o,name:d((k=(m=a.displayName)!=null?m:a.name)!=null?k:e.displayName,"Time"),shortName:d(($=(w=a.shortDisplayName)!=null?w:a.abbreviation)!=null?$:a.name,"\u2014"),abbreviation:d((L=a.abbreviation)!=null?L:e.abbreviation,"FC"),logo:_(o,i),score:j((E=e.score)!=null?E:a.score),winner:r,form:d(e.form)||void 0,record:(F=t[0])==null?void 0:F.summary,shootoutScore:j((J=e.shootoutScore)!=null?J:e.shootoutPts),aggregateScore:u}}function Sn(e){return Array.isArray(e)?C(e[0]):C(e)}function Mn(e,n,a){var t,i;return d(((t=e[0])==null?void 0:t.text)||((i=e[0])==null?void 0:i.headline))||d(a.note)||d(n.note)||void 0}function nn(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase()}function an(e,n){let a=nn(e);return[n.name,n.shortName,n.abbreviation].map(t=>nn(t).trim()).filter(t=>t.length>=3).sort((t,i)=>i.length-t.length).some(t=>a.includes(t))}function En(e,n,a){if(e.aggregateScore!=null&&n.aggregateScore!=null||!a)return;let o=a.match(/(\d+)\s*[-–xX]\s*(\d+)\s*no agregado/i);if(!o)return;let t=Number(o[1]),i=Number(o[2]);if(!Number.isFinite(t)||!Number.isFinite(i))return;let g=an(a,e),c=an(a,n);g!==c&&(g?(e.aggregateScore=t,n.aggregateScore=i):(e.aggregateScore=i,n.aggregateScore=t))}var An={"round of 16":"Oitavas","round of 32":"16-avos",quarterfinals:"Quartas",semifinals:"Semifinais",final:"Final",finals:"Finais","qualifying round":"Eliminat\xF3ria","knockout round playoffs":"Playoffs",playoffs:"Playoffs"};function Rn(e){var n;return(n=An[e.toLowerCase().trim()])!=null?n:e}function Tn(e,n,a,o){var b,y;let t=(b=C(e.leg))!=null?b:C(n.leg),i,g,c=j(t==null?void 0:t.value);(c===1||c===2)&&(i=c,g=d((t==null?void 0:t.text)||(t==null?void 0:t.displayValue))||(c===1?"Ida":"Volta"));let u=j(a==null?void 0:a.leg);!i&&(u===1||u===2)&&(i=u,g=u===1?"Ida":"Volta"),!i&&o&&(/\bvolta\b/i.test(o)?(i=2,g="Volta"):/\bida\b/i.test(o)&&(i=1,g="Ida"));let r,p=d((y=e.altGameNote)!=null?y:n.altGameNote);if(p.includes(",")){let v=p.split(",").slice(1).join(",").trim();v&&(r=v)}!r&&(a!=null&&a.title)&&(r=Rn(d(a.title)));let s=j(a==null?void 0:a.totalCompetitions)===2||i!=null||/\b(ida|volta|agregado)\b/i.test(o!=null?o:"");return{leg:i,legLabel:s?g:void 0,roundLabel:s?r:void 0,twoLegged:s||void 0}}function rn(e){var i,g,c,u,r;let n=e!=null?e:{},a=(i=n.children)!=null?i:[],o=a.length>0?a:[n],t=[];for(let p of o){let l=(g=p.standings)!=null?g:p,s=(c=l.entries)!=null?c:[];if(s.length===0)continue;let b=s.map(y=>{var $,L,E,F;let v=($=y.team)!=null?$:{},f=y.stats,m=y.note,k=d(v.id),w=(L=v.logos)!=null?L:[];return{rank:Number(I(f,"rank","R"))||0,teamId:k,teamName:d((E=v.displayName)!=null?E:v.name),abbreviation:d(v.abbreviation),logo:_(k,(F=w[0])==null?void 0:F.href),stats:{played:I(f,"gamesPlayed","GP"),wins:I(f,"wins","W"),draws:I(f,"ties","D"),losses:I(f,"losses","L"),for:I(f,"pointsFor","F"),against:I(f,"pointsAgainst","A"),gd:I(f,"pointDifferential","GD"),points:I(f,"points","P")},note:m==null?void 0:m.description,noteKind:We(m==null?void 0:m.description)}});b.sort((y,v)=>y.rank-v.rank),t.push({name:d((r=(u=p.name)!=null?u:l.displayName)!=null?r:l.name,"Classifica\xE7\xE3o"),rows:b})}return t}function xn(e,n){var r,p,l,s,b,y,v,f;let a=(r=e.athlete)!=null?r:{},o=(p=a.team)!=null?p:{},t=d(a.id);if(!t)return null;let i=(l=o.logos)!=null?l:[],g=Number((s=e.value)!=null?s:0),u=(y=d((b=e.shortDisplayValue)!=null?b:e.displayValue).match(/M:\s*(\d+)/i))==null?void 0:y[1];return{rank:n,athleteId:t,name:d(a.displayName,"Jogador"),shortName:d(a.shortName,d(a.displayName)),teamName:d((v=o.displayName)!=null?v:o.name),teamLogo:(f=i[0])!=null&&f.href?_(d(o.id),i[0].href):o.id?_(d(o.id)):void 0,headshot:Be(t),value:Number.isFinite(g)?g:0,label:d(e.displayValue),played:u}}function cn(e){var g;let a=(g=(e!=null?e:{}).stats)!=null?g:[],o=a.find(c=>d(c.name).toLowerCase().includes("goal")),t=a.find(c=>d(c.name).toLowerCase().includes("assist")),i=c=>{var r;return((r=c==null?void 0:c.leaders)!=null?r:[]).map((p,l)=>xn(p,l+1)).filter(p=>!!p).slice(0,15)};return{goals:i(o),assists:i(t)}}function ln(e,n,a){var Z,W,Y,X,Q,ee,ne,ae,te,oe,se,re,ie,ce,le,ue,de,ge;let o=e!=null?e:{},t=(Z=o.header)!=null?Z:{},i=(W=t.competitions)!=null?W:[],g=(Y=t.league)!=null?Y:{},c=(X=g.logos)!=null?X:[],u=(Q=c.find(N=>{var A;return(A=N.rel)==null?void 0:A.includes("dark")}))!=null?Q:c[0],r=P(n),p=d(g.name,(ee=r==null?void 0:r.name)!=null?ee:n),l=d((ne=g.abbreviation)!=null?ne:g.shortName,(ae=r==null?void 0:r.shortName)!=null?ae:p),s=null;if((i[0]||t.id)&&(s=ve({...t,competitions:i,id:t.id,date:(oe=(te=i[0])==null?void 0:te.date)!=null?oe:t.date},n,p,l,u==null?void 0:u.href)),s=(se=s!=null?s:a)!=null?se:null,!s)return null;let y=(ie=((re=o.boxscore)!=null?re:{}).teams)!=null?ie:[],v=tn(y,s.home.id,"home"),f=tn(y,s.away.id,"away"),m=Pn(v,f),w=((ce=o.keyEvents)!=null?ce:[]).map((N,A)=>{var B,O,z,me,pe,he,fe,ye;let T=(B=N.type)!=null?B:{},Je=(O=N.clock)!=null?O:{},ke=(z=N.team)!=null?z:{},x=(pe=((me=N.participants)!=null?me:[])[0])==null?void 0:pe.athlete,V=x!=null&&x.id?d(x.id):void 0;return{parts:(Array.isArray(N.participants)?N.participants:[]).map(function(p){var t=p&&p.athlete;return t?{id:d(t.id),name:d(t.displayName||t.fullName)}:null}).filter(Boolean),period:+((N.period||{}).number)||0,id:d(N.id,String(A)),type:d((he=T.text)!=null?he:T.type,"Evento"),typeId:d((fe=T.type)!=null?fe:T.id),clock:d(Je.displayValue),text:d((ye=N.shortText)!=null?ye:N.text),teamId:ke.id?d(ke.id):void 0,player:x!=null&&x.displayName?d(x.displayName):void 0,playerId:V,headshot:V?Ie(V,x):void 0,scoring:!!N.scoringPlay,yellow:!!N.yellowCard||d(T.type).includes("yellow"),red:!!N.redCard||d(T.type).includes("red"),ownGoal:!!N.ownGoal||d(T.type).includes("own-goal"),penalty:!!N.penaltyKick||d(T.type).includes("penalty")}}),L=((le=o.rosters)!=null?le:[]).map(N=>{var Ae,x,V;let A=(Ae=N.team)!=null?Ae:{},T=d(A.id),ke=((x=N.roster)!=null?x:[]).map(B=>{var pe,he,fe,ye;let O=(pe=B.athlete)!=null?pe:{},z=(he=B.position)!=null?he:{},me=d(O.id);return{id:me,name:d((fe=O.displayName)!=null?fe:O.fullName,"Jogador"),jersey:d(B.jersey,"\u2014"),starter:!!B.starter,position:d((ye=z.displayName)!=null?ye:z.name),positionAbbr:d(z.abbreviation),formationPlace:B.formationPlace?d(B.formationPlace):void 0,subbedIn:!!B.subbedIn,subbedOut:!!B.subbedOut,captain:!!B.captain,stats:fxStats(B.stats),headshot:Ie(me,O)}});return{teamId:T,color:d(A.color),teamName:d((V=A.displayName)!=null?V:A.name),abbreviation:d(A.abbreviation),logo:_(T,d(A.logo)||void 0),formation:d(N.formation,"\u2014"),homeAway:N.homeAway==="away"?"away":"home",players:ke}}),E=(ue=o.gameInfo)!=null?ue:{},F=(de=E.venue)!=null?de:{},G=((ge=E.officials)!=null?ge:[]).find(N=>{var A,T;return((T=(A=N.position)==null?void 0:A.name)!=null?T:"").toLowerCase().includes("ref")});return F.fullName&&!s.venue&&(s.venue=d(F.fullName)),{match:s,events:w,comments:lxRawComments(o),stats:m,lineups:L,attendance:E.attendance?d(E.attendance):void 0,referee:G==null?void 0:G.displayName}}function tn(e,n,a){var t,i;let o=(t=e.find(g=>{var c;return d((c=g.team)==null?void 0:c.id)===n}))!=null?t:a==="home"?e[0]:e[1];return(i=o==null?void 0:o.statistics)!=null?i:[]}function Pn(e,n){var i,g;let a=new Map;for(let c of e){let u=d(c.name);if(!u)continue;let r=d(c.displayValue,"0");a.set(u,{name:u,label:d((i=c.label)!=null?i:c.displayName,u),home:r,away:"0",homeNum:Fe(r),awayNum:0})}for(let c of n){let u=d(c.name);if(!u)continue;let r=d(c.displayValue,"0"),p=a.get(u);p?(p.away=r,p.awayNum=Fe(r)):a.set(u,{name:u,label:d((g=c.label)!=null?g:c.displayName,u),home:"0",away:r,homeNum:0,awayNum:Fe(r)})}let o=["possessionPct","totalShots","shotsOnTarget","wonCorners","foulsCommitted","offsides","yellowCards","redCards","accuratePasses","totalPasses","passPct","saves"],t=[...a.values()];return t.sort((c,u)=>{let r=o.indexOf(c.name),p=o.indexOf(u.name);return r===-1&&p===-1?0:r===-1?1:p===-1?-1:r-p}),t.filter(c=>o.includes(c.name)||c.homeNum+c.awayNum>0).slice(0,12)}function Fe(e){let n=Number(String(e).replace("%","").replace(",","."));return Number.isFinite(n)?n:0}function un(e,n){var p,l,s,b,y,v,f,m,k,w,$;let a=e!=null?e:{},o=(p=a.team)!=null?p:a,t=d(o.id);if(!t)return null;let i=(l=o.logos)!=null?l:[],g=o.record,c=(s=o.nextEvent)==null?void 0:s[0],u=P(n),r;return c&&(r=(v=ve(c,n,(b=u==null?void 0:u.name)!=null?b:n,(y=u==null?void 0:u.shortName)!=null?y:n))!=null?v:void 0),{id:t,leagueSlug:n,name:d((f=o.displayName)!=null?f:o.name),shortName:d((m=o.shortDisplayName)!=null?m:o.name),abbreviation:d(o.abbreviation),logo:_(t,(k=i[0])==null?void 0:k.href),color:o.color?d(o.color):void 0,standingSummary:o.standingSummary?d(o.standingSummary):void 0,record:($=(w=g==null?void 0:g.items)==null?void 0:w[0])==null?void 0:$.summary,nextMatch:r}}function dn(e){var g,c,u,r,p,l,s,b,y;let n=(g=C(e))!=null?g:{},a=(c=C(n.team))!=null?c:{},o=(r=(u=n.athletes)!=null?u:a.athletes)!=null?r:[];if(o.length>0){let v=C(o[0]);v&&Array.isArray(v.items)&&(o=o.flatMap(f=>{let m=C(f);return Array.isArray(m==null?void 0:m.items)?m.items:[]}))}let t=[],i=new Set;for(let v of o){let f=C(v);if(!f)continue;let m=d(f.id);if(!m||i.has(m))continue;i.add(m);let k=(p=C(f.position))!=null?p:{},w=C(f.flag),$=j(f.age);t.push({id:m,name:d((l=f.displayName)!=null?l:f.fullName,"Jogador"),shortName:d((s=f.shortName)!=null?s:f.displayName,"Jogador"),jersey:d((b=f.jersey)!=null?b:f.jerseyNumber,"\u2014"),position:d((y=k.displayName)!=null?y:k.name,"Jogador"),positionAbbr:d(k.abbreviation,"?"),headshot:Ie(m,f),age:$!=null?$:void 0,nationality:d(f.citizenship||(w==null?void 0:w.alt))||void 0,flag:d(w==null?void 0:w.href)||void 0,height:d(f.displayHeight)||void 0})}return t}function gn(e,n){var c,u,r;let a=e!=null?e:{},o=(c=a.events)!=null?c:[],t=P(n),i=(u=a.team)!=null?u:{},g=d(i.displayName,(r=t==null?void 0:t.name)!=null?r:n);return o.map(p=>{var y,v,f,m,k,w,$,L;let l=(y=p.league)!=null?y:{},s=d((f=(v=l.slug)!=null?v:l.abbreviation)!=null?f:n,n).toLowerCase(),b=(k=(m=P(s))==null?void 0:m.slug)!=null?k:n;return ve(p,b,d(l.name,(w=t==null?void 0:t.name)!=null?w:n),d(($=l.abbreviation)!=null?$:l.shortName,(L=t==null?void 0:t.shortName)!=null?L:g))}).filter(p=>!!p)}var Bn="https://site.web.api.espn.com",Fn=DBZ_I18N.espn,fn="dbzscore-favs",Ue="dbzscore-alerts",mn=new Map,M,je=!1;function h(e){return String(e!=null?e:"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function S(e,n=document){return n.querySelector(e)}/* ===== Segurança dos dados: cópia salva no aparelho (usada só quando a fonte falha) ===== */
var DBC_P="dbzc:",DBC_I="dbzc-idx",DBC_MAX=100,DBC_AGE=2592e5,DBC_LAST={};
function dbcIdx(){try{var x=JSON.parse(localStorage.getItem(DBC_I)||"[]");return Array.isArray(x)?x:[]}catch(x){return[]}}
function dbcStore(k,data){
  try{
    var now=Date.now();
    if(DBC_LAST[k]&&now-DBC_LAST[k]<6e4)return;
    var js=JSON.stringify(data);
    if(!js||js.length>6e5)return;
    var ix=[];
    dbcIdx().forEach(function(r){
      if(r.k!==k&&now-r.ts<DBC_AGE)ix.push(r);
      else if(r.k!==k)try{localStorage.removeItem(DBC_P+r.k)}catch(x){}
    });
    ix.push({k:k,ts:now});
    while(ix.length>DBC_MAX){var o=ix.shift();try{localStorage.removeItem(DBC_P+o.k)}catch(x){}}
    try{localStorage.setItem(DBC_P+k,js)}
    catch(x){
      var old=ix.slice(0,-1),n=Math.ceil(old.length/2);
      old.slice(0,n).forEach(function(r){try{localStorage.removeItem(DBC_P+r.k)}catch(y){}});
      ix=old.slice(n).concat(ix.slice(-1));
      try{localStorage.setItem(DBC_P+k,js)}catch(y){return}
    }
    localStorage.setItem(DBC_I,JSON.stringify(ix));
    DBC_LAST[k]=now;
  }catch(x){}
}
function dbcLoad(k){
  try{
    var r=dbcIdx().find(function(x){return x.k===k}),raw=localStorage.getItem(DBC_P+k);
    if(!r||!raw||Date.now()-r.ts>DBC_AGE)return null;
    return{ts:r.ts,data:JSON.parse(raw)};
  }catch(x){return null}
}
function dbcBar(msg){
  var el=document.getElementById("stale-bar");
  if(!el){el=document.createElement("div");el.id="stale-bar";el.addEventListener("click",dbcFresh);document.body.appendChild(el)}
  el.textContent=msg;
}
function dbcStale(ts){
  var t=new Date(ts);
  dbcBar("Fonte de dados fora do ar. Mostrando dados salvos às "+t.toLocaleTimeString(DBZ_I18N.locale,{hour:"2-digit",minute:"2-digit"})+" (toque para fechar)");
}
function dbcReserve(){dbcBar("Fonte principal fora do ar. Usando a fonte reserva (API-Football). Alguns dados podem faltar. Toque para fechar.")}
function dbcFresh(){var el=document.getElementById("stale-bar");if(el)el.remove()}
async function q(e,n){
  var k=e.startsWith("http")?e:Bn+e+(e.includes("?")?"&":"?")+Fn;
  if(/summary\?event=af\d+/.test(e)){
    try{var r0=await afAdapt(e);dbcReserve();return r0}
    catch(x0){var s0=dbcLoad(k);if(s0){dbcStale(s0.ts);return s0.data}throw x0}
  }
  try{return await q0(e,n)}
  catch(err){
    var msg=String(err&&err.message||""),down=/Sem conex/.test(msg)||/\((403|429|5\d\d)\)/.test(msg);
    if(down){
      DBC_UNTIL=Date.now()+45e3;
      try{var r=await afAdapt(e);dbcReserve();return r}catch(x){}
    }
    var sv=dbcLoad(k);
    if(sv){dbcStale(sv.ts);return sv.data}
    throw err;
  }
}
/* ===== Fonte reserva: API-Football (só entra quando a ESPN falha) ===== */
var AF_HOST="https://v3.football.api-sports.io",AF_LIMIT=95,AF_MEM={},AF_BAD=false,DBC_UNTIL=0;
var AF_LEAGUE={"fifa.world":1,"fifa.wwc":8,"fifa.cwc":15,"uefa.champions":2,"uefa.europa":3,"uefa.europa.conf":848,"uefa.nations":5,"uefa.euro":4,
  "conmebol.libertadores":13,"conmebol.sudamericana":11,"conmebol.america":9,"concacaf.champions":16,"concacaf.gold":22,"caf.champions":12,
  "caf.nations":6,"afc.champions":17,"afc.asian.cup":7,"eng.1":39,"eng.2":40,"eng.fa":45,"eng.w.1":44,"esp.1":140,"esp.2":141,"ita.1":135,
  "ita.2":136,"ger.1":78,"ger.2":79,"fra.1":61,"fra.2":62,"por.1":94,"por.taca.portugal":96,"ned.1":88,"bel.1":144,"sco.1":179,"tur.1":203,
  "aut.1":218,"gre.1":197,"den.1":119,"rus.1":235,"uefa.wchampions":525,"bra.1":71,"bra.2":72,"arg.1":128,"arg.copa":130,"chi.1":265,
  "col.1":239,"uru.1":268,"ecu.1":242,"par.1":250,"per.1":281,"usa.1":253,"usa.nwsl":254,"mex.1":262,"rsa.1":288,"caf.confed":20,
  "ksa.1":307,"jpn.1":98,"aus.1":188,"ind.1":323};
var AF_POS={G:["Goleiro","G"],D:["Defensor","D"],M:["Meio-campista","M"],F:["Atacante","F"]};
var AF_STAT={"Ball Possession":["possessionPct","Posse de bola"],"Total Shots":["totalShots","Finalizações"],"Shots on Goal":["shotsOnTarget","No alvo"],
  "Corner Kicks":["wonCorners","Escanteios"],"Fouls":["foulsCommitted","Faltas"],"Offsides":["offsides","Impedimentos"],"Yellow Cards":["yellowCards","Cartões amarelos"],
  "Red Cards":["redCards","Cartões vermelhos"],"Passes accurate":["accuratePasses","Passes certos"],"Total passes":["totalPasses","Passes"],
  "Passes %":["passPct","Precisão de passe"],"Goalkeeper Saves":["saves","Defesas"]};

function afKey(){return typeof window!=="undefined"&&window.DBZ_APIFOOTBALL_KEY?String(window.DBZ_APIFOOTBALL_KEY).trim():""}
async function afGet(path,ttl){
  var key=afKey();
  if(!key||AF_BAD)throw new Error("Fonte reserva indisponível");
  var m=AF_MEM[path];
  if(m&&m.exp>Date.now())return m.p;
  var day=K(),st={};
  try{st=JSON.parse(localStorage.getItem("dbzscore-afq")||"{}")}catch(x){}
  if(st.d!==day)st={d:day,n:0};
  if(st.n>=AF_LIMIT)throw new Error("Limite diário da fonte reserva atingido");
  st.n++;
  try{localStorage.setItem("dbzscore-afq",JSON.stringify(st))}catch(x){}
  var url=AF_HOST+path,init={headers:{Accept:"application/json"}};
  if(typeof AndroidNotify!=="undefined")url+=(path.indexOf("?")>=0?"&":"?")+"dbzkey="+encodeURIComponent(key);
  else init.headers["x-apisports-key"]=key;
  /* pedidos iguais feitos ao mesmo tempo compartilham a mesma consulta (poupa a cota diária) */
  var pr=(async function(){
    var r=await fetch(url,init);
    if(!r.ok)throw new Error("Fonte reserva: HTTP "+r.status);
    var j=await r.json(),er=j&&j.errors;
    if(er&&(Array.isArray(er)?er.length:Object.keys(er).length)){
      if(/token|key/i.test(JSON.stringify(er)))AF_BAD=true;
      throw new Error("Fonte reserva recusou o pedido: "+JSON.stringify(er).slice(0,140));
    }
    return j;
  })();
  AF_MEM[path]={exp:Date.now()+ttl,p:pr};
  try{return await pr}catch(x){delete AF_MEM[path];throw x}
}
function afState(sh){
  if(/^(1H|2H|ET|BT|P|LIVE|INT|SUSP|HT)$/.test(sh))return"in";
  if(/^(FT|AET|PEN)$/.test(sh))return"post";
  return"pre";
}
var AF_DET={FT:"Fim",AET:"Fim (prorrog.)",PEN:"Fim (pênaltis)",HT:"Intervalo",PST:"Adiado",CANC:"Cancelado",ABD:"Abandonado",SUSP:"Suspenso",AWD:"W.O.",WO:"W.O."};
function afClock(s){
  if(s.short==="HT")return"Intervalo";
  if(s.elapsed==null)return"";
  return s.elapsed+"'"+(s.extra?"+"+s.extra+"'":"");
}
function afAbbr(n){return String(n||"").replace(/[^A-Za-zÀ-ÿ]/g,"").slice(0,3).toUpperCase()||"FC"}
function afTeam(t,side,goals){
  return{homeAway:side,id:"af"+t.id,score:goals==null?null:goals,winner:!!t.winner,
    team:{id:"af"+t.id,displayName:t.name,shortDisplayName:t.name,abbreviation:afAbbr(t.name),logo:t.logo}};
}
function afComp(f){
  var s=f.fixture.status||{},st=afState(s.short);
  return{id:"af"+f.fixture.id,date:f.fixture.date,
    status:{type:{state:st,completed:st==="post",description:AF_DET[s.short]||s.long||"",detail:AF_DET[s.short]||s.long||"",shortDetail:AF_DET[s.short]||afClock(s)||s.long||"",name:s.short},
      displayClock:afClock(s),period:s.short==="2H"?2:s.short==="1H"?1:0},
    venue:{displayName:f.fixture.venue&&f.fixture.venue.name||""},
    competitors:[afTeam(f.teams.home,"home",f.goals.home),afTeam(f.teams.away,"away",f.goals.away)]};
}
function afEventOf(f){
  var c=afComp(f);
  return{id:c.id,date:c.date,status:c.status,venue:c.venue,competitions:[c]};
}
function afHead(f){
  var l=f.league||{};
  return{name:l.name,abbreviation:l.name,logos:l.logo?[{href:l.logo,rel:["dark"]}]:[]};
}
async function afDay(date){
  var today=K(),ttl=date===today?9e4:date<today?36e5:9e5;
  var j=await afGet("/fixtures?date="+date+"&timezone="+encodeURIComponent(DBZ_I18N.tz),ttl);
  return Array.isArray(j.response)?j.response:[];
}
async function afScoreboard(slug,date){
  var lid=AF_LEAGUE[slug];
  if(!lid)throw new Error("Competição sem equivalente na fonte reserva");
  var list=(await afDay(date)).filter(function(f){return f.league&&f.league.id===lid});
  return{leagues:[list.length?afHead(list[0]):{}],events:list.map(afEventOf)};
}
function afPhoto(id){return"https://media.api-sports.io/football/players/"+id+".png"}
function afAth(p){
  return p&&p.id?{athlete:{id:"af"+p.id,displayName:p.name||"",headshot:{href:afPhoto(p.id)}}}:null;
}
function afEvents(f){
  var out=[];
  (f.events||[]).forEach(function(x,i){
    var ty=x.type,dt=x.detail||"",el=x.time&&x.time.elapsed,ex=x.time&&x.time.extra;
    var clock=el==null?"":el+"'"+(ex?"+"+ex+"'":""),per=el==null?1:el<=45?1:el<=90?2:3;
    var pl=x.player&&x.player.name||"",as=x.assist&&x.assist.name||"",type,text,sc=false,parts;
    if(ty==="Goal"){
      if(/missed/i.test(dt)){type="Penalty - Missed";text="Pênalti perdido: "+pl+"."}
      else{
        sc=true;
        if(/own/i.test(dt)){type="Own Goal";text="Gol contra! "+pl+"."}
        else if(/penalty/i.test(dt)){type="Penalty - Scored";text="Gol de pênalti! "+pl+"."}
        else{type="Goal";text="Gol! "+pl+"."+(as?" Assistência de "+as+".":"")}
      }
      parts=[afAth(x.player),afAth(x.assist)];
    }else if(ty==="Card"){
      var red=/red|second yellow/i.test(dt);
      type=red?"Red Card":"Yellow Card";text=(red?"Cartão vermelho para ":"Cartão amarelo para ")+pl+".";
      parts=[afAth(x.player)];
    }else if(ty==="subst"){
      type="Substitution";text="Substituição. "+as+" substitui "+pl;
      parts=[afAth(x.assist),afAth(x.player)];
    }else if(ty==="Var"){
      type="VAR";text="VAR: "+dt+(pl?" ("+pl+")":"");parts=[afAth(x.player)];
    }else return;
    out.push({id:String(i),type:{id:type.toLowerCase().replace(/\s+/g,"-"),text:type},clock:{displayValue:clock},period:{number:per},
      team:{id:"af"+(x.team&&x.team.id)},participants:parts.filter(Boolean),text:text,shortText:text,scoringPlay:sc});
  });
  return out;
}
function afRosters(f){
  var subs={},sin={};
  (f.events||[]).forEach(function(x){
    if(x.type==="subst"){if(x.player&&x.player.id)subs[x.player.id]=1;if(x.assist&&x.assist.id)sin[x.assist.id]=1}
  });
  return(f.lineups||[]).map(function(l){
    var t=l.team||{},tid=String(t.id),home=String(f.teams.home.id)===tid,
      xi=(l.startXI||[]).map(function(z){return z.player||{}}).slice();
    var order=xi.map(function(p,i){
      var g=String(p.grid||"").split(":");return{p:p,i:i,r:+g[0]||99,c:+g[1]||0};
    }).sort(function(a,b){return a.r-b.r||a.c-b.c||a.i-b.i});
    var place={};order.forEach(function(o,k){place[o.p.id]=k+1});
    var mk=function(p,starter){
      var ps=AF_POS[p.pos]||[p.pos||"",p.pos||""];
      return{athlete:{id:"af"+p.id,displayName:p.name,headshot:{href:afPhoto(p.id)}},jersey:String(p.number!=null?p.number:""),starter:starter,
        position:{displayName:ps[0],abbreviation:ps[1]},formationPlace:starter?place[p.id]:undefined,subbedOut:!!subs[p.id],subbedIn:!!sin[p.id]};
    };
    return{team:{id:"af"+t.id,displayName:t.name,abbreviation:afAbbr(t.name),logo:t.logo},formation:l.formation||"",homeAway:home?"home":"away",
      roster:xi.map(function(p){return mk(p,true)}).concat((l.substitutes||[]).map(function(z){return mk(z.player||{},false)}))};
  });
}
function afBox(f){
  return(f.statistics||[]).map(function(t){
    return{team:{id:"af"+(t.team&&t.team.id)},statistics:(t.statistics||[]).filter(function(s){return AF_STAT[s.type]}).map(function(s){
      var m=AF_STAT[s.type];return{name:m[0],label:m[1],displayValue:s.value==null?"0":String(s.value)};
    })};
  });
}
async function afSummary(id){
  var j=await afGet("/fixtures?id="+id,6e4),f=(j.response||[])[0];
  if(!f)throw new Error("Jogo não encontrado na fonte reserva");
  var evs=afEvents(f);
  var comm=evs.map(function(x,i){
    return{sequence:i,time:x.clock,text:x.text,play:{type:x.type,team:x.team,participants:x.participants,scoringPlay:x.scoringPlay}};
  });
  return{header:{id:"af"+f.fixture.id,competitions:[afComp(f)],league:afHead(f)},boxscore:{teams:afBox(f)},keyEvents:evs,commentary:comm,
    rosters:afRosters(f),gameInfo:{venue:{fullName:f.fixture.venue&&f.fixture.venue.name||""},
      officials:f.fixture.referee?[{displayName:f.fixture.referee,position:{name:"Referee"}}]:[]}};
}
async function afStandings(slug,qs){
  var lid=AF_LEAGUE[slug];
  if(!lid)throw new Error("Competição sem equivalente na fonte reserva");
  var d=new Date(),y=d.getFullYear(),cal=/^(bra|arg|chi|col|uru|ecu|par|per|usa|jpn|conmebol|fifa|uefa\.euro)/.test(slug),
    sm=String(qs||"").match(/season=(\d{4})/),season=sm?+sm[1]:(cal||d.getMonth()>=6?y:y-1);
  var rows=null;
  for(var k=0;k<2&&!rows;k++){
    var j=await afGet("/standings?league="+lid+"&season="+(season-k),36e5),r=j.response&&j.response[0];
    if(r&&r.league&&r.league.standings&&r.league.standings.length)rows=r.league.standings;
  }
  if(!rows)throw new Error("Tabela indisponível na fonte reserva");
  return{children:rows.map(function(g){
    return{name:g[0]&&g[0].group||"Classificação",standings:{entries:g.map(function(x){
      var a=x.all||{},gl=a.goals||{},t=x.team||{},nm=function(n,v){return{name:n,value:v}};
      return{team:{id:"af"+t.id,displayName:t.name,name:t.name,abbreviation:afAbbr(t.name),logos:[{href:t.logo}]},
        note:x.description?{description:x.description}:undefined,
        stats:[nm("rank",x.rank),nm("gamesPlayed",a.played),nm("wins",a.win),nm("ties",a.draw),nm("losses",a.lose),
          nm("pointsFor",gl.for),nm("pointsAgainst",gl.against),nm("pointDifferential",x.goalsDiff),nm("points",x.points)]};
    })}};
  })};
}
async function afAdapt(e){
  var m=e.match(/\/sports\/soccer\/([^/?]+)\/scoreboard\?(.*)$/);
  if(m&&!/limit=/.test(m[2])){
    var dm=m[2].match(/dates=(\d{4})(\d{2})(\d{2})/);
    return afScoreboard(m[1],dm?dm[1]+"-"+dm[2]+"-"+dm[3]:K());
  }
  m=e.match(/\/sports\/soccer\/([^/?]+)\/summary\?event=af(\d+)/);
  if(m)return afSummary(m[2]);
  m=e.match(/\/apis\/v2\/sports\/soccer\/([^/?]+)\/standings\?(.*)$/);
  if(m)return afStandings(m[1],m[2]);
  throw new Error("Sem equivalente na fonte reserva");
}
async function q0(e,n){let a=e.startsWith("http")?e:`${Bn}${e}${e.includes("?")?"&":"?"}${Fn}`,o=Date.now(),t=mn.get(a),i=n==="scoreboard"?2e4:n==="summary"?25e3:n==="standings"?3e5:18e4;if(t&&t.exp>o)return t.data;if(o<DBC_UNTIL)throw new Error("Sem conex\xE3o com os dados. Verifique a internet e tente de novo.");let g,HD={headers:{Accept:"application/json","Accept-Language":DBZ_I18N.al}};try{g=await fetch(a,HD)}catch(er){if(a.startsWith(Bn)){try{g=await fetch("https://site.api.espn.com"+a.slice(Bn.length),HD)}catch(er2){throw new Error("Sem conex\xE3o com os dados. Verifique a internet e tente de novo.")}}else throw new Error("Sem conex\xE3o com os dados. Verifique a internet e tente de novo.")}if(!g.ok)throw new Error(`N\xE3o foi poss\xEDvel carregar dados (${g.status})`);let c=await g.json();return mn.set(a,{exp:o+i,data:c}),dbcStore(a,c),dbcFresh(),c}function yn(e){return/^[a-z0-9][a-z0-9._-]*$/i.test(e)}function U(){try{let e=localStorage.getItem(fn);if(e)return JSON.parse(e)}catch{}return{leagues:["bra.1","uefa.champions","eng.1"],teams:[]}}function bn(e){localStorage.setItem(fn,JSON.stringify(e));try{fxSync()}catch(_){}try{auPush()}catch(_){}}function qe(e){return U().leagues.includes(e)}function Oe(e,n){return U().teams.some(a=>a.id===e&&a.league===n)}function Ne(e){let n=U();n.leagues=n.leagues.includes(e)?n.leagues.filter(a=>a!==e):[...n.leagues,e],bn(n)}function Ce(e){let n=U(),a=n.teams.some(o=>o.id===e.id&&o.league===e.league);n.teams=a?n.teams.filter(o=>!(o.id===e.id&&o.league===e.league)):[...n.teams,e],bn(n)}function De(e,n){let a=e.map(t=>({...t,matches:[...t.matches]})),o=new Set(a.flatMap(t=>t.matches.map(i=>i.id)));for(let t of n){let i=t.matches.filter(c=>!o.has(c.id));if(!i.length)continue;i.forEach(c=>o.add(c.id));let g=a.find(c=>c.leagueSlug===t.leagueSlug);g?g.matches=[...g.matches,...i].sort((c,u)=>c.date.localeCompare(u.date)):a.push({...t,matches:i})}return a}async function Le(e,n){if(!yn(e))throw new Error("Competi\xE7\xE3o inv\xE1lida");let a=n?`&dates=${xe(n)}`:"",o=await q(`/apis/site/v2/sports/soccer/${e}/scoreboard?${a}`.replace("?&","?"),"scoreboard");return on(o,e)}async function pn(e){let n=e?`&dates=${xe(e)}`:"",a=await q(`/apis/v2/scoreboard/header?sport=soccer${n}`,"scoreboard");return sn(a)}async function vn(e,n=[]){let a=e&&/^\d{4}-\d{2}-\d{2}$/.test(e)?e:K(),o=n.filter(l=>yn(l)&&!be.includes(l)),t=[];try{t=await pn(a)}catch{}let i=be.filter(l=>!t.some(s=>s.leagueSlug===l));if(i.length){let l=await Promise.allSettled(i.map(s=>Le(s,a)));t=De(t,l.filter(s=>s.status==="fulfilled").map(s=>s.value))}if(o.length){let l=await Promise.allSettled(o.map(s=>Le(s,a)));t=De(t,l.filter(s=>s.status==="fulfilled").map(s=>s.value))}let g=t.reduce((l,s)=>l+s.matches.length,0);if(g<6){let l=await Promise.allSettled([...be,...o].map(s=>Le(s,a)));t=De(t,l.filter(s=>s.status==="fulfilled").map(s=>s.value)),g=t.reduce((s,b)=>s+b.matches.length,0)}let c=new Map(be.map((l,s)=>[l,s]));t=t.filter(l=>l.matches.length>0&&l.leagueSlug!=="club.friendly").sort((l,s)=>{var v,f;let b=(v=c.get(l.leagueSlug))!=null?v:80,y=(f=c.get(s.leagueSlug))!=null?f:80;return b!==y?b-y:l.leagueName.localeCompare(s.leagueName,DBZ_I18N.locale)});let u=t.reduce((l,s)=>l+s.matches.filter(b=>b.status==="live").length,0),r=t.reduce((l,s)=>l+s.matches.length,0),p=t.flatMap(l=>l.matches.filter(s=>s.status==="finished"));if(a===K()&&p.length<4){let l=$e(a,-1);try{let b=(await pn(l)).flatMap(v=>v.matches.filter(f=>f.status==="finished")),y=new Set(p.map(v=>v.id));p=[...p,...b.filter(v=>!y.has(v.id))]}catch{}}return p=[...p].sort((l,s)=>s.date.localeCompare(l.date)).slice(0,8),{date:a,groups:t,liveCount:u,total:r,recentFinished:p}}function In(){let e=(location.hash||"#/").replace(/^#/,""),[n,a]=e.split("?"),o=new URLSearchParams(a||""),t=n.split("/").filter(Boolean);return t[0]==="buscar"?{name:"search"}:t[0]==="jogador"&&t[1]&&t[2]?{name:"player",slug:t[1],id:t[2]}:t[0]==="competicoes"?{name:"leagues",q:o.get("q")||void 0}:t[0]==="alertas"?{name:"alerts"}:t[0]==="conta"?{name:"conta"}:t[0]==="favoritos"?{name:"favs"}:t[0]==="liga"&&t[1]?{name:"league",slug:t[1],date:o.get("data")||void 0}:t[0]==="jogo"&&t[1]&&t[2]?{name:"match",slug:t[1],id:t[2]}:t[0]==="time"&&t[1]&&t[2]?{name:"team",slug:t[1],id:t[2]}:{name:"home",date:o.get("data")||void 0}}function D(e,n,a=22){let o=Math.max(16,a);return`<img class="crest" src="${h(e)}" alt="" width="${o}" height="${o}" onerror="this.style.display='none'"/>`}function Se(e,n=!1){let a=e.status==="live",o=e.status==="finished",sc=e.status==="scheduled",t=Qe(e),i=[n?e.leagueShortName:null,t].filter(Boolean).join(" \xB7 "),g=a?`<span class="live-lab"><span class="live-dot"></span>${h(e.clock||"Ao vivo")}</span>`:`<span class="muted-lab">${h(sc?Pe(e.date):Ke(e.status,e.clock,e.detail))}</span>`,c=Xe(e)?`<span class="accent-lab">Pen ${e.home.shootoutScore}–${e.away.shootoutScore}</span>`:"",u=o?'<span class="accent-lab">▶ YouTube</span>':"",ag=Ye(e),team=p=>{let l=e[p],nm=`<span class="tname">${h(l.name)}</span>`,cr=D(l.logo,l.name,32);return`<div class="mc-team ${p}">${p==="home"?nm+cr:cr+nm}</div>`},num=p=>{var v;let l=e[p],d=o&&l.winner===!1?"dim":"",x=ag?`<span class="agg">(${(v=l.aggregateScore)!=null?v:0})</span>`:"";return`<b class="${d}">${l.score!=null?l.score:0}${x}</b>`},mid=sc?'<div class="mc-score sched">VS</div>':`<div class="mc-score">${num("home")}<i>–</i>${num("away")}</div>`,ki="";if(a){let m=/(\d+)/.exec(String(e.clock||"")),k=m?+m[1]:45,pc=Math.max(4,Math.min(100,Math.round(k/(k>90?120:90)*100)));ki=`<div class="mc-ki" aria-hidden="true"><i style="width:${pc}%"></i></div>`}return`<a class="mcard vs${a?" live":""}" href="#/jogo/${h(e.leagueSlug)}/${h(e.id)}">
    <div class="mc-top"><p class="kicker${t?" accent":""}">${h(i)}</p>${g}</div>
    <div class="mc-vs">${team("home")}${mid}${team("away")}</div>
    ${c||u?`<div class="mc-foot">${c}${u}</div>`:""}
    ${ki}
  </a>`}function jn(e,n){return`<nav class="bottom-nav">
    ${[{id:"home",href:"#/",label:"Jogos",icon:Kn()},{id:"leagues",href:"#/competicoes",label:"Ligas",icon:Zn()},{id:"search",href:"#/buscar",label:"Buscar",icon:srIco()},{id:"alerts",href:"#/alertas",label:"Alertas",icon:Ln()},{id:"favs",href:"#/favoritos",label:"Favoritos",icon:Me()}].map(o=>`<a class="${o.id===e?"on":""}" href="${o.href}">
        ${o.icon}<span>${o.label}</span>
        ${o.id==="alerts"&&n?'<i class="badge-dot"></i>':""}
      </a>`).join("")}
  </nav>`}function Dn(e){return`<header class="top">
    <div class="accent-bar"></div>
    <div class="top-inner">
      <a class="wordmark" href="#/" aria-label="DBZSCORE \u2014 in\xEDcio">
        <img src="logo.png" alt="" width="32" height="32"/>
        <span class="display">DBZ<span class="accent">SCORE</span></span>
      </a>
      <span class="top-actions">${thBtn()}${DBZ_I18N.btn()}<a class="bell-btn" href="#/buscar" aria-label="Buscar">${srIco()}</a><a class="bell-btn" href="#/alertas" aria-label="Alertas">${Ln()}${e?'<i class="badge-dot"></i>':""}</a>${auTopBtn()}</span>
    </div>
  </header>`}function Hn(){try{return JSON.parse(localStorage.getItem(Ue)||"[]").filter(n=>!n.read).length}catch{return 0}}function R(e,n){let a=Hn();return`${Dn(a)}<main class="page">${n}</main>${jn(e,a)}`}function Ee(e=6){return`<div class="skels">${Array.from({length:e},()=>'<div class="skel"></div>').join("")}</div>`}function _e(e,n){let a=$e(e,-1),o=$e(e,1),t=i=>i===K()?n:`${n}${n.includes("?")?"&":"?"}data=${i}`;return`<div class="date-nav">
    <a href="${t(a)}" aria-label="Dia anterior">\u2039</a>
    <span>${h(ze(e))}</span>
    <a href="${t(o)}" aria-label="Pr\xF3ximo dia">\u203A</a>
  </div>`}function kn(e){let n=`${e.home.name} vs ${e.away.name} melhores momentos`;return`https://www.youtube.com/results?search_query=${encodeURIComponent(n)}`}async function Gn(e){var o,t;let n=e||K();M.innerHTML=R("home",`${He(n)}${Ee()}`);let a=U();try{let i=await vn(n,a.leagues),g='<div class="search-wrap"><input id="q" type="search" placeholder="Buscar time ou competi\xE7\xE3o" aria-label="Buscar jogos"/></div>',c=i.liveCount,u=[{id:"all",label:"Todos"},{id:"live",label:"Ao vivo"},...i.groups.map(s=>{var b,y;return{id:s.leagueSlug,label:(y=(b=P(s.leagueSlug))==null?void 0:b.shortName)!=null?y:s.leagueShortName}})],r=i.recentFinished.length>0?`<section class="rail">
            <h2 class="sec">Melhores momentos</h2>
            <div class="rail-row">
              ${i.recentFinished.map(s=>{var b,y;return`<a class="thumb" href="${h(kn(s))}" target="_blank" rel="noopener">
                    <div class="thumb-art">${D(s.home.logo,s.home.name,28)}${D(s.away.logo,s.away.name,28)}</div>
                    <p>${h(s.home.abbreviation)} ${(b=s.home.score)!=null?b:0}\u2013${(y=s.away.score)!=null?y:0} ${h(s.away.abbreviation)}</p>
                  </a>`}).join("")}
            </div>
          </section>`:"";M.innerHTML=R("home",`${He(n,c)}${_e(i.date,"#/")}${r}${g}
      <div class="chips" id="chips">${u.map((s,b)=>`<button data-id="${h(s.id)}" class="${b===0?"on":""}">${h(s.label)}</button>`).join("")}</div>
      <div id="list"></div>`);let p=S("#list"),l=()=>{var v,f;let s=(((v=document.getElementById("q"))==null?void 0:v.value)||"").toLowerCase().trim(),b=((f=S("#chips .on"))==null?void 0:f.getAttribute("data-id"))||"all",y=i.groups;if(b==="live"?y=y.map(m=>({...m,matches:m.matches.filter(k=>k.status==="live")})).filter(m=>m.matches.length):b!=="all"&&(y=y.filter(m=>m.leagueSlug===b)),s&&(y=y.map(m=>({...m,matches:m.matches.filter(k=>k.home.name.toLowerCase().includes(s)||k.away.name.toLowerCase().includes(s)||k.leagueName.toLowerCase().includes(s)||k.leagueShortName.toLowerCase().includes(s))})).filter(m=>m.matches.length)),!y.length){p.innerHTML='<p class="empty">Nenhum jogo neste filtro.</p>';return}p.innerHTML=y.map(m=>`<section class="lg-block">
            <a class="lg-head" href="#/liga/${h(m.leagueSlug)}"><span class="lg-name">${LG(m.leagueSlug,22)}<span>${h(m.leagueName)}</span></span><span class="muted-lab">${m.matches.length}</span></a>
            <div class="cards">${m.matches.map(k=>Se(k)).join("")}</div>
          </section>`).join("")};l(),(o=document.getElementById("q"))==null||o.addEventListener("input",l),(t=S("#chips"))==null||t.addEventListener("click",s=>{var y;let b=s.target.closest("button");b&&((y=S("#chips"))==null||y.querySelectorAll("button").forEach(v=>v.classList.remove("on")),b.classList.add("on"),l())})}catch(i){M.innerHTML=R("home",`${He(n)}<p class="empty">${h(i.message)}</p>`)}}function He(e,n=0){return`<section class="hud-panel hero">
    <p class="tag">DBZSCORE voc\xEA vive o jogo</p>
    <h1 class="display">Rodada em curso</h1>
    <p class="lead">Resultados, tabelas e os melhores momentos no YouTube assim que cada jogo termina.</p>
    ${n?`<p class="live-lab" style="margin-top:12px"><span class="live-dot"></span>${n} ${n===1?"jogo ao vivo":"jogos ao vivo"}</p>`:""}
  </section>`}async function qn(e){var t,i;let n=Object.keys(Re),a=`<section class="hud-panel hero">
      <p class="tag">Competi\xE7\xF5es</p>
      <h1 class="display">Ligas do mundo</h1>
    </section>
    <div class="search-wrap"><input id="q" type="search" placeholder="Buscar competi\xE7\xE3o" value="${h(e||"")}"/></div>
    <div id="list"></div>`;M.innerHTML=R("leagues",a);let o=()=>{var u;let g=(((u=document.getElementById("q"))==null?void 0:u.value)||"").toLowerCase().trim(),c=n.map(r=>{let p=we.filter(l=>l.region===r&&(!g||l.name.toLowerCase().includes(g)||l.shortName.toLowerCase().includes(g)||l.country.toLowerCase().includes(g)||DBZ_I18N.tr(l.name).toLowerCase().includes(g)||DBZ_I18N.tr(l.shortName).toLowerCase().includes(g)||DBZ_I18N.tr(l.country).toLowerCase().includes(g)));return p.length?`<section class="lg-block">
          <h2 class="sec">${h(Re[r])}</h2>
          <div class="league-grid">
            ${p.map(l=>{let s=Ve(l.countryCode,40),b=qe(l.slug);return`<div class="league-row">
                  <a href="#/liga/${h(l.slug)}">
                    ${LG(l.slug,28,s||"")}
                    <span><strong>${h(l.shortName)}</strong><small>${h(l.country)}</small></span>
                  </a>
                  <button class="star ${b?"on":""}" data-slug="${h(l.slug)}" aria-label="Favoritar">${Me()}</button>
                </div>`}).join("")}
          </div>
        </section>`:""}).join("");S("#list").innerHTML=c||'<p class="empty">Nenhuma competi\xE7\xE3o encontrada.</p>'};o(),(t=document.getElementById("q"))==null||t.addEventListener("input",o),(i=S("#list"))==null||i.addEventListener("click",g=>{let c=g.target.closest("button.star");c&&(Ne(c.dataset.slug),o())})}async function On(e,n){var t,i,g;let a=P(e),o=n||K();M.innerHTML=R("leagues",`<section class="hud-panel hero">
      ${LG(e,56)}<p class="tag">${h((a==null?void 0:a.country)||"Competi\xE7\xE3o")}</p>
      <h1 class="display">${h((a==null?void 0:a.name)||e)}</h1>
      <button class="ghost-star" id="fav">${qe(e)?"\u2605 Favorita":"\u2606 Favoritar"}</button>
    </section>${_e(o,`#/liga/${e}`)}${Ee()}`),(t=S("#fav"))==null||t.addEventListener("click",()=>{Ne(e),H()});try{let[c,u,r]=await Promise.allSettled([Le(e,o),(async()=>{let m=await q(`/apis/v2/sports/soccer/${e}/standings?`,"standings");return rn(m)})(),(async()=>{let m=await q(`/apis/site/v2/sports/soccer/${e}/statistics?`,"stats");return cn(m)})()]),p=c.status==="fulfilled"?c.value:{leagueSlug:e,leagueName:e,leagueShortName:e,matches:[]},l=u.status==="fulfilled"?u.value:[],s=r.status==="fulfilled"?r.value:{goals:[],assists:[]},y=`<section class="hud-panel hero">
      ${LG(e,56)}<p class="tag">${h((a==null?void 0:a.country)||p.leagueName)}</p>
      <h1 class="display">${h((a==null?void 0:a.name)||p.leagueName)}</h1>
      <button class="ghost-star" id="fav">${qe(e)?"\u2605 Favorita":"\u2606 Favoritar"}</button>
    </section>${_e(o,`#/liga/${e}`)}<div class="chips" id="tabs">
      <button data-t="jogos" class="on">Jogos</button>
      <button data-t="tabela">Tabela</button>
      <button data-t="artilheiros">Artilheiros</button>
    </div><div id="panel"></div>`;M.innerHTML=R("leagues",y);let v=S("#panel"),f=m=>{if(m==="tabela"){if(!l.length){v.innerHTML='<p class="empty">Classifica\xE7\xE3o indispon\xEDvel.</p>';return}v.innerHTML=l.map(k=>`<div class="table-wrap">
              <h3 class="sec">${h(k.name)}</h3>
              <table class="stand">
                <thead><tr><th>#</th><th>Time</th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th></tr></thead>
                <tbody>
                  ${k.rows.map(w=>`<tr>
                        <td>${w.rank}</td>
                        <td><a href="#/time/${h(e)}/${h(w.teamId)}">${D(w.logo,w.teamName,18)} ${h(w.teamName)}</a></td>
                        <td><strong>${h(w.stats.points)}</strong></td>
                        <td>${h(w.stats.played)}</td>
                        <td>${h(w.stats.wins)}</td>
                        <td>${h(w.stats.draws)}</td>
                        <td>${h(w.stats.losses)}</td>
                        <td>${h(w.stats.gd)}</td>
                      </tr>`).join("")}
                </tbody>
              </table>
            </div>`).join("");return}if(m==="artilheiros"){let k=(w,$)=>`<div><h3 class="sec">${w}</h3>${$.length?$.map(L=>`<div class="leader" data-pid="${h(L.athleteId)}" data-lg="${h(e)}" data-pd="${h(JSON.stringify({id:L.athleteId,name:L.name,img:L.headshot,team:L.teamName}))}">
                      <span class="rk">${L.rank}</span>
                      <img class="head" src="${h(L.headshot)}" alt="${h(L.name)}" data-ph="${h(L.athleteId)}" data-tm="${h(L.teamName)}"/>
                      <span class="grow"><strong>${h(L.shortName)}</strong><small>${h(L.teamName)}</small></span>
                      <span class="val">${L.value}</span>
                    </div>`).join(""):'<p class="empty">Sem dados.</p>'}</div>`;v.innerHTML=`<div class="lead-grid">${k("Gols",s.goals)}${k("Assist\xEAncias",s.assists)}</div>`;return}v.innerHTML=p.matches.length?`<div class="cards">${p.matches.map(k=>Se(k)).join("")}</div>`:'<p class="empty">Sem jogos nesta data.</p>'};f("jogos"),(i=S("#tabs"))==null||i.addEventListener("click",m=>{var w;let k=m.target.closest("button");k&&((w=S("#tabs"))==null||w.querySelectorAll("button").forEach($=>$.classList.remove("on")),k.classList.add("on"),f(k.dataset.t||"jogos"))}),(g=S("#fav"))==null||g.addEventListener("click",()=>{Ne(e),H()})}catch(c){M.innerHTML=R("leagues",`<p class="empty">${h(c.message)}</p>`)}}/* ===== Lances v3: fluxo da partida, mapa de lances, linha do tempo e comentário ===== */
/*LX-BEGIN*/
var LX_W={goal:6,pen:3,sot:3.2,shot:2,corner:1.6,off:.8,fk:.7,foul:.5,yc:.6,rc:2.5};
var LX_IC={goal:"⚽",pen:"⚽",yc:"🟨",rc:"🟥",sub:"⇄",var:"VAR",sot:"◎",shot:"○",corner:"⚑",foul:"✋",off:"⚐",fk:"✦",per:"⏱",other:"•"};
var LX_LB={goal:"Gol",pen:"Pênalti",yc:"Cartão amarelo",rc:"Cartão vermelho",sub:"Substituição",var:"VAR",sot:"Chute no alvo",shot:"Finalização",corner:"Escanteio",foul:"Falta",off:"Impedimento",fk:"Tiro livre",per:"",other:""};
var LX_PF={all:null,goal:["goal","pen"],shot:["shot","sot"],corner:["corner"],foul:["foul","off","fk"],card:["yc","rc"]};

function lxRawComments(o){
  var arr=Array.isArray(o.commentary)?o.commentary:[];
  return arr.map(function(c,i){
    c=C(c)||{};
    var p=C(c.play)||{},ty=C(p.type)||{},tm=C(p.team)||C(c.team)||{},
      pa=Array.isArray(p.participants)?p.participants:[],
      at=C((C(pa[0])||{}).athlete)||{};
    return{
      id:d(c.sequence!=null?c.sequence:p.id,String(i)),
      clock:d((C(c.time)||{}).displayValue||(C(p.clock)||{}).displayValue),
      text:d(c.text||p.text||p.shortText),
      typ:d(ty.text||ty.type),
      teamId:tm.id?d(tm.id):"",
      player:d(at.displayName||at.fullName),
      playerId:at.id?d(at.id):"",
      scoring:!!p.scoringPlay
    };
  }).filter(function(x){return x.text||x.typ});
}

function lxMin(s){
  var m=String(s||"").match(/(\d+)\s*(?:'|’|′)?\s*(?:\+\s*(\d+))?/);
  return m?{b:+m[1],x:m[2]?+m[2]:0}:null;
}
function lxT(s){var m=lxMin(s);return m?m.b+m.x:null}

function lxKind(typ,txt,sc){
  var a=(String(typ||"")+" | "+String(txt||"").slice(0,60)).toLowerCase();
  if(/goal kick|tiro de meta/.test(a))return"other";
  if(sc)return"goal";
  if(/substitu/.test(a))return"sub";
  if(/\bvar\b|video assistant|disallow|anulad/.test(a))return"var";
  if(/red card|second yellow|cart[aã]o vermelho|expuls|sent off/.test(a))return"rc";
  if(/yellow|amarelo/.test(a))return"yc";
  if(/own goal|gol contra|^goal|\| goal|goal!|gol!|\bgol\b|penalty - scored|penalty scored|p[eê]nalti convertido/.test(a))return"goal";
  if(/kick.?off|half.?time|full.?time|first half|second half|end of|match ends|extra time|intervalo|fim d|in[ií]cio d|encerr|prorroga/.test(a)&&!/attempt|shot/.test(a))return"per";
  if(/penalty|p[eê]nalti/.test(a))return"pen";
  if(/attempt saved|save|defesa|defendeu|on target|no alvo/.test(a))return"sot";
  if(/attempt|shot|chute|finaliza|cabece|header|blocked|bloque|woodwork|trave|\bpost\b|miss/.test(a))return"shot";
  if(/corner|escanteio/.test(a))return"corner";
  if(/offside|impedimento/.test(a))return"off";
  if(/free.?kick|tiro livre|cobran[cç]a de falta/.test(a)&&!/foul/.test(a))return"fk";
  if(/foul|falta|hand ?ball|m[aã]o/.test(a))return"foul";
  return"other";
}

function lxOrder(arr){
  if(arr.length>1){
    var f=arr[0].t,l=arr[arr.length-1].t;
    if(f!=null&&l!=null&&f>l)arr=arr.slice().reverse();
  }
  return arr.map(function(x,i){return[x,i]}).sort(function(a,b){
    var ta=a[0].t==null?-1:a[0].t,tb=b[0].t==null?-1:b[0].t;
    return ta-tb||a[1]-b[1];
  }).map(function(p){return p[0]});
}

function lxModel(u){
  var r=u.match,hid=String(r.home.id),aid=String(r.away.id);
  var names=[[r.home.name,r.home.shortName],[r.away.name,r.away.shortName]];
  var side=function(t,x){
    if(t===hid)return 0;
    if(t===aid)return 1;
    if(!x)return-1;
    var lo=x.toLowerCase(),best=-1,bi=1e9;
    names.forEach(function(ns,k){ns.forEach(function(nm){
      if(!nm)return;
      var i=lo.indexOf(String(nm).toLowerCase());
      if(i>=0&&i<bi){bi=i;best=k}
    })});
    return best;
  };
  var ev=lxOrder(u.events.map(function(x,i){
    return{id:x.id,i:i,kind:lxKind(x.type,x.text,x.scoring),side:lxKind(x.type,x.text,x.scoring)==="per"?-1:side(x.teamId,""),clock:x.clock,
      t:lxT(x.clock),mn:lxMin(x.clock),text:x.text,player:x.player,pid:x.playerId,head:x.headshot,
      period:x.period||0,own:x.ownGoal,pen:x.penalty,parts:x.parts||[]};
  }));
  var cm=lxOrder((u.comments||[]).map(function(x,i){
    return{id:x.id,i:i,kind:lxKind(x.typ,x.text,x.scoring),side:lxKind(x.typ,x.text,x.scoring)==="per"?-1:side(x.teamId,x.text),clock:x.clock,
      t:lxT(x.clock),text:x.text,typ:x.typ,player:x.player,pid:x.playerId};
  }));
  var hs=0,as=0,ok=true;
  ev.forEach(function(x){
    if(x.kind==="goal"){
      if(x.side===0)hs++;else if(x.side===1)as++;else ok=false;
      x.sc=[hs,as];
    }
  });
  if(r.status!=="scheduled"&&(hs!==(+r.home.score||0)||as!==(+r.away.score||0)))ok=false;
  if(!ok)ev.forEach(function(x){x.sc=null});
  var per=function(x){
    if(x.period>=1&&x.period<=5)return x.period===5?4:x.period>=3?3:x.period;
    var b=x.mn?x.mn.b:0;return b<=45?1:b<=90?2:3;
  };
  var ht=null;
  if(ok){var a=0,b=0;ev.forEach(function(x){if(x.kind==="goal"&&per(x)===1){if(x.side===0)a++;else b++}});ht=[a,b]}
  var rich=cm.filter(function(x){return x.side>=0&&x.t!=null&&LX_W[x.kind]}).length>=8;
  var plays=(rich?cm:ev).filter(function(x){return x.side>=0&&x.t!=null&&LX_W[x.kind]});
  var tmax=0;
  ev.concat(cm).forEach(function(x){if(x.t!=null&&x.t>tmax)tmax=x.t});
  var cur=null;
  if(r.status==="live"){cur=lxT(r.clock);if(cur==null&&tmax)cur=tmax;if(cur!=null&&cur>tmax)tmax=cur}
  var jer={};
  (u.lineups||[]).forEach(function(l){l.players.forEach(function(p){jer[p.id]=p.jersey})});
  return{r:r,ev:ev,cm:cm,plays:plays,rich:rich,cur:cur,end:tmax>100?120:Math.max(90,Math.ceil(tmax)+1),
    ht:ht,per:per,jer:jer,names:[r.home.shortName||r.home.name,r.away.shortName||r.away.name]};
}

/* ---------- Fluxo da partida ---------- */
function lxSeries(m){
  var N=Math.ceil(m.end*2)+1,hv=new Array(N).fill(0),av=new Array(N).fill(0);
  m.plays.forEach(function(p){
    var sd=p.side;
    if(p.kind==="foul"||p.kind==="yc"||p.kind==="rc")sd=1-sd;
    var a=sd===0?hv:av,c=Math.round(Math.min(p.t,m.end)*2);
    for(var j=Math.max(0,c-14);j<=Math.min(N-1,c+14);j++){
      var dt=(j-c)/2;a[j]+=LX_W[p.kind]*Math.exp(-dt*dt/(2*2.2*2.2));
    }
  });
  return{hv:hv,av:av,mx:Math.max(3,Math.max.apply(null,hv),Math.max.apply(null,av))};
}
function lxShare(m,t0,t1){
  var a=0,b=0;
  m.plays.forEach(function(p){
    if(p.t<t0||p.t>t1)return;
    var sd=p.side;
    if(p.kind==="foul"||p.kind==="yc"||p.kind==="rc")sd=1-sd;
    if(sd===0)a+=LX_W[p.kind];else b+=LX_W[p.kind];
  });
  if(a+b===0)return null;
  var pa=Math.round(a/(a+b)*100);return[pa,100-pa];
}
function lxRead(m,t0,t1,lab){
  var s=lxShare(m,t0,t1);
  if(!s)return'<span class="fx-dim">'+h(lab)+' · sem lances</span>';
  return'<span class="fx-dim">'+h(lab)+'</span> <i class="fx-dot fx-ah"></i><b>'+h(m.names[0])+' '+s[0]+'%</b> <span class="fx-dim">×</span> <b>'+s[1]+'% '+h(m.names[1])+'</b><i class="fx-dot fx-aa"></i>';
}
function lxFlow(m){
  var r=m.r;
  var head='<section class="hud-panel fx-card"><h3 class="fx-h">Fluxo da partida</h3>';
  if(m.plays.length<3)return head+'<p class="fx-note">Ainda não há lances suficientes para desenhar o fluxo.</p></section>';
  var W=360,HH=150,mid=75,amp=62,s=lxSeries(m),N=s.hv.length,
    lim=m.cur!=null?Math.min(N-1,Math.round(m.cur*2)):N-1,
    X=function(j){return j/(N-1)*W},tx=function(t){return Math.min(W,t/m.end*W)},
    pts=function(arr,sg){var o=[];for(var j=0;j<=lim;j++)o.push([X(j),mid+sg*arr[j]/s.mx*amp]);return o},
    /* curva suave (Catmull-Rom -> Bézier), presa ao lado do time para não cruzar a linha central */
    smooth=function(P,sg){
      var d="M"+P[0][0].toFixed(1)+","+P[0][1].toFixed(1),cl=function(y){return sg<0?Math.max(0,Math.min(mid,y)):Math.min(HH,Math.max(mid,y))};
      for(var i=0;i<P.length-1;i++){
        var p0=P[i-1]||P[i],p1=P[i],p2=P[i+1],p3=P[i+2]||p2;
        d+=" C"+(p1[0]+(p2[0]-p0[0])/6).toFixed(1)+","+cl(p1[1]+(p2[1]-p0[1])/6).toFixed(1)+" "+(p2[0]-(p3[0]-p1[0])/6).toFixed(1)+","+cl(p2[1]-(p3[1]-p1[1])/6).toFixed(1)+" "+p2[0].toFixed(1)+","+p2[1].toFixed(1);
      }
      return d;
    },
    PH=pts(s.hv,-1),PA=pts(s.av,1),ph=smooth(PH,-1),pa=smooth(PA,1),
    phA=ph+" L"+X(lim).toFixed(1)+","+mid+" L0,"+mid+" Z",paA=pa+" L"+X(lim).toFixed(1)+","+mid+" L0,"+mid+" Z";
  var mk="";
  m.ev.forEach(function(x){
    if(x.t==null||x.side<0)return;
    var cx=tx(x.t).toFixed(1),cy=x.side===0?10:HH-10,cl=x.side===0?"fx-ah":"fx-aa";
    if(x.kind==="goal")mk+='<g class="'+cl+'"><polygon class="fx-f" points="'+cx+","+(cy-9)+" "+(+cx+8)+","+cy+" "+cx+","+(cy+9)+" "+(cx-8)+","+cy+'" stroke="#fff" stroke-width="1.4" stroke-linejoin="round"/><circle cx="'+cx+'" cy="'+cy+'" r="2" fill="#fff"/></g>';
    else if(x.kind==="yc"||x.kind==="rc")mk+='<rect x="'+(cx-3)+'" y="'+(cy-4.5)+'" width="6" height="9" rx="1" fill="'+(x.kind==="yc"?"#f5c518":"#e03131")+'"/>';
  });
  var ax="";
  [0,45,90,120].forEach(function(t){if(t<=m.end)ax+='<span style="left:'+(t/m.end*100)+'%">'+t+"'</span>"});
  var cur=m.cur!=null?'<line class="fx-now" x1="'+tx(m.cur)+'" x2="'+tx(m.cur)+'" y1="0" y2="'+HH+'" stroke-width="2"/><circle class="fx-now-dot" cx="'+tx(m.cur)+'" cy="4" r="4"/>':"";
  return head+'<p class="fx-read" id="fxr">'+lxRead(m,0,m.end,"Pressão no jogo")+'</p>'+
    '<div class="fx-flow"><div class="fx-crests">'+D(r.home.logo,r.home.name,26)+D(r.away.logo,r.away.name,26)+'</div>'+
    '<svg viewBox="0 0 '+W+" "+HH+'" preserveAspectRatio="none" role="img" aria-label="Fluxo da partida">'+
    '<defs><linearGradient id="fxgh" gradientUnits="userSpaceOnUse" x1="0" y1="'+mid+'" x2="0" y2="0"><stop offset="0" style="stop-color:var(--accent);stop-opacity:.1"/><stop offset="1" style="stop-color:var(--accent);stop-opacity:.85"/></linearGradient>'+
    '<linearGradient id="fxga" gradientUnits="userSpaceOnUse" x1="0" y1="'+mid+'" x2="0" y2="'+HH+'"><stop offset="0" style="stop-color:var(--fx-away);stop-opacity:.1"/><stop offset="1" style="stop-color:var(--fx-away);stop-opacity:.85"/></linearGradient></defs>'+
    '<rect width="'+W+'" height="'+HH+'" class="fx-track"/>'+
    '<line x1="0" x2="'+W+'" y1="'+(mid-amp/2)+'" y2="'+(mid-amp/2)+'" class="fx-grid"/><line x1="0" x2="'+W+'" y1="'+(mid+amp/2)+'" y2="'+(mid+amp/2)+'" class="fx-grid"/>'+
    '<path d="'+phA+'" class="fx-ah" style="fill:url(#fxgh)"/><path d="'+paA+'" class="fx-aa" style="fill:url(#fxga)"/>'+
    '<path d="'+ph+'" class="fx-ah fx-edge"/><path d="'+pa+'" class="fx-aa fx-edge"/>'+
    '<line x1="0" x2="'+W+'" y1="'+mid+'" y2="'+mid+'" class="fx-mid-l"/>'+
    '<line x1="'+tx(45)+'" x2="'+tx(45)+'" y1="0" y2="'+HH+'" class="fx-ht"/>'+
    mk+cur+'<line class="fx-scrub" x1="0" x2="0" y1="0" y2="'+HH+'" style="display:none"/></svg></div>'+
    '<div class="fx-ax">'+ax+'</div>'+
    '<p class="fx-note">Toque no gráfico para ver um minuto. Estimativa feita a partir dos lances (gols, chutes, escanteios, faltas e cartões), não é um dado oficial.</p></section>';
}
function lxScrub(ev,m){
  var box=ev.target.closest&&ev.target.closest(".fx-flow");
  if(!box||!m||m.plays.length<3)return;
  var sv=box.querySelector("svg"),rc=sv.getBoundingClientRect();
  if(!rc.width)return;
  var t=Math.max(0,Math.min(m.end,(ev.clientX-rc.left)/rc.width*m.end)),x=t/m.end*360,ln=sv.querySelector(".fx-scrub");
  ln.setAttribute("x1",x);ln.setAttribute("x2",x);ln.style.display="";
  var rd=document.getElementById("fxr");
  if(rd)rd.innerHTML=lxRead(m,Math.max(0,t-5),t+5,Math.round(t)+"'");
}

/* ---------- Mapa de lances ---------- */
function lxHash(s){var x=2166136261;s=String(s);for(var i=0;i<s.length;i++){x^=s.charCodeAt(i);x=Math.imul(x,16777619)}return x>>>0}
function lxPos(p){
  var k=p.kind,hs=lxHash(p.id+k+p.i),r1=(hs%997)/997,r2=((hs>>>10)%991)/991,dir=p.side===0?1:-1,dist,y;
  var G=function(a,b,r){return a+(b-a)*r};
  if(k==="goal"){dist=G(2,11,r1);y=G(25,43,r2)}
  else if(k==="pen"){dist=11;y=34}
  else if(k==="sot"){dist=G(7,24,r1);y=G(21,47,r2)}
  else if(k==="shot"){dist=G(9,32,r1);y=G(12,56,r2)}
  else if(k==="corner"){dist=1;y=r2>.5?2:66}
  else if(k==="off"){dist=G(14,34,r1);y=G(8,60,r2)}
  else if(k==="fk"){dist=G(26,56,r1);y=G(8,60,r2)}
  else{dist=G(48,86,r1);y=G(8,60,r2)}
  var x=dir===1?105-dist:dist;
  return[Math.min(103,Math.max(2,x)),Math.min(66,Math.max(2,y))];
}
function lxCap(p,m){
  if(!p)return"Nenhum lance deste tipo até agora.";
  var tm=m.names[p.side];
  return'<b>'+h(p.clock||"")+'</b> · '+h(LX_LB[p.kind]||"Lance")+' · '+h(p.player?p.player+" ("+tm+")":tm);
}
function lxPin(p,i){
  var q=lxPos(p),x=q[0].toFixed(1),y=q[1].toFixed(1),k=p.kind,cl=p.side===0?"fx-ah":"fx-aa",s;
  if(k==="goal"||k==="pen")s='<circle class="fx-f" cx="'+x+'" cy="'+y+'" r="2.8"/><circle cx="'+x+'" cy="'+y+'" r="1" fill="#fff"/>';
  else if(k==="sot")s='<circle class="fx-f" cx="'+x+'" cy="'+y+'" r="1.9"/>';
  else if(k==="shot")s='<circle class="fx-s" cx="'+x+'" cy="'+y+'" r="1.9" fill="none" stroke-width="1"/>';
  else if(k==="corner")s='<path class="fx-f" d="M'+(+x-2)+","+(+y+1.8)+" L"+(+x+2)+","+(+y+1.8)+" L"+x+","+(+y-2)+' Z"/>';
  else if(k==="yc"||k==="rc")s='<rect x="'+(+x-1.3)+'" y="'+(+y-1.8)+'" width="2.6" height="3.6" fill="'+(k==="yc"?"#f5c518":"#e03131")+'" stroke="#000" stroke-opacity=".45" stroke-width=".3"/>';
  else s='<path class="fx-s" d="M'+(+x-1.5)+","+(+y-1.5)+" L"+(+x+1.5)+","+(+y+1.5)+" M"+(+x+1.5)+","+(+y-1.5)+" L"+(+x-1.5)+","+(+y+1.5)+'" stroke-width="1.1"/>';
  return'<g class="fx-pin '+cl+'" data-i="'+i+'">'+s+'<circle cx="'+x+'" cy="'+y+'" r="3.6" fill="transparent"/></g>';
}
function lxChips(g,cur,opts){
  return'<div class="fx-chips" data-g="'+g+'">'+opts.map(function(o){
    return'<button data-v="'+o[0]+'" class="'+(o[0]===cur?"on":"")+'">'+h(o[1])+'</button>';
  }).join("")+'</div>';
}
/* ===== Formações em campo (estilo Sofascore) ===== */
function fxStats(a){
  var o={};
  (Array.isArray(a)?a:[]).forEach(function(s){
    if(!s||s.name==null)return;
    var v=Number(s.value!=null?s.value:s.displayValue);
    if(isFinite(v))o[s.name]=v;
  });
  return o;
}
function fpAbbr(p){return String(p.positionAbbr||"").toUpperCase().replace(/[\s.]/g,"")}
/* 0 goleiro, 1 defesa, 2 meio, 3 ataque, 4 desconhecido */
function fpRole(p){
  var a=fpAbbr(p),n=fxNorm(p.position);
  if(a==="G"||a==="GK"||/goalk|goleir|portero|arquero/.test(n))return 0;
  if(/mid|meio|volante|medio|centrocamp/.test(n))return 2;
  if(/defen|zague|lateral|back|libero|sweeper/.test(n))return 1;
  if(/atac|forw|strik|wing|ponta|delant/.test(n))return 3;
  if(/^(D|CD|CB|SW|LB|RB|LWB|RWB|LE|LD|ZC|ZE|ZD|ZCD|ZCE|ZCI|ZI|CD-?[LR])$/.test(a))return 1;
  if(/^(M|CM|DM|AM|LM|RM|MC|MCE|MCD|MCI|ME|MD|MA|VOL|CM-?[LR]|AM-?[LR]|DM-?[LR])$/.test(a))return 2;
  if(/^(F|ST|CF|SS|FW|LF|RF|LW|RW|AE|AD|ATC|ACI|ACE|ACD|ATCD|ATCE|ATCI|CF-?[LR])$/.test(a))return 3;
  return 4;
}
/* posição na horizontal: -2 aberto à esquerda ... +2 aberto à direita */
function fpX(p){
  var a=fpAbbr(p),n=fxNorm(p.position);
  if(/^(LB|LWB|LM|LW|LE|AE|ME|PE)$/.test(a))return-2;
  if(/^(RB|RWB|RM|RW|LD|AD|MD|PD)$/.test(a))return 2;
  if(/^(CD-?L|CM-?L|AM-?L|CF-?L|DM-?L|LF|ZE|ZCE|ZCI|ZI|MCE|MCI|ACI|ACE|ATCE|ATCI)$/.test(a))return-1;
  if(/^(CD-?R|CM-?R|AM-?R|CF-?R|DM-?R|RF|ZD|ZCD|MCD|ACD|ATCD)$/.test(a))return 1;
  var L=/left|esquerd|izquierd/.test(n),R=/right|direit|derech/.test(n),C=/cent(er|re|ral|ro)/.test(n);
  if(L&&!R)return C?-1:-2;
  if(R&&!L)return C?1:2;
  return 0;
}
function fpName(n){
  n=String(n||"").trim();
  var p=n.split(/\s+/);
  return p.length<2?n:p[0].charAt(0).toUpperCase()+". "+p.slice(1).join(" ");
}
/* profundidade no meio-campo (0 volante, 1 central, 2 meia de ligação/aberto) — só usada no plano B, sem formationPlace */
function fpDepth(p){
  var a=fpAbbr(p),n=fxNorm(p.position);
  if(fpRole(p)!==2)return 1;
  if(/^(DM|VOL|MCD?|DM-?[LR])$/.test(a)&&a!=="MC"||/volante|defensive/.test(n))return 0;
  if(/^(AM|MA|LM|RM|ME|MD|AM-?[LR])$/.test(a)||/attacking|ofensiv|armador/.test(n))return 2;
  return 1;
}
/* Divide os 11 titulares em goleiro + linhas (defesa → ataque), cada linha da esquerda p/ direita */
function fpRows(t){
  var st=(t.players||[]).filter(function(x){return x.starter});
  if(st.length<7)return null;
  var o=st.map(function(p,i){return{p:p,i:i,k:parseInt(p.formationPlace,10)}}),
    hasK=o.every(function(z){return isFinite(z.k)});
  o.sort(function(a,b){return hasK?(a.k-b.k||a.i-b.i):a.i-b.i});
  var list=o.map(function(z){return z.p}),rs=list.map(fpRole),bad=false,seen=false;
  rs.forEach(function(r,i){
    if(r===0&&i>0)bad=true;
    if(r===1&&seen)bad=true;
    if(r===2||r===3)seen=true;
  });
  var byRole=function(){
    var d=list.map(function(p,i){return{p:p,i:i,r:fpRole(p)===4?2:fpRole(p),dp:fpDepth(p),x:fpX(p)}});
    d.sort(function(a,b){return a.r-b.r||a.dp-b.dp||a.x-b.x||a.i-b.i});
    return d.map(function(z){return z.p});
  };
  if(bad)list=byRole();
  var gk=null,gi=list.findIndex(function(p){return fpRole(p)===0});
  if(gi>=0)gk=list.splice(gi,1)[0];
  var cnt=String(t.formation||"").split("-").map(Number);
  var okF=cnt.length>=2&&cnt.every(function(n){return n>0&&n%1===0})&&cnt.reduce(function(a,b){return a+b},0)===list.length;
  if(!okF){
    list=byRole();
    var gi2=list.findIndex(function(p){return fpRole(p)===0});
    if(gi2>=0&&!gk)gk=list.splice(gi2,1)[0];
    var rr=list.map(fpRole),dn=rr.filter(function(r){return r===1}).length,fn=rr.filter(function(r){return r===3}).length;
    cnt=[dn,list.length-dn-fn,fn].filter(function(n){return n>0});
    if(!cnt.length)cnt=[list.length];
  }
  var rows=[],at=0;
  cnt.forEach(function(n){
    var seg=list.slice(at,at+n).map(function(p,i){return{p:p,i:i,x:fpX(p)}});
    at+=n;
    seg.sort(function(a,b){return a.x-b.x||a.i-b.i});
    rows.push(seg.map(function(z){return z.p}));
  });
  return{gk:gk,rows:rows};
}
function fpEvents(u){
  var o={};
  (u.events||[]).forEach(function(x){
    if(!x.playerId)return;
    var z=o[x.playerId]||(o[x.playerId]={g:0,og:0,y:0,r:0});
    if(x.scoring&&!x.ownGoal)z.g++;
    if(x.ownGoal)z.og++;
    if(x.yellow)z.y++;
    if(x.red)z.r++;
  });
  return o;
}
function fpRate(p,t,ctx,ev){
  if(!p.starter&&!p.subbedIn)return null;
  var s=p.stats||{};
  if(!Object.keys(s).length)return null;
  var x=ev[p.id]||{},g=Math.max(s.totalGoals||0,x.g||0),og=Math.max(s.ownGoals||0,x.og||0),
    y=Math.max(s.yellowCards||0,x.y||0),rd=Math.max(s.redCards||0,x.r||0),
    ga=t.homeAway==="home"?ctx.as:ctx.hs,res=ctx.fin?(t.homeAway==="home"?ctx.hs-ctx.as:ctx.as-ctx.hs):0,
    r=6.3+(res>0?.3:res<0?-.3:0);
  r+=Math.min(g,3)*1.0+Math.min(s.goalAssists||0,3)*.6;
  r+=(s.shotsOnTarget||0)*.15+Math.max(0,(s.totalShots||0)-(s.shotsOnTarget||0))*.04;
  r+=(s.foulsSuffered||0)*.05-(s.foulsCommitted||0)*.06;
  r-=y*.3+rd*1.5+og*.9;
  var role=fpRole(p);
  if(role===0){r+=(s.saves||0)*.2-(s.goalsConceded!=null?s.goalsConceded:(isFinite(ga)?ga:0))*.3;if(isFinite(ga)&&ga===0&&ctx.fin)r+=.4}
  else if(role===1&&ctx.fin&&isFinite(ga)){r+=ga===0?.3:ga>=3?-.3:0}
  return Math.round(Math.max(4,Math.min(10,r))*10)/10;
}
function fpCls(r){return r<5?"r1":r<6?"r2":r<7?"r3":r<8?"r4":r<9?"r5":"r6"}
var FP_BALL='<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#fff" stroke="currentColor" stroke-width="2"/><path d="M12 7l4 3-1.5 5h-5L8 10z" fill="currentColor"/></svg>',
  FP_SWAP='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h13l-3.5-3.5M19 16H6l3.5 3.5"/></svg>',
  FP_BOOT='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h5l.6 6 6.2 2.4c1 .4 1.5 1.2 1.5 2.1V17H4.5z"/></svg>';
function fpBadges(p,ev){
  var s=p.stats||{},x=ev[p.id]||{},g=Math.max(s.totalGoals||0,x.g||0),a=s.goalAssists||0,og=Math.max(s.ownGoals||0,x.og||0),
    y=Math.max(s.yellowCards||0,x.y||0),rd=Math.max(s.redCards||0,x.r||0),o="";
  if(g)o+='<span class="fp-b tr'+(g>1?" n":"")+'" title="Gol">'+FP_BALL+(g>1?"<em>"+g+"</em>":"")+"</span>";
  else if(og)o+='<span class="fp-b tr og" title="Gol contra">'+FP_BALL+"</span>";
  if(a)o+='<span class="fp-b mr" title="Assistência">'+FP_BOOT+"</span>";
  if(rd)o+='<span class="fp-cd red" title="Cartão vermelho"></span>';
  else if(y)o+='<span class="fp-cd" title="Cartão amarelo"></span>';
  if(p.subbedOut&&p.starter)o+='<span class="fp-b bl out" title="Substituído">'+FP_SWAP+"</span>";
  else if(p.subbedIn&&!p.starter)o+='<span class="fp-b bl in" title="Entrou">'+FP_SWAP+"</span>";
  return o;
}
function fpShirt(c){
  c=/^[0-9a-f]{6}$/i.test(c||"")?"#"+c:"#6b7280";
  return'<svg class="fp-shirt" viewBox="0 0 32 32" aria-hidden="true"><path d="M11 3 3 7l3 7 3-1.5V29h14V12.5l3 1.5 3-7-8-4c-.7 2-2.6 3.2-5 3.2S11.7 5 11 3z" fill="'+c+'" stroke="rgba(120,120,120,.6)" stroke-width="1"/></svg>';
}
function fpPitchSvg(){
  var v='vector-effect="non-scaling-stroke"';
  return'<svg class="fp-lines" viewBox="0 0 100 235" preserveAspectRatio="none" aria-hidden="true"><g fill="none" stroke="rgba(150,255,224,.42)" stroke-width="1.5">'+
    '<rect x="0.4" y="0.4" width="99.2" height="234.2" '+v+'/>'+
    '<line x1="0" y1="117.5" x2="100" y2="117.5" '+v+'/>'+
    '<circle cx="50" cy="117.5" r="13.5" '+v+'/>'+
    '<rect x="30" y="0.4" width="40" height="12" '+v+'/><rect x="41" y="0.4" width="18" height="4.6" '+v+'/>'+
    '<path d="M42.5 12.4a8 8 0 0 0 15 0" '+v+'/>'+
    '<rect x="30" y="222.6" width="40" height="12" '+v+'/><rect x="41" y="230" width="18" height="4.6" '+v+'/>'+
    '<path d="M42.5 222.6a8 8 0 0 1 15 0" '+v+'/></g></svg>';
}
function fpHtml(u,e,st){
  var L=(u.lineups||[]).slice().sort(function(a,b){return(a.homeAway==="home"?0:1)-(b.homeAway==="home"?0:1)});
  if(L.length<2)return"";
  var R=[fpRows(L[0]),fpRows(L[1])];
  if(!R[0]||!R[1]||!R[0].gk||!R[1].gk)return"";
  var ev=fpEvents(u),r=u.match,ctx={fin:r.status==="finished",hs:Number(r.home.score),as:Number(r.away.score)},
    rate={},sum=[[],[]],best=null;
  L.forEach(function(t,ti){
    t.players.forEach(function(p){
      var v=fpRate(p,t,ctx,ev);
      if(v==null)return;
      rate[ti+":"+p.id]=v;sum[ti].push(v);
      if(ctx.fin&&v>=7&&(!best||v>best.v))best={k:ti+":"+p.id,v:v};
    });
  });
  var any=sum[0].length+sum[1].length>0,mode=st.fpm||(any?"perf":"pos");
  if(mode==="perf"&&!any)mode="pos";
  var avg=sum.map(function(a){return a.length>=5?a.reduce(function(x,y){return x+y},0)/a.length:null});
  var node=function(p,ti,x,y,t,k){
    var v=rate[ti+":"+p.id],pd=JSON.stringify({id:p.id,name:p.name,img:p.headshot,jersey:p.jersey,pos:p.position,team:t.teamName,teamId:t.teamId,teamLogo:t.logo}),
      mvp=best&&best.k===ti+":"+p.id,chip="";
    if(mode==="perf"&&v!=null)chip='<b class="fp-r '+fpCls(v)+(mvp?" mvp":"")+'">'+(mvp?'<i class="fp-star">★</i>':"")+v.toFixed(1)+"</b>";
    else if(mode==="pos"&&p.positionAbbr)chip='<b class="fp-r pos">'+h(p.positionAbbr)+"</b>";
    return'<div class="fp-p t'+ti+(k>=4?" dense":"")+'" style="left:'+x.toFixed(2)+"%;width:"+(k===1?46:k===2?36:k===3?31:k===4?26.5:22)+"%;top:calc("+y.toFixed(2)+'% - var(--s) / 2)" data-pid="'+h(p.id)+'" data-lg="'+h(e)+'" data-pd="'+h(pd)+'">'+
      '<div class="fp-ph"><img class="head" src="'+h(p.headshot)+'" alt="'+h(p.name)+'" data-ph="'+h(p.id)+'" data-tm="'+h(t.teamName)+'" data-jn="'+h(p.jersey)+'"/>'+(mode==="perf"?fpBadges(p,ev):"")+chip+"</div>"+
      '<div class="fp-n"><i>'+h(p.jersey)+"</i>"+(p.captain?"<i>(c)</i>":"")+"<span>"+h(fpName(p.name))+"</span></div></div>";
  };
  var place=function(T,ti){
    var lines=[[T.gk]].concat(T.rows),n=lines.length,out="";
    lines.forEach(function(row,i){
      var y=ti===0?3+(i/(n-1))*38.5:93.5-(i/(n-1))*42;
      var k=row.length,m=k===1?50:k===2?28:k===3?18:k===4?13.5:11;
      row.forEach(function(p,j){
        var x=k===1?50:m+(100-2*m)*j/(k-1);
        if(ti===0)x=100-x; /* time da casa ataca para baixo: o lado esquerdo dele fica à direita da tela */
        out+=node(p,ti,x,y,L[ti],k);
      });
    });
    return out;
  };
  var head=function(t,ti){
    var a=avg[ti];
    return'<div class="fp-team"><span class="fp-crest">'+D(t.logo,t.teamName,34)+'</span><div class="fp-main"><b class="fp-tn">'+h(t.teamName)+"</b>"+
      (a!=null&&mode==="perf"?'<span class="fp-avg"><i class="'+fpCls(a)+'"></i><b>'+a.toFixed(2)+'</b><button class="fp-info" type="button" aria-label="Como a nota é calculada">i</button></span>':"")+
      '</div><span class="fp-form"><b>'+h(t.formation)+"</b>"+fpShirt(t.color)+"</span></div>";
  };
  var bench=function(t,ti){
    var bn=t.players.filter(function(x){return!x.starter});
    if(!bn.length)return"";
    return'<h3 class="sec fp-bh">'+D(t.logo,t.teamName,18)+" "+h(t.teamName)+" · Banco</h3>"+bn.map(function(p){
      var v=rate[ti+":"+p.id],pd=JSON.stringify({id:p.id,name:p.name,img:p.headshot,jersey:p.jersey,pos:p.position,team:t.teamName,teamId:t.teamId,teamLogo:t.logo});
      return'<div class="xi fp-bn'+(p.subbedIn?" in":"")+'" data-pid="'+h(p.id)+'" data-lg="'+h(e)+'" data-pd="'+h(pd)+'">'+
        '<span class="jersey">'+h(p.jersey)+'</span><img class="head sm" src="'+h(p.headshot)+'" alt="'+h(p.name)+'" data-ph="'+h(p.id)+'" data-tm="'+h(t.teamName)+'" data-jn="'+h(p.jersey)+'"/>'+
        '<span class="grow">'+h(p.name)+"<small>"+h(p.positionAbbr)+"</small></span>"+
        (p.subbedIn?'<span class="fp-b in inl" title="Entrou">'+FP_SWAP+"</span>":"")+
        (mode==="perf"&&v!=null?'<b class="fp-r inl '+fpCls(v)+'">'+v.toFixed(1)+"</b>":"")+"</div>";
    }).join("");
  };
  return'<div class="fp-wrap">'+
    '<div class="fp-modes" role="tablist"><button type="button" data-v="perf"'+(mode==="perf"?' class="on"':"")+(any?"":" disabled")+'>Desempenho</button><button type="button" data-v="pos"'+(mode==="pos"?' class="on"':"")+">Posição</button></div>"+
    '<p class="fp-note" hidden>Nota estimada pelo DBZSCORE: parte de 6,3 e soma gols, assistências, chutes no gol, defesas, faltas, cartões, gols sofridos e o resultado do jogo. Não é a nota oficial de nenhum site.</p>'+
    head(L[0],0)+'<div class="fp-pitch">'+fpPitchSvg()+place(R[0],0)+place(R[1],1)+"</div>"+head(L[1],1)+
    '<div class="fp-benches">'+bench(L[0],0)+bench(L[1],1)+"</div></div>";
}

function lxPitch(m,st){
  var f=LX_PF[st.pf],list=[];
  m.plays.forEach(function(p,i){if(!f||f.indexOf(p.kind)>=0)list.push([p,i])});
  var st2="";
  for(var i=0;i<10;i++)st2+='<rect x="'+(1+i*10.3)+'" y="1" width="10.3" height="66" class="'+(i%2?"fx-g1":"fx-g2")+'"/>';
  var ln='<g class="fx-ln"><rect x="1" y="1" width="103" height="66"/><line x1="52.5" y1="1" x2="52.5" y2="67"/><circle cx="52.5" cy="34" r="9.15"/>'+
    '<rect x="1" y="13.85" width="16.5" height="40.3"/><rect x="87.5" y="13.85" width="16.5" height="40.3"/>'+
    '<rect x="1" y="24.85" width="5.5" height="18.3"/><rect x="98.5" y="24.85" width="5.5" height="18.3"/>'+
    '<path d="M17.5,26.7 A9.15,9.15 0 0 1 17.5,41.3"/><path d="M87.5,26.7 A9.15,9.15 0 0 0 87.5,41.3"/></g>';
  var pins=list.map(function(a){return lxPin(a[0],a[1])}).join("");
  var last=list.length?list[list.length-1][0]:null,ball="";
  if(last){
    var q=lxPos(last),lab=(m.jer[last.pid]?m.jer[last.pid]+" ":"")+(last.player||(last.clock||"")),
      lx=Math.min(88,Math.max(17,q[0])),ly=q[1]<14?q[1]+8:q[1]-5.5;
    ball='<g class="fx-ball"><circle cx="'+q[0].toFixed(1)+'" cy="'+q[1].toFixed(1)+'" r="2.1" fill="#fff" stroke="#111" stroke-width=".5"/>'+
      '<text x="'+lx.toFixed(1)+'" y="'+ly.toFixed(1)+'" text-anchor="middle">'+h(lab)+'</text></g>';
  }
  return'<section class="hud-panel fx-card"><h3 class="fx-h">Mapa de lances</h3>'+
    lxChips("pf",st.pf,[["all","Todos"],["goal","Gols"],["shot","Chutes"],["corner","Escanteios"],["foul","Faltas"],["card","Cartões"]])+
    '<svg class="fx-pitch" viewBox="0 0 105 68" role="img" aria-label="Mapa de lances">'+st2+ln+
    '<text x="4" y="5.2" class="fx-dir">'+h(m.names[0])+' ▶</text><text x="101" y="5.2" text-anchor="end" class="fx-dir">◀ '+h(m.names[1])+'</text>'+
    pins+ball+'</svg><p class="fx-cap" id="fxpc">'+lxCap(last,m)+'</p>'+
    '<p class="fx-note">Posições aproximadas: a fonte não envia coordenadas, então cada lance é posto na zona típica do seu tipo. Toque num ícone para ver o lance.</p></section>';
}

/* ---------- Linha do tempo ---------- */
function lxAssist(t){
  var a=String(t||"").match(/(?:assisted by|assist[eê]ncia de)\s+([^.(]+)/i);
  return a?a[1].trim():"";
}
function lxSub(x){
  var t=String(x.text||"").replace(/^[^.]*\.\s*/,""),
    mm=t.match(/(.+?)\s+(?:replaces|substitui(?:u)?)\s+(.+?)(?:\s+(?:because|due|por)\b|\.|$)/i);
  if(mm&&mm[1].trim().length>=3&&mm[2].trim().length>=3)return{i:mm[1].trim(),o:mm[2].trim()};
  var pp=x.parts||[];
  if(pp.length>=2&&pp[0].name&&pp[1].name)return{i:pp[0].name,o:pp[1].name};
  return mm?{i:mm[1].trim(),o:mm[2].trim()}:null;
}
function lxPd(x,m,e){
  if(!x.pid)return"";
  var r=m.r,tm=x.side===1?r.away:r.home;
  return' data-pid="'+h(x.pid)+'" data-lg="'+h(e)+'" data-pd="'+h(JSON.stringify({id:x.pid,name:x.player,img:x.head,team:tm.name,teamId:tm.id,teamLogo:tm.logo}))+'"';
}
function lxBody(x,m,e){
  var who=x.player?'<strong class="fx-who">'+h(x.player)+'</strong>':"",sub="",k=x.kind;
  if(k==="goal"){
    sub=(x.own?"Gol contra":x.pen?"Gol de pênalti":"Gol")+(x.sc?' · <b class="fx-sc">'+x.sc[0]+"–"+x.sc[1]+"</b>":"");
    var a=lxAssist(x.text);if(a)sub+="<br>Assistência: "+h(a);
  }else if(k==="sub"){
    var s=lxSub(x);
    if(s){who='<span class="fx-in">▲ '+h(s.i)+'</span>';sub='<span class="fx-out">▼ '+h(s.o)+"</span>"}
    else sub="Substituição";
  }else if(k==="var"){sub=h(String(x.text||"").slice(0,80))}
  else sub=h(LX_LB[k]||"");
  return'<div class="fx-body"'+(k==="sub"?"":lxPd(x,m,e))+">"+who+(sub?"<small>"+sub+"</small>":"")+"</div>";
}
function lxTimeline(m,st,e){
  var F={all:null,goal:["goal","pen"],card:["yc","rc"],sub:["sub"]},ok={goal:1,pen:1,yc:1,rc:1,sub:1,var:1};
  var list=m.ev.filter(function(x){return ok[x.kind]&&(!F[st.f]||F[st.f].indexOf(x.kind)>=0)});
  var chips=lxChips("f",st.f,[["all","Tudo"],["goal","Gols"],["card","Cartões"],["sub","Substituições"]])+
    '<div class="fx-chips" data-g="nf"><button data-v="'+(st.nf==="1"?"0":"1")+'" class="on">'+(st.nf==="1"?"⇅ Mais recentes primeiro":"⇅ Ordem do jogo")+"</button></div>";
  var head='<section class="fx-card fx-tl"><h3 class="fx-h">Lances do jogo</h3>'+chips;
  if(!list.length)return head+'<p class="empty">'+(m.ev.length?"Nenhum lance neste filtro.":"Sem lances ainda.")+"</p></section>";
  var groups=[];
  list.forEach(function(x){
    var p=m.per(x),g=groups.length&&groups[groups.length-1].p===p?groups[groups.length-1]:null;
    if(!g){g={p:p,rows:[]};groups.push(g)}
    g.rows.push(x);
  });
  var LB=["","1º tempo","2º tempo","Prorrogação","Pênaltis"];
  if(st.nf==="1"){groups=groups.slice().reverse();groups.forEach(function(g){g.rows=g.rows.slice().reverse()})}
  var out=groups.map(function(g){
    var ex=g.p===2&&m.ht?'<span class="fx-dim">Intervalo '+m.ht[0]+"–"+m.ht[1]+"</span>":"";
    return'<div class="fx-per"><span>'+LB[g.p]+"</span>"+ex+'</div><ul class="fx-list">'+g.rows.map(function(x){
      var b=lxBody(x,m,e),sd=x.side===0?0:1;
      return'<li class="fx-row k-'+x.kind+'"><div class="fx-s0">'+(sd===0?b:"")+'</div><div class="fx-mid"><span class="fx-ic">'+LX_IC[x.kind]+'</span><span class="fx-tm">'+h(x.clock)+'</span></div><div class="fx-s1">'+(sd===1?b:"")+"</div></li>";
    }).join("")+"</ul>";
  }).join("");
  return head+out+"</section>";
}

/* ---------- Comentário ---------- */
function lxComments(m,st){
  var main={goal:1,pen:1,yc:1,rc:1,sub:1,var:1,sot:1,per:1};
  if(!m.cm.length)return'<p class="empty">O comentário lance a lance ainda não está disponível para esta partida. Veja os lances principais na aba Lances.</p>';
  var list=m.cm.filter(function(x){return st.cf==="all"||main[x.kind]});
  list=list.slice().reverse();
  return lxChips("cf",st.cf,[["main","Principais"],["all","Todos os lances"]])+
    '<ul class="fx-cmt">'+list.map(function(x){
      return'<li class="k-'+x.kind+(x.side>=0?" s"+x.side:"")+'"><span class="fx-tm">'+h(x.clock||"")+'</span><span class="fx-ic">'+LX_IC[x.kind]+"</span><p>"+h(x.text)+"</p></li>";
    }).join("")+"</ul>";
}

function lxLastHtml(m,e){
  var l=null;
  for(var i=m.ev.length-1;i>=0;i--){var x=m.ev[i];if(x.kind==="goal"||x.kind==="yc"||x.kind==="rc"){l=x;break}}
  if(!l)return"";
  return'<p class="fx-last k-'+l.kind+'"><span class="fx-ic">'+LX_IC[l.kind]+"</span>"+h(l.player||LX_LB[l.kind])+" "+h(l.clock)+"</p>";
}
/*LX-END*/

async function _n(e,n){
  M.innerHTML=R("home",Ee(4));
  try{
    var url="/apis/site/v2/sports/soccer/"+e+"/summary?event="+n;
    var c=await q(url,"summary"),u=ln(c,e);
    if(!u)throw new Error("Jogo não encontrado");
    var m=lxModel(u),
      st={tab:"lances",f:"all",nf:u.match.status==="live"?"1":"0",pf:"all",cf:"main"};
    var hero=function(){
      var r=u.match,p=r.status==="live",hm=r.home.score!=null?r.home.score:0,aw=r.away.score!=null?r.away.score:0,
        y=Oe(r.home.id,e),v=Oe(r.away.id,e);
      return'<section class="hud-panel match-hero">'+
        '<p class="tag">'+(p?'<span class="live-lab"><span class="live-dot"></span>'+h(r.clock||"Ao vivo")+"</span>":h(r.leagueName))+"</p>"+
        '<div class="scoreboard">'+
        '<a class="mh-team" href="#/time/'+h(e)+"/"+h(r.home.id)+'">'+D(r.home.logo,r.home.name,56)+"<strong>"+h(r.home.shortName)+"</strong></a>"+
        '<div class="mh-score display">'+(r.status==="scheduled"?Pe(r.date):hm+"<span>–</span>"+aw)+"</div>"+
        '<a class="mh-team" href="#/time/'+h(e)+"/"+h(r.away.id)+'">'+D(r.away.logo,r.away.name,56)+"<strong>"+h(r.away.shortName)+"</strong></a>"+
        "</div>"+lxLastHtml(m,e)+
        '<p class="lead">'+h(r.venue||"")+" "+(r.status==="finished"?"· Encerrado":"")+"</p>"+
        '<div class="fav-row"><button class="ghost-star" id="fh">'+(y?"★":"☆")+" "+h(r.home.shortName)+"</button>"+
        '<button class="ghost-star" id="fa">'+(v?"★":"☆")+" "+h(r.away.shortName)+"</button></div>"+
        (r.status==="finished"?'<a class="yt-btn" href="'+h(kn(r))+'" target="_blank" rel="noopener">▶ Melhores momentos no YouTube</a>':"")+
        "</section>";
    };
    var statsHtml=function(){
      return u.stats.map(function(s){
        var k=s.homeNum+s.awayNum||1;
        return'<div class="stat"><div class="stat-lab"><span>'+h(s.home)+"</span><span>"+h(s.label)+"</span><span>"+h(s.away)+
          '</span></div><div class="bar"><i style="width:'+s.homeNum/k*100+'%"></i></div></div>';
      }).join("")||'<p class="empty">Sem estatísticas.</p>';
    };
    var lineHtml=function(){return fpHtml(u,e,st)||lineHtmlOld()};
    var lineHtmlOld=function(){
      var one=function(t){
        var st1=t.players.filter(function(x){return x.starter}),bn=t.players.filter(function(x){return!x.starter});
        var row=function(L){
          return'<div class="xi" data-pid="'+h(L.id)+'" data-lg="'+h(e)+'" data-pd="'+h(JSON.stringify({id:L.id,name:L.name,img:L.headshot,jersey:L.jersey,pos:L.position,team:t.teamName,teamId:t.teamId,teamLogo:t.logo}))+'">'+
            '<span class="jersey">'+h(L.jersey)+'</span><img class="head sm" src="'+h(L.headshot)+'" alt="'+h(L.name)+'" data-ph="'+h(L.id)+'" data-tm="'+h(t.teamName)+'" data-jn="'+h(L.jersey)+'"/>'+
            '<span class="grow">'+h(L.name)+"<small>"+h(L.positionAbbr)+"</small></span></div>";
        };
        return"<div><h3 class=\"sec\">"+D(t.logo,t.teamName,18)+" "+h(t.teamName)+" · "+h(t.formation)+"</h3>"+st1.map(row).join("")+
          (bn.length?'<p class="muted-lab" style="margin:10px 0 6px">Banco</p>'+bn.map(row).join(""):"")+"</div>";
      };
      return u.lineups.length?'<div class="lead-grid">'+u.lineups.map(one).join("")+"</div>":'<p class="empty">Escalação não disponível.</p>';
    };
    var compRow=function(){
      var r=u.match,rd=Qe(r),lg=P(e);
      return'<a class="fx-comp" href="#/liga/'+h(e)+'"><span class="fx-ic">⚽</span><span>Futebol, '+h(r.leagueName||(lg&&lg.name)||"")+(rd?", "+h(rd):"")+'</span><i>›</i></a>';
    };
    M.innerHTML=R("home",'<div id="fxh">'+hero()+'</div><div class="chips fx-tabs" id="tabs">'+
      '<button data-t="lances" class="on">Lances</button><button data-t="coment">Comentário</button>'+
      '<button data-t="stats">Estatísticas</button><button data-t="escalacao">Escalação</button></div><div id="panel"></div>');
    var panel=S("#panel"),tabs=S("#tabs"),box=S("#fxh");
    var draw=function(){
      var t=st.tab;
      panel.innerHTML=t==="stats"?statsHtml():t==="escalacao"?lineHtml():t==="coment"?lxComments(m,st):
        compRow()+lxFlow(m)+lxPitch(m,st)+lxTimeline(m,st,e);
    };
    draw();
    tabs.addEventListener("click",function(ev){
      var b=ev.target.closest("button");if(!b)return;
      tabs.querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
      b.classList.add("on");st.tab=b.dataset.t;draw();
    });
    panel.addEventListener("click",function(ev){
      var fm=ev.target.closest(".fp-modes button");
      if(fm){if(!fm.disabled){st.fpm=fm.dataset.v;draw()}return}
      if(ev.target.closest(".fp-info")){var nt=panel.querySelector(".fp-note");if(nt)nt.hidden=!nt.hidden;return}
      var ch=ev.target.closest(".fx-chips button");
      if(ch){var g=ch.parentNode.dataset.g;st[g]=ch.dataset.v;draw();return}
      var pin=ev.target.closest(".fx-pin");
      if(pin){var cp=S("#fxpc");if(cp)cp.innerHTML=lxCap(m.plays[+pin.dataset.i],m)}
    });
    var scrub=function(ev){lxScrub(ev,m)};
    panel.addEventListener("pointerdown",scrub);
    panel.addEventListener("pointermove",function(ev){if(ev.pointerType==="mouse"?ev.buttons===0||ev.buttons===1:ev.buttons)scrub(ev)});
    box.addEventListener("click",function(ev){
      var r=u.match;
      if(ev.target.closest("#fh")){Ce({league:e,id:r.home.id,name:r.home.name,logo:r.home.logo}),H()}
      else if(ev.target.closest("#fa")){Ce({league:e,id:r.away.id,name:r.away.name,logo:r.away.logo}),H()}
    });
    if(u.match.status==="live"){
      var tm=setInterval(async function(){
        if(!document.body.contains(panel)||location.hash.indexOf("/jogo/"+e+"/"+n)<0){clearInterval(tm);return}
        try{
          var c2=await q(url,"summary"),u2=ln(c2,e);
          if(u2){u=u2;m=lxModel(u);box.innerHTML=hero();draw();if(u.match.status!=="live")clearInterval(tm)}
        }catch(x){}
      },30000);
    }
  }catch(c){
    M.innerHTML=R("home",'<p class="empty">'+h(c.message)+"</p>");
  }
}

/* ===== Página do time (v2): Detalhes, Partidas, Classificações, Estatísticas, Equipe, Melhores jogadores ===== */
var TMZ=DBZ_I18N.tz;
function tmDay(iso){try{return new Intl.DateTimeFormat("en-CA",{timeZone:TMZ,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(iso))}catch(x){return""}}
function tmShort(iso){try{return new Intl.DateTimeFormat(DBZ_I18N.locale,{timeZone:TMZ,day:"2-digit",month:"short"}).format(new Date(iso)).replace(".","")}catch(x){return""}}
function tmNorm(s){return String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim()}
function tmFix(raw){
  var ev=(raw&&raw.events)||[];
  ev.forEach(function(e){
    var cp=(e.competitions&&e.competitions[0])||e;
    (cp.competitors||[]).forEach(function(c){
      if(!c)return;
      ["score","shootoutScore"].forEach(function(k){var v=c[k];if(v&&typeof v==="object")c[k]=v.displayValue!=null?v.displayValue:v.value});
    });
  });
  return raw;
}
function tmView(m,id){
  var home=m.home.id===id,us=home?m.home:m.away,th=home?m.away:m.home,fin=m.status==="finished",gf=us.score,ga=th.score,res=null,r90=null;
  if(fin&&gf!=null&&ga!=null){
    r90=gf>ga?"V":gf<ga?"D":"E";res=r90;
    if(r90==="E"&&us.shootoutScore!=null&&th.shootoutScore!=null)res=us.shootoutScore>th.shootoutScore?"V":"D";
  }
  return{m:m,home:home,us:us,th:th,fin:fin,gf:gf,ga:ga,res:res,r90:r90};
}
function tmScore(v){
  if(v.gf==null||v.ga==null)return"–";
  var t=v.gf+"-"+v.ga;
  if(v.us.shootoutScore!=null&&v.th.shootoutScore!=null)t+=" ("+v.us.shootoutScore+"-"+v.th.shootoutScore+")";
  return t;
}
function tmZone(note){
  var s=tmNorm(note);
  if(!s)return"";
  if(/rebaix|relega/.test(s))return"red";
  if(/(libert|champions)/.test(s)&&/(qualif|previa|preliminar|playoff)/.test(s))return"lime";
  if(/libert|champions/.test(s))return"green";
  if(/sul|sudamer|europa|confer/.test(s))return"blue";
  return"gray";
}
function tmGroup(p){
  var a=String(p.positionAbbr||"").toUpperCase(),n=tmNorm(p.position);
  if(a==="G"||a==="GK"||/goalk|goleir/.test(n))return 0;
  if(/^(D|CD|CB|LB|RB|SW|LWB|RWB|CD-L|CD-R)$/.test(a)||/defen|zagu|lateral|back/.test(n))return 1;
  if(/^(M|CM|DM|AM|LM|RM|CAM|CDM|MC|CM-L|CM-R)$/.test(a)||/meio|midf|volante/.test(n))return 2;
  if(/^(F|ST|LW|RW|CF|SS|FW)$/.test(a)||/atac|forw|strik|wing|ponta/.test(n))return 3;
  return 4;
}
function tmCoach(raw){
  var r=raw&&raw.value?raw.value:raw,cs=r&&r.coach;
  if(!Array.isArray(cs)||!cs.length)return null;
  var c=cs[0]||{},name=((c.firstName||"")+" "+(c.lastName||"")).trim()||c.displayName||c.fullName||"";
  if(!name)return null;
  return{name:name,nat:c.citizenship||"",id:c.id?String(c.id):""};
}
function tmCalc(list){
  var z=function(){return{j:0,v:0,e:0,d:0,gp:0,gc:0}};
  var s={j:0,v:0,e:0,d:0,gp:0,gc:0,cs:0,marc:0,semMarc:0,big:null,casa:z(),fora:z()};
  list.forEach(function(x){
    if(!x.fin||x.gf==null||x.ga==null)return;
    var k=x.home?s.casa:s.fora;
    [s,k].forEach(function(t){t.j++;t.gp+=x.gf;t.gc+=x.ga;if(x.r90==="V")t.v++;else if(x.r90==="E")t.e++;else t.d++});
    if(x.ga===0)s.cs++;
    if(x.gf>0)s.marc++;else s.semMarc++;
    var df=x.gf-x.ga;
    if(df>0&&(!s.big||df>s.big.df||(df===s.big.df&&x.gf>s.big.gf)))s.big={df:df,gf:x.gf,ga:x.ga,op:x.th.shortName||x.th.name};
  });
  return s;
}
async function Un(e,n){
  M.innerHTML=R("favs",Ee());
  try{
    var rs=await Promise.allSettled([
      q(`/apis/site/v2/sports/soccer/${e}/teams/${n}?enable=roster`,"team"),
      q(`/apis/site/v2/sports/soccer/${e}/teams/${n}/schedule?`,"team"),
      q(`/apis/site/v2/sports/soccer/${e}/teams/${n}/schedule?fixture=true`,"team"),
      q(`/apis/site/v2/sports/soccer/${e}/teams/${n}/roster?`,"team"),
      q(`/apis/v2/sports/soccer/${e}/standings?`,"standings"),
      q(`/apis/site/v2/sports/soccer/${e}/statistics?`,"stats")
    ]);
    var val=function(k){return rs[k].status==="fulfilled"?rs[k].value:null};
    if(rs.every(function(r){return r.status==="rejected"}))throw rs[0].reason;

    var info=val(0),u=info?un(info,e):null;

    /* jogos (resultados + próximos), sem repetir */
    var seen=new Set(),all=[];
    [1,2].forEach(function(k){
      var raw=val(k);
      if(!raw)return;
      try{gn(tmFix(raw),e).forEach(function(m){if(!seen.has(m.id)){seen.add(m.id);all.push(m)}})}catch(x){}
    });
    all=all.filter(function(m){return m.home.id===n||m.away.id===n});
    all.sort(function(a,b){return a.date.localeCompare(b.date)});
    var views=all.map(function(m){return tmView(m,n)});

    /* nome/escudo mesmo se a ficha do time falhar */
    if(!u){
      var fav=U().teams.find(function(t){return t.id===n&&t.league===e}),any=views[0];
      var nm=(fav&&fav.name)||(any&&any.us.name)||"Time";
      u={id:n,leagueSlug:e,name:nm,shortName:nm,abbreviation:"",logo:(fav&&fav.logo)||(any&&any.us.logo)||_(n),standingSummary:""};
    }

    var lg=P(e),isFav=Oe(n,e);
    var venue=(info&&info.team&&info.team.franchise&&info.team.franchise.venue&&info.team.franchise.venue.fullName)||"";
    var flag=lg&&lg.countryCode?Ve(lg.countryCode,40):null;

    /* elenco e treinador */
    var rosterRaw=val(3),players=[];
    try{players=dn(rosterRaw||info||{})}catch(x){players=[]}
    if(!players.length&&info){try{players=dn(info)}catch(x){}}
    var coach=tmCoach(rosterRaw)||tmCoach(info&&info.team?info.team:info);

    /* líderes da liga que são do time */
    var lead={goals:[],assists:[]};
    try{if(val(5))lead=cn(val(5))}catch(x){}
    var mine=function(arr){return arr.filter(function(p){return tmNorm(p.teamName)===tmNorm(u.name)})};

    var st={tab:"detalhes",pmode:"lista",season:"",stand:[],loading:false,comp:"all",eq:"geral",cal:null};
    try{st.stand=rn(val(4))}catch(x){st.stand=[]}
    var today=tmDay(new Date());
    var focus=(views.find(function(v){return v.m.status!=="finished"})||views[views.length-1]);
    var fd=focus?tmDay(focus.m.date):today;
    st.cal={y:+fd.slice(0,4),m:+fd.slice(5,7)-1};

    var nowIso=new Date().toISOString();
    var liveV=views.filter(function(v){return v.m.status==="live"});
    var nextV=views.filter(function(v){return v.m.status==="scheduled"||(v.m.status==="other"&&v.m.date>=nowIso)});
    var doneV=views.filter(function(v){return v.fin});
    var teamRow=function(){
      for(var i=0;i<st.stand.length;i++){var r=st.stand[i].rows.find(function(x){return x.teamId===n});if(r)return{row:r,name:st.stand[i].name}}
      return null;
    };
    var avatar=function(name){return fxAv(name)};
    var img=function(src,name,cls,pid,tm,jn){return `<img class="${cls}" src="${h(src)}" alt="${h(name)}" data-fb="${h(avatar(name))}"${pid?` data-ph="${h(pid)}"`:""}${tm?` data-tm="${h(tm)}"`:""}${jn?` data-jn="${h(jn)}"`:""} onerror="this.onerror=null;this.src=this.dataset.fb"/>`};

    /* ---------- DETALHES ---------- */
    var vDet=function(){
      var out="",feat=liveV[0]||nextV[0]||doneV[doneV.length-1];
      if(feat){
        var m=feat.m,isLive=m.status==="live",lab=isLive?"Ao vivo":m.status==="finished"?"Último jogo":"Próximo jogo";
        var mid=m.status==="scheduled"
          ?`<b class="tm-time">${h(Pe(m.date))}</b><small>${h(tmShort(m.date))}</small>`
          :`<b class="tm-sc${isLive?" live":""}">${m.home.score??0} – ${m.away.score??0}</b><small>${h(isLive?(m.clock||"Ao vivo"):"Encerrado")}</small>`;
        var side=function(t){return `<span class="tm-side">${D(t.logo,t.name,48)}<span>${h(t.shortName||t.name)}</span></span>`};
        out+=`<a class="tm-card tm-feat" href="#/jogo/${h(m.leagueSlug)}/${h(m.id)}">
          <p class="kicker${isLive?" accent":""}">${h(lab)} · ${h(m.leagueName)}${Qe(m)?" · "+h(Qe(m)):""}</p>
          <div class="tm-row">${side(m.home)}<span class="tm-mid">${mid}</span>${side(m.away)}</div>
        </a>`;
      }
      var tr=teamRow();
      if(tr){
        var s=tr.row.stats;
        out+=`<section class="tm-card"><h3 class="tm-h">${h(P(e)?P(e).shortName:"Classificação")}</h3>
          <div class="tm-kpis">
            <div><b>${tr.row.rank}º</b><small>Posição</small></div>
            <div><b>${h(s.points)}</b><small>Pontos</small></div>
            <div><b>${h(s.played)}</b><small>Jogos</small></div>
            <div><b>${h(s.gd)}</b><small>Saldo</small></div>
          </div>
          <div class="tm-kpis sub">
            <div><b>${h(s.wins)}</b><small>V</small></div>
            <div><b>${h(s.draws)}</b><small>E</small></div>
            <div><b>${h(s.losses)}</b><small>D</small></div>
            <div><b>${h(s.for)}:${h(s.against)}</b><small>Gols</small></div>
          </div></section>`;
      }
      var last5=doneV.slice(-5);
      if(last5.length){
        out+=`<section class="tm-card"><h3 class="tm-h">Forma recente</h3>
          <div class="tm-form">${last5.map(function(v){return `<a class="tm-fm" href="#/jogo/${h(v.m.leagueSlug)}/${h(v.m.id)}"><span class="pill ${v.res||"E"}">${h(tmScore(v))}</span>${D(v.th.logo,v.th.name,26)}</a>`}).join("")}</div>
          <p class="tm-note">O mais recente fica à direita.</p></section>`;
      }
      if(nextV.length)out+=`<h3 class="sec">Próximos jogos</h3><div class="cards">${nextV.slice(0,3).map(function(v){return Se(v.m,true)}).join("")}</div>`;
      if(!out)out='<p class="empty">Sem informações deste time por enquanto.</p>';
      return out;
    };

    /* ---------- PARTIDAS ---------- */
    var seg=function(){return `<div class="tm-seg"><button data-act="pmode" data-v="lista" class="${st.pmode==="lista"?"on":""}">Lista</button><button data-act="pmode" data-v="cal" class="${st.pmode==="cal"?"on":""}">Calendário</button></div>`};
    var vCal=function(){
      var y=st.cal.y,mo=st.cal.m,first=new Date(Date.UTC(y,mo,1)).getUTCDay(),days=new Date(Date.UTC(y,mo+1,0)).getUTCDate();
      var label=new Intl.DateTimeFormat(DBZ_I18N.locale,{month:"long",year:"numeric",timeZone:"UTC"}).format(new Date(Date.UTC(y,mo,1)));
      var by={};
      views.forEach(function(v){var d=tmDay(v.m.date);if(!by[d])by[d]=v});
      var cells="";
      for(var i=0;i<first;i++)cells+='<div class="cal-c blank"></div>';
      for(var d=1;d<=days;d++){
        var key=y+"-"+String(mo+1).padStart(2,"0")+"-"+String(d).padStart(2,"0"),v=by[key];
        if(!v){cells+=`<div class="cal-c"><span class="d">${d}</span></div>`;continue}
        var isLive=v.m.status==="live",txt=v.m.status==="scheduled"?Pe(v.m.date):v.fin?tmScore(v).split(" ")[0]:(isLive?"Ao vivo":"—");
        cells+=`<a class="cal-c has ${v.home?"home":"away"}${isLive?" live":""}" href="#/jogo/${h(v.m.leagueSlug)}/${h(v.m.id)}">
          <span class="d">${d}</span>${D(v.th.logo,v.th.name,24)}<span class="r ${v.fin?v.res:"n"}">${h(txt)}</span></a>`;
      }
      return `<div class="tm-card">
        <div class="cal-nav"><button data-act="cal" data-d="-1" aria-label="Mês anterior">‹</button><strong>${h(label)}</strong><button data-act="cal" data-d="1" aria-label="Próximo mês">›</button></div>
        <div class="cal-grid cal-head">${["dom.","seg.","ter.","qua.","qui.","sex.","sáb."].map(function(x){return `<span>${x}</span>`}).join("")}</div>
        <div class="cal-grid">${cells}</div>
        <div class="cal-leg"><span><i class="home"></i>Casa</span><span><i class="away"></i>Fora</span></div></div>`;
    };
    var vPar=function(){
      if(st.pmode==="cal")return seg()+vCal();
      var up=views.filter(function(v){return !v.fin}),dn_=doneV.slice().reverse(),out=seg();
      if(up.length)out+=`<h3 class="sec">Próximos</h3><div class="cards">${up.map(function(v){return Se(v.m,true)}).join("")}</div>`;
      if(dn_.length)out+=`<h3 class="sec">Resultados</h3><div class="cards">${dn_.map(function(v){return Se(v.m,true)}).join("")}</div>`;
      if(!up.length&&!dn_.length)out+='<p class="empty">Sem jogos.</p>';
      return out;
    };

    /* ---------- CLASSIFICAÇÕES ---------- */
    var curY=new Date().getFullYear();
    var vCla=function(){
      var opts=[["",String(curY)],[String(curY-1),String(curY-1)],[String(curY-2),String(curY-2)]];
      var head=`<div class="tm-sels"><span class="tm-pill">${h(P(e)?P(e).name:e)}</span>
        <select id="sel-season" class="tm-sel" aria-label="Temporada">${opts.map(function(o){return `<option value="${o[0]}"${st.season===o[0]?" selected":""}>${o[1]}</option>`}).join("")}</select></div>`;
      if(st.loading)return head+Ee(4);
      if(!st.stand.length)return head+'<p class="empty">Classificação indisponível.</p>';
      var groups=st.stand.slice().sort(function(a,b){
        var ha=a.rows.some(function(r){return r.teamId===n})?0:1,hb=b.rows.some(function(r){return r.teamId===n})?0:1;return ha-hb;
      });
      return head+groups.map(function(g){
        var last="",rows="";
        g.rows.forEach(function(r){
          var note=r.note||"",z=tmZone(note);
          if(note!==last){last=note;if(note)rows+=`<tr class="zh ${z}"><td colspan="5">${h(note)}</td></tr>`}
          rows+=`<tr class="${r.teamId===n?"me ":""}z-${z}"><td class="rk-c">${r.rank}</td>
            <td><a href="#/time/${h(e)}/${h(r.teamId)}">${D(r.logo,r.teamName,20)} <span>${h(r.teamName)}</span></a></td>
            <td>${h(r.stats.played)}</td><td>${h(r.stats.gd)}</td><td><strong>${h(r.stats.points)}</strong></td></tr>`;
        });
        return `<div class="table-wrap"><h3 class="sec">${h(g.name)}</h3><table class="stand tm-stand">
          <thead><tr><th>#</th><th>Time</th><th>J</th><th>SG</th><th>PTS</th></tr></thead><tbody>${rows}</tbody></table></div>`;
      }).join("");
    };

    /* ---------- ESTATÍSTICAS ---------- */
    var vEst=function(){
      var slugs=[],names={};
      doneV.forEach(function(v){if(slugs.indexOf(v.m.leagueSlug)<0){slugs.push(v.m.leagueSlug);names[v.m.leagueSlug]=(P(v.m.leagueSlug)&&P(v.m.leagueSlug).shortName)||v.m.leagueShortName||v.m.leagueSlug}});
      var sel=slugs.length>1?`<div class="tm-sels"><select id="sel-comp" class="tm-sel" aria-label="Competição"><option value="all">Todas as competições</option>${slugs.map(function(s){return `<option value="${h(s)}"${st.comp===s?" selected":""}>${h(names[s])}</option>`}).join("")}</select></div>`:"";
      var list=doneV.filter(function(v){return st.comp==="all"||v.m.leagueSlug===st.comp});
      if(!list.length)return sel+'<p class="empty">Sem jogos encerrados nesta temporada.</p>';
      var s=tmCalc(list),pg=function(a,b){return b?(a/b).toFixed(2).replace(".",","):"0"},apr=s.j?Math.round((s.v*3+s.e)/(s.j*3)*100)+"%":"—";
      var row=function(a,b){return `<div class="tm-line"><span>${a}</span><b>${b}</b></div>`};
      var blk=function(t,rows){return `<section class="tm-card"><h3 class="tm-h">${t}</h3>${rows.join("")}</section>`};
      var sub=function(t){return `<tr><td>${t.j}</td><td>${t.v}</td><td>${t.e}</td><td>${t.d}</td><td>${t.gp}:${t.gc}</td></tr>`};
      return sel
        +blk("Resumo",[row("Partidas",s.j),row("Vitórias",s.v),row("Empates",s.e),row("Derrotas",s.d),row("Gols marcados",s.gp),row("Gols sofridos",s.gc),row("Saldo de gols",(s.gp-s.gc>0?"+":"")+(s.gp-s.gc)),row("Aproveitamento",apr)])
        +blk("Atacando",[row("Gols por jogo",pg(s.gp,s.j)),row("Jogos marcando",s.marc),row("Jogos sem marcar",s.semMarc),row("Maior vitória",s.big?`${s.big.gf}-${s.big.ga} (${h(s.big.op)})`:"—")])
        +blk("Defendendo",[row("Gols sofridos por jogo",pg(s.gc,s.j)),row("Jogos sem sofrer gol",s.cs),row("Jogos sofrendo gol",s.j-s.cs)])
        +`<section class="tm-card"><h3 class="tm-h">Casa × Fora</h3><div class="table-wrap"><table class="stand tm-stand">
          <thead><tr><th></th><th>J</th><th>V</th><th>E</th><th>D</th><th>Gols</th></tr></thead>
          <tbody><tr><td><b>Casa</b></td>${sub(s.casa).slice(4)}<tr><td><b>Fora</b></td>${sub(s.fora).slice(4)}</tbody></table></div></section>`;
    };

    /* ---------- EQUIPE ---------- */
    var vEq=function(){
      if(!players.length&&!coach)return '<p class="empty">Elenco indisponível.</p>';
      var chips=`<div class="chips tm-sub-chips">${[["geral","Geral"],["idade","Idade"],["altura","Altura"]].map(function(c){return `<button data-act="eq" data-v="${c[0]}" class="${st.eq===c[0]?"on":""}">${c[1]}</button>`}).join("")}</div>`;
      var out=chips;
      if(coach)out+=`<section class="tm-card tm-people"><div class="leader">${img(coach.id?Be(coach.id):avatar(coach.name),coach.name,"head")}<span class="grow"><strong>${h(coach.name)}</strong><small>Treinador${coach.nat?" · "+h(coach.nat):""}</small></span></div></section>`;
      var titles=["Goleiros","Defensores","Meio-campistas","Atacantes","Outros"],order=[3,2,1,0,4];
      order.forEach(function(g){
        var ps=players.filter(function(p){return tmGroup(p)===g});
        if(!ps.length)return;
        ps.sort(function(a,b){var x=parseInt(a.jersey,10),y=parseInt(b.jersey,10);return(isNaN(x)?999:x)-(isNaN(y)?999:y)});
        out+=`<section class="tm-card tm-people"><h3 class="tm-h">${titles[g]}</h3>${ps.map(function(p){
          var extra=st.eq==="idade"?(p.age!=null?p.age+" anos":"—"):st.eq==="altura"?(p.height||"—"):"";
          return `<div class="leader tm-pl" data-pid="${h(p.id)}" data-lg="${h(e)}" data-pd="${h(JSON.stringify({id:p.id,name:p.name,img:p.headshot,age:p.age,nat:p.nationality,flag:p.flag,height:p.height,jersey:p.jersey,pos:p.position,team:u.name,teamId:n,teamLogo:u.logo}))}">${img(p.headshot,p.name,"head",p.id,u.name,p.jersey)}
            <span class="grow"><strong>${h(p.name)}</strong><small><span class="tm-jn">${h(p.jersey)}</span> ${h(p.positionAbbr)} ${p.flag?`<img class="tm-flag" src="${h(p.flag)}" alt="" onerror="this.style.display='none'"/>`:""}${p.nationality?h(p.nationality):""}</small></span>
            ${extra?`<span class="val tm-val">${h(extra)}</span>`:""}</div>`;
        }).join("")}</section>`;
      });
      return out;
    };

    /* ---------- MELHORES JOGADORES ---------- */
    var vMel=function(){
      var blk=function(t,arr,unit){
        var a=mine(arr);
        return `<section class="tm-card tm-people"><h3 class="tm-h">${t}</h3>${a.length?a.map(function(p){return `<div class="leader" data-pid="${h(p.athleteId)}" data-lg="${h(e)}" data-pd="${h(JSON.stringify({id:p.athleteId,name:p.name,img:p.headshot,team:p.teamName}))}"><span class="rk">${p.rank}</span>${img(p.headshot,p.name,"head",p.athleteId,p.teamName)}<span class="grow"><strong>${h(p.shortName)}</strong><small>${h(unit)} · ${h(P(e)?P(e).shortName:"")}</small></span><span class="val">${p.value}</span></div>`}).join(""):'<p class="empty">Nenhum jogador do time entre os líderes da competição.</p>'}</section>`;
      };
      return blk("Artilheiros",lead.goals,"Posição no ranking de gols")+blk("Assistências",lead.assists,"Posição no ranking de assistências");
    };

    /* ---------- montagem da página ---------- */
    M.innerHTML=R("favs",`<section class="hud-panel hero team-hero">
        ${D(u.logo,u.name,72)}
        <h1 class="display">${h(u.name)}</h1>
        <p class="lead tm-country">${flag?`<img class="tm-flag lg" src="${h(flag)}" alt="" onerror="this.style.display='none'"/>`:""}${h((lg&&lg.country)||"")}${lg?" · "+h(lg.name):""}</p>
        ${u.standingSummary?`<p class="lead">${h(u.standingSummary)}</p>`:""}
        ${venue?`<p class="lead tm-venue">Estádio: ${h(venue)}</p>`:""}
        <button class="ghost-star" id="fav">${isFav?"★ Favorito":"☆ Favoritar"}</button>
      </section>
      <div class="chips" id="tabs">
        <button data-t="detalhes" class="on">Detalhes</button>
        <button data-t="partidas">Partidas</button>
        <button data-t="classificacoes">Classificações</button>
        <button data-t="estatisticas">Estatísticas</button>
        <button data-t="equipe">Equipe</button>
        <button data-t="melhores">Melhores jogadores</button>
      </div>
      <div id="panel"></div>`);

    var panel=S("#panel");
    var draw=function(){
      var f={detalhes:vDet,partidas:vPar,classificacoes:vCla,estatisticas:vEst,equipe:vEq,melhores:vMel}[st.tab]||vDet;
      try{panel.innerHTML=f()}catch(x){panel.innerHTML='<p class="empty">Não foi possível montar esta aba.</p>'}
    };
    draw();

    var favBtn=S("#fav");
    favBtn&&favBtn.addEventListener("click",function(){Ce({league:e,id:n,name:u.name,logo:u.logo});H()});

    var tabs=S("#tabs");
    tabs&&tabs.addEventListener("click",function(ev){
      var b=ev.target.closest("button");
      if(!b||!b.dataset.t)return;
      tabs.querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
      b.classList.add("on");
      st.tab=b.dataset.t;
      draw();
      try{b.scrollIntoView({inline:"center",block:"nearest"})}catch(x){}
    });

    panel.addEventListener("click",function(ev){
      var b=ev.target.closest("[data-act]");
      if(!b)return;
      var a=b.dataset.act;
      if(a==="pmode"){st.pmode=b.dataset.v;draw()}
      else if(a==="eq"){st.eq=b.dataset.v;draw()}
      else if(a==="cal"){
        var d=Number(b.dataset.d)||0,t=new Date(Date.UTC(st.cal.y,st.cal.m+d,1));
        st.cal={y:t.getUTCFullYear(),m:t.getUTCMonth()};draw();
      }
    });
    panel.addEventListener("change",async function(ev){
      var t=ev.target;
      if(t.id==="sel-comp"){st.comp=t.value;draw()}
      else if(t.id==="sel-season"){
        st.season=t.value;st.loading=true;draw();
        try{st.stand=rn(await q(`/apis/v2/sports/soccer/${e}/standings?${t.value?"season="+encodeURIComponent(t.value):""}`,"standings"))}catch(x){st.stand=[]}
        st.loading=false;draw();
      }
    });
  }catch(err){
    M.innerHTML=R("favs",`<p class="empty">${h(err&&err.message?err.message:"Não foi possível carregar o time.")}</p><button class="ghost-star" id="retry">Tentar de novo</button>`);
    var rt=S("#retry");
    rt&&rt.addEventListener("click",function(){H()});
  }
}
function Jn(){let e=U(),n=e.leagues.map(a=>P(a)).filter(Boolean);M.innerHTML=R("favs",`<section class="hud-panel hero">
      <p class="tag">Sua lista</p>
      <h1 class="display">Favoritos</h1>
    </section>
    <h2 class="sec">Competi\xE7\xF5es</h2>
    ${n.length?`<div class="league-grid">${n.map(a=>`<div class="league-row">
                <a href="#/liga/${h(a.slug)}">${LG(a.slug,28,Ve(a.countryCode,40)||"")}<span><strong>${h(a.shortName)}</strong><small>${h(a.country)}</small></span></a>
                <button class="star on" data-slug="${h(a.slug)}">${Me()}</button>
              </div>`).join("")}</div>`:'<p class="empty">Nenhuma liga favorita. Marque em Competi\xE7\xF5es.</p>'}
    <h2 class="sec">Times</h2>
    ${e.teams.length?`<div class="league-grid">${e.teams.map(a=>`<div class="league-row">
                <a href="#/time/${h(a.league)}/${h(a.id)}">${D(a.logo,a.name,28)}<span><strong>${h(a.name)}</strong></span></a>
                <button class="star on" data-team="${h(a.id)}" data-lg="${h(a.league)}">${Me()}</button>
              </div>`).join("")}</div>`:'<p class="empty">Nenhum time favorito ainda.</p>'}
    <h2 class="sec">Jogadores</h2>
    ${(e.players&&e.players.length)?`<div class="league-grid">${e.players.map(a=>`<div class="league-row">
                <a href="#/jogador/${h(a.league||"all")}/${h(a.id)}"><img class="head sr-img" src="${h(a.img||Be(a.id))}" alt="${h(a.name)}" data-ph="${h(a.id)}" data-tm="${h(a.team||"")}"/><span><strong>${h(a.name)}</strong></span></a>
                <button class="star on" data-pl="${h(a.id)}">${Me()}</button>
              </div>`).join("")}</div>`:'<p class="empty">Nenhum jogador favorito ainda.</p>'}`),M.querySelectorAll("button.star[data-slug]").forEach(a=>a.addEventListener("click",()=>{Ne(a.dataset.slug),H()})),M.querySelectorAll("button.star[data-team]").forEach(a=>a.addEventListener("click",()=>{let o=a;Ce({league:o.dataset.lg,id:o.dataset.team,name:"",logo:""}),H()})),M.querySelectorAll("button.star[data-pl]").forEach(a=>a.addEventListener("click",()=>{let n=U();n.players=(n.players||[]).filter(x=>String(x.id)!==a.dataset.pl);bn(n),H()}))}function wn(){try{return JSON.parse(localStorage.getItem(Ue)||"[]")}catch{return[]}}function $n(e){localStorage.setItem(Ue,JSON.stringify(e.slice(0,80)))}function Vn(){let e=wn(),un=new Set(e.filter(n=>!n.read).map(n=>n.id));e.forEach(n=>{n.read=!0}),$n(e),M.innerHTML=R("alerts",`<section class="hud-panel hero">
      <p class="tag">Ao vivo</p>
      <h1 class="display">Alertas</h1>
      <p class="lead">Gols, p\xEAnaltis, cart\xF5es, intervalo e fim de jogo.</p>
      ${e.length?'<button type="button" class="fx-clear">Limpar histórico</button>':""}
    </section>
    ${e.length?`<div class="fx-list">${e.map(n=>fxItem(n,un.has(n.id))).join("")}</div>`:'<div class="fx-empty"><span>🔔</span><p>Nenhum alerta ainda.</p><small>Favorite times e competições (★) para receber gols, cartões, intervalo e fim de jogo.</small></div>'}`),fxPanel(),fxBind()}var Ge=new Map;var FXK={goal:["GOL!","gol"],penalty:["P\u00caNALTI","penalti"],ht:["FIM DO 1\u00ba TEMPO","intervalo"],yellow:["CART\u00c3O AMARELO","amarelo"],red:["CART\u00c3O VERMELHO","vermelho"],ft:["FIM DE JOGO","fim"]},
FXI={goal:"\u26bd",penalty:"\ud83c\udfaf",ht:"\u23f8\ufe0f",yellow:"\ud83d\udfe8",red:"\ud83d\udfe5",ft:"\ud83c\udfc1"},FXA=null,FXB={},FXS=new Map,FXR=!1;
function fxCfg(){var c={sound:1,banner:1,kinds:{}};try{Object.assign(c,JSON.parse(localStorage.getItem("dbzscore-fx")||"{}"))}catch(e){}c.kinds=c.kinds||{};return c}
function fxCtx(){try{if(!FXA){var C=window.AudioContext||window.webkitAudioContext;C&&(FXA=new C)}FXA&&FXA.state==="suspended"&&FXA.resume()}catch(e){}return FXA}
["pointerdown","touchend","click"].forEach(ev=>document.addEventListener(ev,()=>{fxCtx()},{passive:!0}));
async function fxPlay(k){try{var c=fxCtx(),f=FXK[k]&&FXK[k][1];if(!c||!f)return;if(!FXB[f]){var r=await fetch("sounds/"+f+".mp3");FXB[f]=await c.decodeAudioData(await r.arrayBuffer())}var s=c.createBufferSource();s.buffer=FXB[f];s.connect(c.destination);s.start(0)}catch(e){}}
function fxTimeAgo(t){var s=Math.max(0,Math.round((Date.now()-t)/1e3));if(s<45)return"agora";var m=Math.round(s/60);if(m<60)return"há "+m+" min";var d=new Date(t),p=function(n){return String(n).padStart(2,"0")},hm=p(d.getHours())+":"+p(d.getMinutes());return d.toDateString()===new Date().toDateString()?"hoje "+hm:p(d.getDate())+"/"+p(d.getMonth()+1)+" "+hm}
function fxBadge(a){return'<span class="fx-badge">'+(a.logo?'<img src="'+h(a.logo)+'" alt="" onerror="this.remove()">':"")+"<i>"+(FXI[a.kind]||"")+"</i></span>"}
function fxBody(a,when){var k=FXK[a.kind]?a.kind:"goal",sc=a.home?h(a.home)+" <b>"+h(a.sh)+"–"+h(a.sa)+"</b> "+h(a.away):"",det=a.det||(a.home?"":a.text||"");return'<span class="fx-body"><span class="fx-top"><b class="fx-kind">'+h(a.title||FXK[k][0])+"</b><em>"+h((a.lg?a.lg+" · ":"")+when)+"</em></span>"+(sc?'<span class="fx-score">'+sc+"</span>":"")+(det?'<span class="fx-det">'+h(det)+"</span>":"")+"</span>"}
function fxBanner(a){var w=document.getElementById("fxw");w||(w=document.createElement("div"),w.id="fxw",document.body.appendChild(w));while(w.children.length>=3)w.lastElementChild.remove();
var k=FXK[a.kind]?a.kind:"goal",dur=k==="goal"||k==="penalty"?7e3:5500,left=dur,t0=Date.now(),tm,closed=!1,drag=!1,sx=0,sy=0,dx=0,dy=0,d=document.createElement("div");
d.className="fx-toast "+k;d.setAttribute("role","status");d.style.setProperty("--dur",dur+"ms");
d.innerHTML=fxBadge(a)+fxBody(a,"agora")+'<button type="button" class="fx-x" aria-label="Fechar">×</button><i class="fx-bar"></i>';
function close(dir){if(closed)return;closed=!0;clearTimeout(tm);d.style.opacity="0";d.style.transform=dir?"translateX("+dir*110+"%)":"translateY(-24px)";setTimeout(function(){d.remove()},320)}
function arm(){t0=Date.now();clearTimeout(tm);tm=setTimeout(close,Math.max(800,left));d.classList.remove("hold")}
function hold(){clearTimeout(tm);left-=Date.now()-t0;d.classList.add("hold")}
function go(){close();location.hash=a.slug&&a.matchId?"#/jogo/"+a.slug+"/"+a.matchId:"#/alertas"}
d.querySelector(".fx-x").onclick=function(e){e.stopPropagation();close()};
d.addEventListener("pointerdown",function(e){if(e.target.closest(".fx-x")||closed)return;drag=!0;sx=e.clientX;sy=e.clientY;dx=dy=0;hold();try{d.setPointerCapture(e.pointerId)}catch(_){}});
d.addEventListener("pointermove",function(e){if(!drag)return;dx=e.clientX-sx;dy=Math.min(0,e.clientY-sy);d.style.transition="none";d.style.transform="translate("+dx+"px,"+dy+"px)";d.style.opacity=String(1-Math.min(1,Math.max(Math.abs(dx)/220,Math.abs(dy)/80)))});
function end(){if(!drag)return;drag=!1;d.style.transition="";if(Math.abs(dx)>90||dy<-40)close(dx>90?1:dx<-90?-1:0);else{d.style.transform="";d.style.opacity="";arm()}}
d.addEventListener("pointerup",function(){if(!drag)return;var moved=Math.abs(dx)>6||Math.abs(dy)>6;end();moved||go()});
d.addEventListener("pointercancel",end);
w.prepend(d);arm()}
function fxItem(n,un){var k=FXK[n.kind]?n.kind:"goal",href=n.slug&&n.matchId?"#/jogo/"+h(n.slug)+"/"+h(n.matchId):"",tg=href?'a href="'+href+'"':"div";return"<"+tg+' class="fx-item '+k+(un?" new":"")+'">'+fxBadge(n)+fxBody(n,fxTimeAgo(n.createdAt))+"</"+(href?"a":"div")+">"}
function fxBind(){var b=M.querySelector(".fx-clear");b&&(b.onclick=function(){$n([]);Vn()})}
function fxNative(a){try{if(!window.AndroidNotify||!AndroidNotify.showRico)return;var pl=a.home?a.home+" "+a.sh+"–"+a.sa+" "+a.away:DBZ_I18N.tr(a.text||"");AndroidNotify.showRico(String(a.kind||"goal"),String(DBZ_I18N.tr(a.title||"DBZSCORE")),String(pl),String(a.det||""),String(a.lg||""),String(a.logo&&/^https:/.test(a.logo)?a.logo:""),String(a.slug||""),String(a.matchId||""))}catch(e){}}
function fxSync(){try{if(!window.AndroidNotify||!AndroidNotify.sync)return;var f=U(),c=fxCfg();AndroidNotify.sync(JSON.stringify({bg:c.bg===0?0:1,leagues:f.leagues,teams:f.teams.map(t=>({league:t.league,id:t.id})),kinds:c.kinds}))}catch(e){}}
function fxFire(l){var c=fxCfg();c.banner&&l.slice(0,3).forEach(fxBanner);c.bg===0&&document.hidden&&l.slice(0,3).forEach(fxNative);if(c.sound){var k=["red","goal","penalty","ft","ht","yellow"].find(x=>l.some(a=>a.kind===x));k&&fxPlay(k)}}
/* tema claro / escuro (botão no cabeçalho; escolha salva no aparelho) */
var THK="dbzscore-theme";
function thGet(){try{return localStorage.getItem(THK)==="light"?"light":"dark"}catch(e){return"dark"}}
function thApply(t){document.documentElement.setAttribute("data-theme",t);var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",t==="light"?"#f5f1e8":"#09080f");var c=document.querySelector('meta[name="color-scheme"]');if(c)c.setAttribute("content",t)}
function thIco(){var a='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">';return thGet()==="light"?a+'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>':a+'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>'}
function thLab(){return thGet()==="light"?"Ativar tema escuro":"Ativar tema claro"}
function thBtn(){return'<button class="bell-btn" id="theme-btn" type="button" aria-label="'+thLab()+'" title="'+thLab()+'">'+thIco()+'</button>'}
document.addEventListener("click",function(ev){var b=ev.target&&ev.target.closest&&ev.target.closest("#theme-btn");if(!b)return;var t=thGet()==="light"?"dark":"light";try{localStorage.setItem(THK,t)}catch(e){}thApply(t);b.innerHTML=thIco();b.setAttribute("aria-label",thLab());b.setAttribute("title",thLab())});
thApply(thGet());
function fxAv(n){return"data:image/svg+xml;utf8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#f1f3f6"/><circle cx="32" cy="25" r="11.5" fill="#b8bfca"/><path d="M9 64c0-15 10.5-23 23-23s23 8 23 23z" fill="#b8bfca"/></svg>')}
var FXPK="dbzscore-photos2",FXPC=(()=>{try{return JSON.parse(localStorage.getItem(FXPK)||"{}")||{}}catch(e){return{}}})(),FXPP=new Map,FXPQ=[],FXPA=0;
function fxPSave(){try{localStorage.setItem(FXPK,JSON.stringify(FXPC))}catch(e){}}
function fxNorm(x){return String(x||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9 ]/g," ").replace(/\s+/g," ").trim()}
async function fxTsdb(name){var r=await fetch("https://www.thesportsdb.com/api/v1/json/"+FXTSDBKEY+"/searchplayers.php?p="+encodeURIComponent(name));if(!r.ok)throw new Error("tsdb "+r.status);var j=await r.json(),arr=(j&&j.player)||[],k=fxNorm(name),kt=k.split(" ");for(var p of arr){if(String(p.strSport||"")!=="Soccer")continue;var n=fxNorm(p.strPlayer),nt=n.split(" "),ok=n===k||(Math.min(nt.length,kt.length)>=2&&(n.indexOf(k)>=0||k.indexOf(n)>=0));if(!ok)continue;var u=p.strCutout||p.strThumb||p.strRender;if(u)return String(u).replace(/^http:/,"https:")}return""} var FXTSDBKEY="3"; async function fxWiki(lang,name){var q=name+(lang==="pt"?" futebolista":" footballer"),r=await fetch("https://"+lang+".wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrlimit=4&gsrsearch="+encodeURIComponent(q)+"&prop=pageimages&piprop=thumbnail&pithumbsize=400");if(!r.ok)throw new Error("wiki "+r.status);var j=await r.json(),pg=j&&j.query&&j.query.pages;if(!pg)return"";var toks=fxNorm(name).split(" ").filter(x=>x.length>1),last=toks[toks.length-1],need=Math.min(2,toks.length),arr=Object.values(pg).sort((a,b)=>(a.index||0)-(b.index||0));for(var g of arr){if(!g.thumbnail||!g.thumbnail.source)continue;var t=" "+fxNorm(g.title)+" ";if(last&&t.includes(" "+last+" ")&&toks.filter(x=>t.includes(" "+x+" ")).length>=need)return String(g.thumbnail.source).replace(/^http:/,"https:")}return""}
/* ===== Fotos de jogadores: a API-Football é a fonte principal =====
   Como funciona (para não confundir homônimos, ex.: Pedro da Lazio × Pedro do Flamengo):
   1) acha o TIME na API-Football (/teams?search=) e guarda o id por 30 dias;
   2) baixa o ELENCO desse time (/players/squads?team=) e guarda por 7 dias;
   3) procura o jogador DENTRO do elenco do próprio time, por nome + número da camisa.
   As imagens (media.api-sports.io) não gastam cota; só os passos 1 e 2 (uns 2 pedidos por time novo).
   Se a API-Football não achar com segurança, a foto da ESPN continua (nunca uma foto "chutada"). */
var AFP_K1="dbzscore-aftm2",AFP_K2="dbzscore-afsq2",AFP_K3="dbzscore-afid2",AFP_DAY=864e5;
function afpLoad(k){try{return JSON.parse(localStorage.getItem(k)||"{}")||{}}catch(x){return{}}}
function afpSv(k,o,max){
  var ks=Object.keys(o);
  if(ks.length>max){ks.sort(function(a,b){return(o[a].t||0)-(o[b].t||0)});ks.slice(0,ks.length-max).forEach(function(x){delete o[x]})}
  try{localStorage.setItem(k,JSON.stringify(o))}catch(x){}
}
/* caches antigos podiam guardar foto errada (busca só pelo nome): descarta */
try{localStorage.removeItem("dbzscore-photos");localStorage.removeItem("dbzscore-afph")}catch(x){}
var AFPT=afpLoad(AFP_K1),AFPS=afpLoad(AFP_K2),AFPI=afpLoad(AFP_K3),AFP_PEND={};
function afpMax(){var n=typeof window!=="undefined"?Number(window.DBZ_AF_FOTOS_POR_DIA):NaN;return Number.isFinite(n)?Math.max(0,n):60}
var AFP_KEEP=35;
/* limite diário só para fotos; sempre sobra cota para a fonte reserva (AFP_KEEP pedidos) */
function afpBudget(){
  var day=K(),a={},q={};
  try{a=JSON.parse(localStorage.getItem("dbzscore-afp")||"{}")}catch(x){}
  try{q=JSON.parse(localStorage.getItem("dbzscore-afq")||"{}")}catch(x){}
  if(a.d!==day)a={d:day,n:0};
  var usados=q.d===day?(q.n||0):0;
  if(a.n>=afpMax()||usados>=AF_LIMIT-AFP_KEEP)return false;
  a.n++;try{localStorage.setItem("dbzscore-afp",JSON.stringify(a))}catch(x){}
  return true;
}
function afpOn(){return!!afKey()&&!AF_BAD&&afpMax()>0}
/* o plano gratuito da API-Football aceita ~10 pedidos por minuto: os pedidos de foto saem UM POR VEZ (fila), no máx. 9 por minuto.
   Se a API recusar (limite por minuto), espera e tenta de novo; falhas não gastam o limite diário de fotos. */
var AFP_TS=[],AFP_Q=Promise.resolve(),AFP_JOBQ=Promise.resolve(),AFP_STOP=0;
/* um jogador por vez (time + elenco), para as fotos aparecerem aos poucos, de cima para baixo, e não todas só no fim */
function afpJob(fn){var run=AFP_JOBQ.then(fn);AFP_JOBQ=run.catch(function(){});return run}
async function afpSlot(){
  for(;;){
    var n=Date.now();AFP_TS=AFP_TS.filter(function(t){return n-t<6e4});
    if(AFP_TS.length<9){AFP_TS.push(n);return}
    await new Promise(function(r){setTimeout(r,AFP_TS[0]+6e4-n+50)});
  }
}
function afpRefund(){try{var a=JSON.parse(localStorage.getItem("dbzscore-afp")||"{}");if(a.d===K()&&a.n>0){a.n--;localStorage.setItem("dbzscore-afp",JSON.stringify(a))}}catch(x){}}
function afpDiag(m){try{localStorage.setItem("dbzscore-afdiag",JSON.stringify({t:Date.now(),m:String(m).slice(0,160)}))}catch(x){}}
function afpDiagText(){
  var a={},q={},d={},day=K();
  try{a=JSON.parse(localStorage.getItem("dbzscore-afp")||"{}")}catch(x){}
  try{q=JSON.parse(localStorage.getItem("dbzscore-afq")||"{}")}catch(x){}
  try{d=JSON.parse(localStorage.getItem("dbzscore-afdiag")||"{}")}catch(x){}
  var t="Fotos (API-Football): "+(a.d===day?a.n:0)+" de "+afpMax()+" buscas hoje \u00b7 consultas do dia: "+(q.d===day?q.n:0)+" de "+AF_LIMIT;
  if(d.m)t+=" \u00b7 \u00faltimo aviso: "+d.m;
  return t;
}
async function afpReq0(path,ttl){
  for(var tr=0;tr<3;tr++){
    if(AFP_STOP>Date.now())throw new Error("API-Football: limite do dia");
    await afpSlot();
    try{return await afGet(path,ttl)}
    catch(x){
      var m=String(x&&x.message||"");
      afpDiag(path.split("?")[0]+" "+m);
      if(/limit for the day|limite di\u00e1rio|daily/i.test(m)){AFP_STOP=Date.now()+36e5;throw x}
      if(tr<2&&/recusou|429|rate|Too many|Failed to fetch|Network/i.test(m)){await new Promise(function(r){setTimeout(r,15000*(tr+1))});continue}
      throw x;
    }
  }
}
function afpReq(path,ttl){var run=AFP_Q.then(function(){return afpReq0(path,ttl)});AFP_Q=run.catch(function(){});return run}
/* a ESPN (pt-BR) traduz nomes; a API-Football usa o nome em inglês */
var AFP_ALIAS={};
("bayern de munique=bayern munich;inter de milao=inter;milao=milan;atletico de madrid=atletico madrid;atletico de madri=atletico madrid;"+
"sporting cp=sporting cp;sporting lisboa=sporting cp;borussia monchengladbach=borussia monchengladbach;eintracht frankfurt=eintracht frankfurt;"+
"colonia=fc koln;marselha=marseille;monaco=monaco;olympique de marselha=marseille;olympique lyonnais=lyon;lyon=lyon;"+
"estrela vermelha=crvena zvezda;celtic=celtic;rangers=rangers;shakhtar donetsk=shakhtar donetsk;dinamo de kiev=dynamo kyiv;"+
"brasil=brazil;argentina=argentina;alemanha=germany;franca=france;espanha=spain;italia=italy;inglaterra=england;holanda=netherlands;"+
"paises baixos=netherlands;belgica=belgium;croacia=croatia;marrocos=morocco;japao=japan;coreia do sul=south korea;coreia do norte=north korea;"+
"estados unidos=usa;eua=usa;mexico=mexico;uruguai=uruguay;colombia=colombia;equador=ecuador;paraguai=paraguay;chile=chile;peru=peru;"+
"venezuela=venezuela;bolivia=bolivia;portugal=portugal;suica=switzerland;dinamarca=denmark;suecia=sweden;noruega=norway;polonia=poland;"+
"servia=serbia;escocia=scotland;pais de gales=wales;gales=wales;irlanda=ireland;irlanda do norte=northern ireland;turquia=turkey;grecia=greece;"+
"austria=austria;ucrania=ukraine;republica tcheca=czech republic;tchequia=czech republic;hungria=hungary;romenia=romania;eslovaquia=slovakia;"+
"eslovenia=slovenia;albania=albania;georgia=georgia;egito=egypt;senegal=senegal;nigeria=nigeria;gana=ghana;camaroes=cameroon;"+
"costa do marfim=ivory coast;argelia=algeria;tunisia=tunisia;africa do sul=south africa;australia=australia;ira=iran;arabia saudita=saudi arabia;"+
"catar=qatar;canada=canada;costa rica=costa rica;panama=panama;jamaica=jamaica;honduras=honduras;haiti=haiti;nova zelandia=new zealand;"+
"china=china;india=india;iraque=iraq;jordania=jordan;uzbequistao=uzbekistan;cabo verde=cape verde;mali=mali;rd congo=congo dr;"+
"atletico mineiro=atletico mg;atletico paranaense=athletico paranaense;athletico paranaense=athletico paranaense;"+
"america mineiro=america mg;botafogo=botafogo rj;vasco da gama=vasco da gama;red bull bragantino=bragantino;"+
"internacional=internacional;gremio=gremio;sao paulo=sao paulo;cuiaba=cuiaba;vitoria=vitoria;bahia=bahia;"+
"boca juniors=boca juniors;river plate=river plate;universidad de chile=universidad de chile;penarol=penarol;nacional=nacional").split(";").forEach(function(p){var i=p.indexOf("=");if(i>0)AFP_ALIAS[p.slice(0,i)]=p.slice(i+1)});
var AFP_JUNK=/\b(w|women|feminino|femenino|u\d{2}|ii|b|reserves?|youth|juniors?|sub ?\d{2})\b/;
function afpTn(s){return fxNorm(s).replace(/\b(fc|cf|sc|ac|afc|cd|ca|club|clube|de|do|da|dos|das|futebol|futbol|football|sad|calcio|the)\b/g," ").replace(/\s+/g," ").trim()}
/* escolhe o time certo entre os resultados da busca; sem certeza, devolve null */
function afpTeamPick(list,name){
  var k=afpTn(name),kt=k.split(" ").filter(Boolean);
  if(!kt.length)return null;
  var cand=[];
  (list||[]).forEach(function(it){
    var t=it&&it.team;if(!t||!t.id)return;
    var n=afpTn(t.name),nt=n.split(" ").filter(Boolean),s=0;
    if(!nt.length)return;
    if(fxNorm(t.name)===fxNorm(name))s=110;
    else if(n===k)s=100;
    else if(nt.every(function(x){return kt.indexOf(x)>=0}))s=70-5*(kt.length-nt.length);
    else if(kt.every(function(x){return nt.indexOf(x)>=0}))s=70-10*(nt.length-kt.length);
    if(!s)return;
    if(AFP_JUNK.test(fxNorm(t.name))&&!AFP_JUNK.test(fxNorm(name)))s-=60;
    cand.push({id:t.id,s:s,nat:!!t.national});
  });
  cand.sort(function(a,b){return b.s-a.s||(a.nat?1:0)-(b.nat?1:0)});
  var b=cand[0];
  if(!b||b.s<50)return null;
  if(cand[1]&&cand[1].s===b.s&&cand[1].nat===b.nat)return null;
  return b.id;
}
async function afpTeamId(name){
  var key=fxNorm(name);
  if(!key)return 0;
  var c=AFPT[key];
  if(c&&Date.now()-c.t<(c.id?30:2)*AFP_DAY)return c.id;
  if(AFP_PEND["t"+key])return AFP_PEND["t"+key];
  var pr=(async function(){
    var al=AFP_ALIAS[key]||key,tries=[al],toks=fxNorm(al).split(" ").filter(function(x){return x.length>=4}).sort(function(a,b){return b.length-a.length});
    if(toks.length&&toks[0]!==al)tries.push(toks[0]);
    var id=0;
    for(var i=0;i<tries.length&&!id;i++){
      if(tries[i].length<3)break;
      if(!afpBudget())throw new Error("limite diario de fotos");
      var r;try{r=await afpReq("/teams?search="+encodeURIComponent(tries[i]),864e5)}catch(x){afpRefund();throw x}
      id=afpTeamPick(r&&r.response,al)||0;
    }
    AFPT[key]={id:id,t:Date.now()};afpSv(AFP_K1,AFPT,300);
    return id;
  })();
  AFP_PEND["t"+key]=pr;
  try{return await pr}finally{delete AFP_PEND["t"+key]}
}
async function afpSquad(tid){
  var c=AFPS[tid];
  if(c&&Date.now()-c.t<(c.p.length?7:1)*AFP_DAY)return c.p;
  if(AFP_PEND["s"+tid])return AFP_PEND["s"+tid];
  var pr=(async function(){
    if(!afpBudget()){if(c)return c.p;throw new Error("limite diario de fotos")}
    var r;try{r=await afpReq("/players/squads?team="+tid,864e5)}catch(x){afpRefund();throw x}
    var it=r&&r.response&&r.response[0],
      p=((it&&it.players)||[]).map(function(x){return{i:x.id,n:x.name||"",j:x.number==null?"":String(x.number)}}).filter(function(x){return x.i});
    AFPS[tid]={t:Date.now(),p:p};afpSv(AFP_K2,AFPS,120);
    return p;
  })();
  AFP_PEND["s"+tid]=pr;
  try{return await pr}finally{delete AFP_PEND["s"+tid]}
}
/* acha o jogador no elenco: nome (inclusive "G. Sobrenome") + camisa; empate sem desempate = não escolhe */
function afpMatch(players,name,jersey){
  var k=fxNorm(name),kt=k.split(" ").filter(Boolean);
  if(!kt.length)return null;
  var jn=String(jersey==null?"":jersey).replace(/\D/g,""),sc=[];
  (players||[]).forEach(function(p){
    var an=fxNorm(p.n),at=an.split(" ").filter(Boolean),ns=0;
    if(!at.length)return;
    if(an===k)ns=100;
    else if(at[0].length===1&&at.length>1&&kt[0][0]===at[0]&&at.slice(1).every(function(t){return kt.indexOf(t)>=0}))ns=85;
    else if(at.every(function(t){return kt.indexOf(t)>=0}))ns=75;
    else if(kt.every(function(t){return at.indexOf(t)>=0}))ns=70;
    else{
      var last=kt[kt.length-1],common=kt.filter(function(t){return at.indexOf(t)>=0}).length;
      if(common>=2)ns=50;else if(last.length>=4&&at[at.length-1]===last)ns=40;
    }
    var j=jn&&p.j&&String(p.j)===jn?40:0;
    if(ns||j)sc.push({p:p,ns:ns,t:ns+j});
  });
  sc.sort(function(a,b){return b.t-a.t});
  var b=sc[0],s2=sc[1];
  if(!b||b.ns<40)return null;
  if(b.t<70)return null;
  if(s2&&b.t-s2.t<10)return null;
  return b.p;
}
/* último recurso (jogador fora do elenco guardado, ex.: contratado há pouco): só com nome completo e resultado único */
async function afpProfile(name){
  var k=fxNorm(name),toks=k.split(" ").filter(function(x){return x.length>1});
  if(toks.length<2)return null;
  var ign={junior:1,jr:1,filho:1,neto:1,de:1,da:1,do:1,dos:1,das:1,van:1,von:1,der:1,den:1,el:1,al:1,di:1,del:1,la:1,le:1},
    u=toks.filter(function(t){return!ign[t]}),busca=(u.length?u:toks)[(u.length?u:toks).length-1];
  if(busca.length<3)return null;
  if(!afpBudget())return false;
  var r,ex=[];try{r=await afpReq("/players/profiles?search="+encodeURIComponent(busca),864e5)}catch(x){afpRefund();throw x}
  ((r&&r.response)||[]).forEach(function(it){
    var p=it&&(it.player||it);if(!p||!p.id)return;
    if(fxNorm(p.name)===k||fxNorm((p.firstname||"")+" "+(p.lastname||""))===k)ex.push(p);
  });
  return ex.length===1?ex[0]:null;
}
function afpKey(o){return o.id?"e"+o.id:"n"+fxNorm(o.name)+"|"+fxNorm(o.team)}
function afpCached(o){var c=AFPI[afpKey(o)];return c&&c.u&&Date.now()-c.t<30*AFP_DAY?c.u:""}
async function afpFind(o){
  var key=afpKey(o),c=AFPI[key];
  if(c&&Date.now()-c.t<(c.u?30:2)*AFP_DAY)return c.u;
  if(!afpOn()||!o.name)return"";
  if(AFP_PEND["p"+key])return AFP_PEND["p"+key];
  var pr=afpJob(async function(){
    var u="",skipped=false,c2=AFPI[key];
    if(c2&&c2.u&&Date.now()-c2.t<30*AFP_DAY)return c2.u;
    try{
      var tid=o.team?await afpTeamId(o.team):0;
      if(tid){var m=afpMatch(await afpSquad(tid),o.name,o.jersey);if(m)u=afPhoto(m.i)}
      if(!u){var pf=await afpProfile(o.name);if(pf===false)skipped=true;else if(pf)u=afPhoto(pf.id)}
    }catch(x){afpDiag(String(x&&x.message||x));return null}
    if(u||!skipped){AFPI[key]={u:u,t:Date.now()};afpSv(AFP_K3,AFPI,1500)}
    return u;
  });
  AFP_PEND["p"+key]=pr;
  try{return await pr}finally{delete AFP_PEND["p"+key]}
}
function afpInfo(im){
  var id=im.dataset.ph||"",sd=id&&typeof PLC!=="undefined"&&PLC[id]||{};
  return{id:id,name:im.alt||sd.name||"",team:im.dataset.tm||sd.team||"",jersey:im.dataset.jn||sd.jersey||""};
}
/* troca a foto de cada jogador na tela pela da API-Football (a da ESPN fica como reserva) */
function afpApply(im){
  if(!im||im.dataset.afd||!im.classList||!im.classList.contains("head"))return;
  var src=im.getAttribute("src")||"";
  if(/media\.api-sports\.io/.test(src)){im.dataset.afd="1";return}
  /* fotos antigas guardadas (favoritos, histórico) de outras fontes: nunca mostrar */
  if(src&&!/^data:/.test(src)&&!/^blob:/.test(src))im.src=fxAv(im.alt);
  var o=afpInfo(im);
  if(!o.name)return;
  var go=function(u){
    if(!u||!im.isConnected||im.dataset.afd)return;
    im.dataset.afd="1";
    im.src=u;
  };
  var u0=afpCached(o);
  if(u0){go(u0);return}
  var again=function(){var n=Number(im.dataset.afr)||0;if(n<4){im.dataset.afr=String(n+1);setTimeout(function(){if(im.isConnected)afpApply(im)},30000*(n+1))}};
  afpFind(o).then(function(u){if(u===null)again();else go(u)},again);
}
function afpScan(root){
  if(!root||root.nodeType!==1)return;
  if(root.tagName==="IMG")afpApply(root);
  else if(root.querySelectorAll)root.querySelectorAll("img.head").forEach(afpApply);
}
try{
  new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(afpScan)})}).observe(document.body||document.documentElement,{childList:true,subtree:true});
  afpScan(document.body);
}catch(x){}
function fxPPump(){while(FXPA<3&&FXPQ.length){FXPA++;FXPQ.shift()().then(()=>{FXPA--;fxPPump()})}}
/* reserva para quando nenhuma imagem carrega: TheSportsDB/Wikipédia só com nome completo (nome único), nunca só "Pedro" */
function fxPhoto(name){var k=fxNorm(name);if(!k||k.split(" ").length<2)return Promise.resolve("");var c=FXPC[k];if(c&&(c.u||Date.now()-c.t<1728e5))return Promise.resolve(c.u);if(FXPP.has(k))return FXPP.get(k);var pr=new Promise(res=>{FXPQ.push(async()=>{try{var u=await fxTsdb(name).catch(function(){return""})||await fxWiki("en",name)||await fxWiki("pt",name);FXPC[k]={u:u,t:Date.now()};fxPSave();res(u)}catch(e){res("")}FXPP.delete(k)})});FXPP.set(k,pr);fxPPump();return pr}
document.addEventListener("error",e=>{var t=e.target;if(!(t&&t.tagName==="IMG"&&t.classList.contains("head"))||t.dataset.av)return;
  /* a foto da API-Football não carregou: fica a silhueta (não usamos mais fotos de outras fontes) */
  t.dataset.av="1";t.src=fxAv(t.alt)},!0);
function fxPanel(){var c=fxCfg(),el=document.createElement("section");el.className="hud-panel fxp";var R=[["goal","\u26bd Gol"],["penalty","\ud83c\udfaf P\u00eanalti"],["ht","\u23f8\ufe0f Fim do 1\u00ba tempo"],["yellow","\ud83d\udfe8 Cart\u00e3o amarelo"],["red","\ud83d\udfe5 Cart\u00e3o vermelho"],["ft","\ud83c\udfc1 Fim de jogo"]];
el.innerHTML='<h2 class="sec">Notifica\u00e7\u00f5es e sons</h2><p class="fx-sub">Geral</p><div class="fxr"><label><input type="checkbox" data-g="sound"'+(c.sound?" checked":"")+"> Som</label></div><div class=\"fxr\"><label><input type=\"checkbox\" data-g=\"banner\""+(c.banner?" checked":"")+"> Aviso na tela</label></div>"+(window.AndroidNotify?"<div class=\"fxr\"><label><input type=\"checkbox\" data-g=\"bg\""+(c.bg===0?"":" checked")+"> Alertas com o app fechado</label></div>":"")+'<p class="fx-sub">Tipos de alerta</p>'+R.map(r=>'<div class="fxr"><label><input type="checkbox" data-k="'+r[0]+'"'+(c.kinds[r[0]]===0?"":" checked")+"> "+r[1]+'</label><button type="button" data-t="'+r[0]+'">\u25b6 Testar</button></div>').join("")+'<p class="empty">Valem para as competi\u00e7\u00f5es e times favoritados (\u2605). '+(window.AndroidNotify?'Com Alertas com o app fechado ativo, os avisos chegam mesmo com o app fechado.':'Mantenha o app aberto durante os jogos.')+'</p>';
window.AndroidNotify&&AndroidNotify.abrirAjustes&&el.insertAdjacentHTML("beforeend",'<button type="button" class="fx-sys" data-sys="1">Som e vibra\u00e7\u00e3o no Android</button>');el.onchange=e=>{var i=e.target,c=fxCfg();i.dataset.g&&(c[i.dataset.g]=i.checked?1:0);i.dataset.k&&(c.kinds[i.dataset.k]=i.checked?1:0);localStorage.setItem("dbzscore-fx",JSON.stringify(c));try{fxSync()}catch(_){}};
el.onclick=e=>{if(e.target.closest("button[data-sys]")){try{AndroidNotify.abrirAjustes()}catch(_){}return}var b=e.target.closest("button[data-t]");if(b){var k=b.dataset.t;fxPlay(k);(a=>{fxBanner(a);fxNative(a)})({kind:k,title:FXK[k][0],text:"Exemplo \u00b7 DBZSCORE",det:{goal:"Pedro 23'",penalty:"Gabigol 45'",yellow:"Gerson 31'",red:"Fulano 78'"}[k]||"",home:"Flamengo",away:"Palmeiras",sh:2,sa:1,lg:"BRA",logo:"logo.png"})}};
el.insertAdjacentHTML("beforeend",'<p class="fx-diag">'+h(afpDiagText())+"</p>");var hr=S(".hero");hr?hr.after(el):M.prepend(el)}
async function hn(){if(FXR)return;FXR=!0;try{var t=U(),G=(await vn(void 0,t.leagues)).groups.flatMap(x=>x.matches),L=wn(),F=[],c=fxCfg(),
fav=u=>t.leagues.includes(u.leagueSlug)||t.teams.some(x=>x.id===u.home.id||x.id===u.away.id),
sumUrl=u=>"/apis/site/v2/sports/soccer/"+u.leagueSlug+"/summary?event="+u.id+"&x="+Math.floor(Date.now()/2e4);
await Promise.all(G.filter(u=>fav(u)&&(u.status==="live"||(u.status==="finished"&&FXS.has(u.id)&&!FXS.get(u.id).fin))).map(u=>q(sumUrl(u),"summary").catch(()=>0)));
for(let u of G){if(u.status!=="live"&&u.status!=="finished")continue;
let hs=u.home.score??0,as=u.away.score??0,sc=hs+"-"+as,pv=Ge.get(u.id),st=FXS.get(u.id),first=!st,
s=st||{seen:new Set,ht:u.statusName==="STATUS_HALFTIME",ft:u.status==="finished",fin:u.status==="finished",base:!1,pend:0},
line=u.home.shortName+" "+hs+"\u2013"+as+" "+u.away.shortName+" \u00b7 "+u.leagueShortName,ns=0,
mk=(kind,title,text,det,tid)=>F.push({id:u.id+"-"+kind+"-"+Date.now()+"-"+F.length,kind,title,text,det:det||"",createdAt:Date.now(),read:!1,matchId:u.id,slug:u.leagueSlug,home:u.home.shortName,away:u.away.shortName,sh:hs,sa:as,lg:u.leagueShortName,logo:tid!=null&&String(tid)===String(u.home.id)?u.home.logo||"":tid!=null&&String(tid)===String(u.away.id)?u.away.logo||"":""});
FXS.set(u.id,s);Ge.set(u.id,sc);
if(fav(u)){
if(!first){if(!s.ht&&u.statusName==="STATUS_HALFTIME"){s.ht=!0;mk("ht",FXK.ht[0],line)}if(!s.ft&&u.status==="finished"){s.ft=!0;mk("ft",FXK.ft[0],line)}}
let need=u.status==="live"||(!first&&!s.fin&&u.status==="finished");u.status==="finished"&&(s.fin=!0);
if(need)try{let P=ln(await q(sumUrl(u),"summary"),u.leagueSlug);if(P){for(let e of P.events){if(s.seen.has(e.id))continue;s.seen.add(e.id);if(!s.base)continue;
let k=e.penalty?"penalty":e.scoring?"goal":e.red?"red":e.yellow?"yellow":"";if(!k)continue;
if(e.scoring){ns++;if(s.pend>0){s.pend--;continue}}
mk(k,k==="goal"?(e.ownGoal?"GOL CONTRA":"GOL!"):k==="penalty"?(e.scoring?"P\u00caNALTI \u00b7 GOL!":"P\u00caNALTI PERDIDO"):FXK[k][0],(e.player?e.player+" ":"")+e.clock+" \u00b7 "+line,(e.player?e.player+" ":"")+e.clock,e.teamId)}s.base=!0}}catch(_){}}
if(pv&&pv!==sc&&hs+as>pv.split("-").reduce((a,b)=>a+ +b,0)&&!(fav(u)&&ns>0)){mk("goal","GOL!",line,"",hs>+pv.split("-")[0]?u.home.id:u.away.id);fav(u)&&s.pend++}}
F=F.filter(a=>c.kinds[a.kind]!==0);if(F.length){L.unshift(...F.slice().reverse());fxFire(F)}$n(L)}catch(e){}finally{FXR=!1}}
function zn(){
  if(sessionStorage.getItem("dbzscore-intro")==="1"){je=!0;return}
  let reduce=!1;try{reduce=window.matchMedia("(prefers-reduced-motion: reduce)").matches}catch(x){}
  let letters=(t,c)=>t.split("").map(ch=>`<span class="sl${c?" "+c:""}" style="--i:${zn.i++}">${ch}</span>`).join("");
  zn.i=0;
  let e=document.createElement("button");
  e.className="splash";e.type="button";e.setAttribute("aria-label","Entrar no DBZSCORE");
  e.innerHTML=`<span class="splash-half sh-a"></span><span class="splash-half sh-b"></span>
    <div class="splash-glow"></div>
    <svg class="splash-pitch" viewBox="0 0 400 400" aria-hidden="true">
      <circle class="sp-ring" cx="200" cy="200" r="150" pathLength="1" transform="rotate(-90 200 200)"/>
      <circle class="sp-ring2" cx="200" cy="200" r="192" pathLength="1" transform="rotate(-90 200 200)"/>
    </svg>
    <div class="splash-scan"></div>
    <div class="splash-stage">
      <div class="splash-markwrap">
        <span class="splash-pulse"></span><span class="splash-pulse p2"></span>
        <img class="splash-mark" src="logo.png" alt="" width="112" height="112"/>
      </div>
      <p class="splash-wordmark display" aria-label="DBZSCORE">${letters("DBZ","")}<span class="accent" style="display:contents">${letters("SCORE","")}</span></p>
      <p class="splash-tag">DBZSCORE voc\xEA vive o jogo</p>
      <span class="splash-rule"></span>
    </div>
    <p class="splash-skip">Toque para entrar</p>`;
  let timer=0,n=()=>{
    if(je)return;je=!0;clearTimeout(timer);
    sessionStorage.setItem("dbzscore-intro","1");
    e.classList.add("splash-exit");
    setTimeout(()=>e.remove(),reduce?200:600)
  };
  e.addEventListener("click",n);
  document.body.appendChild(e);
  timer=setTimeout(n,reduce?900:2700)
}
async function H(){let e=In();return e.name==="search"?srPage():e.name==="player"?plPage(e.slug,e.id):e.name==="leagues"?qn(e.q):e.name==="alerts"?Vn():e.name==="conta"?auPage():e.name==="favs"?Jn():e.name==="league"?On(e.slug,e.date):e.name==="match"?_n(e.slug,e.id):e.name==="team"?Un(e.slug,e.id):Gn(e.date)}function Kn(){return'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>'}function Zn(){return'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M7 6H4a3 3 0 0 0 3 5M17 6h3a3 3 0 0 1-3 5"/></svg>'}function Ln(){return'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>'}function Me(){return'<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2l2.9 6.9L22 10l-5 4.4L18.2 22 12 18.3 5.8 22 7 14.4 2 10l7.1-1.1L12 2z"/></svg>'}/* Escudos locais: têm prioridade sobre a ESPN. Para trocar um escudo, ponha o arquivo em assets/www/ligas/ com o nome da liga (ex.: ligas/bra.1.png) e liste aqui. Se o arquivo não existir, o app volta a usar o da ESPN. */
var LG_LOCAL={"bra.1":"ligas/bra.1.png"};
var LGK="dbzscore-lglogos",LGC=(()=>{try{return JSON.parse(localStorage.getItem(LGK)||"{}")||{}}catch{return{}}})(),LGP=new Map,LGQ=[],LGA=0,LGT=0;function LG(e,n=22,a){let o=LG_LOCAL[e]||LGC[e]||a||"",i=o?` src="${h(o)}"`:"";return`<img class="lg-logo${o?"":" empty"}" data-lgslug="${h(e)}" data-fb="${h(a||"")}"${i} width="${n}" height="${n}" alt="" onerror="var f=this.dataset.fb;if(f&&this.getAttribute('src')!==f){this.setAttribute('src',f)}else{this.classList.add('empty')}"/>`}function lgFetch(e){if(LGP.has(e))return LGP.get(e);let n=q(`/apis/site/v2/sports/soccer/${e}/scoreboard?limit=1`,"logo").then(a=>{var o;let t=((o=a&&a.leagues&&a.leagues[0])!=null?o:{}).logos||[],i=t.find(c=>c.rel&&c.rel.includes("dark"))||t.find(c=>c.rel&&c.rel.includes("default"))||t[0],g=i&&i.href?String(i.href).replace(/^http:/,"https:"):"";if(g){LGC[e]=g;try{localStorage.setItem(LGK,JSON.stringify(LGC))}catch{}}return g}).catch(()=>"");return LGP.set(e,n),n}function lgPump(){for(;LGA<4&&LGQ.length;){LGA++;LGQ.shift()().then(()=>{LGA--,lgPump()})}}function lgRun(e){return new Promise(n=>{LGQ.push(()=>lgFetch(e).then(n,()=>n("")));lgPump()})}function lgSet(e,n){e.getAttribute("src")!==n&&e.setAttribute("src",n),e.classList.remove("empty")}function lgFill(e){let n=e.dataset.lgslug;if(!n||!yn(n))return;if(LG_LOCAL[n]){if(!e.dataset.lgloc){e.dataset.lgloc="1",e.addEventListener("error",()=>{e.getAttribute("src")===LG_LOCAL[n]&&lgRun(n).then(a=>{a&&e.isConnected&&lgSet(e,a)})})}lgSet(e,LG_LOCAL[n]);return}if(LGC[n]){lgSet(e,LGC[n]);return}lgRun(n).then(a=>{a&&e.isConnected&&lgSet(e,a)})}var LGO=typeof IntersectionObserver=="function"?new IntersectionObserver(e=>{e.forEach(n=>{n.isIntersecting&&(LGO.unobserve(n.target),lgFill(n.target))})},{rootMargin:"300px"}):null;function lgScan(){document.querySelectorAll("img[data-lgslug]:not([data-lgo])").forEach(e=>{e.dataset.lgo="1",LGO?LGO.observe(e):lgFill(e)})}document.addEventListener("DOMContentLoaded",()=>{let e=document.getElementById("app");e&&new MutationObserver(()=>{clearTimeout(LGT),LGT=setTimeout(lgScan,30)}).observe(e,{childList:!0,subtree:!0}),lgScan()});window.addEventListener("hashchange",()=>{H()});document.addEventListener("DOMContentLoaded",()=>{M=document.getElementById("app"),zn(),H(),hn(),setInterval(hn,25e3),fxSync()});
/* ===================== DBZ: Busca (Procurar) + Página do jogador ===================== */
var SRK="dbzscore-recent",PLK="dbzscore-pl";
var PLC=(function(){try{return JSON.parse(sessionStorage.getItem(PLK)||"{}")||{}}catch(x){return{}}})();
function plSeed(p){if(!p||!p.id)return;PLC[p.id]=Object.assign(PLC[p.id]||{},p);try{sessionStorage.setItem(PLK,JSON.stringify(PLC))}catch(x){}}
function srRecent(){try{return JSON.parse(localStorage.getItem(SRK)||"[]")||[]}catch(x){return[]}}
function srSave(a){try{localStorage.setItem(SRK,JSON.stringify(a.slice(0,15)))}catch(x){}}
function srSame(a,b){return a.k===b.k&&String(a.id)===String(b.id)&&(a.lg||"")===(b.lg||"")}
function srPush(it){var a=srRecent().filter(function(x){return!srSame(x,it)});a.unshift(it);srSave(a)}
function srRemove(it){srSave(srRecent().filter(function(x){return!srSame(x,it)}))}
function plFavList(){return U().players||[]}
function plIsFav(id){return plFavList().some(function(p){return String(p.id)===String(id)})}
function plToggle(p){var n=U();n.players=n.players||[];var i=n.players.findIndex(function(x){return String(x.id)===String(p.id)});if(i>=0)n.players.splice(i,1);else n.players.push({id:String(p.id),league:p.league||"",name:p.name||"",img:p.img||"",team:p.team||""});bn(n)}
function srIco(){return'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>'}
function srBackIco(){return'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>'}
function srGoBack(){if(history.length>1)history.back();else location.hash="#/"}

var SR_TEAMS=[["86","esp.1","Real Madrid"],["83","esp.1","FC Barcelona"],["382","eng.1","Manchester City"],["360","eng.1","Manchester United"],["364","eng.1","Liverpool"],["160","fra.1","Paris Saint-Germain"],["132","ger.1","Bayern de Munique"],["359","eng.1","Arsenal"],["363","eng.1","Chelsea"],["110","ita.1","Inter de Milão"],["111","ita.1","Juventus"],["103","ita.1","Milan"],["1068","esp.1","Atlético de Madrid"],["819","bra.1","Flamengo"],["2029","bra.1","Palmeiras"],["874","bra.1","Corinthians"],["2026","bra.1","São Paulo"],["3454","bra.1","Vasco da Gama"],["2674","bra.1","Santos"]];
function srTeamItem(t){return{k:"team",id:t[0],lg:t[1],name:t[2],img:_(t[0])}}
function srLeagueItem(l){return{k:"league",id:l.slug,name:l.name,country:l.country,cc:l.countryCode}}
function srPopAll(){
  var T=SR_TEAMS.map(srTeamItem),L=function(s){var l=P(s);return l?srLeagueItem(l):null};
  var order=[T[0],T[1],T[2],L("uefa.champions"),T[3],T[4],L("bra.1"),T[13],L("eng.1"),T[5],T[14],L("esp.1"),T[6],L("conmebol.libertadores"),T[15],L("ita.1")];
  return order.filter(Boolean);
}
function srMeta(it){
  var lg=it.k==="team"?P(it.lg):it.k==="league"?P(it.id):null;
  var country=it.country||(lg&&lg.country)||it.sub||"";
  var cc=it.cc!=null?it.cc:(lg&&lg.countryCode)||"";
  var flag=cc?'<img class="sr-flag" src="'+h(Ve(cc,40))+'" alt="" onerror="this.style.display=\'none\'"/>':(it.k==="team"||it.k==="league")&&(!lg||!lg.countryCode)?'<span class="sr-globe">\u{1F30D}</span>':"";
  return flag+'<span>'+h(country||"Futebol")+'</span>'+(country?'<i class="sr-dot"></i><span>Futebol</span>':"");
}
function srHref(it){return it.k==="team"?"#/time/"+(it.lg||"all")+"/"+it.id:it.k==="player"?"#/jogador/"+(it.lg||"all")+"/"+it.id:"#/liga/"+it.id}
function srIsFav(it){return it.k==="team"?Oe(String(it.id),it.lg||""):it.k==="player"?plIsFav(it.id):qe(it.id)}
function srRow(it,mode){
  var pic=it.k==="player"?'<img class="head sr-img" src="'+h(it.img||Be(it.id))+'" alt="'+h(it.name)+'" data-ph="'+h(it.id)+'" data-tm="'+h(/futebol|soccer/i.test(it.sub||"")?"":(it.sub||it.team||""))+'"/>':it.k==="league"?LG(it.id,40,""):D(it.img||_(it.id),it.name,40);
  var data=h(JSON.stringify(it));
  var act=mode==="recent"?'<button class="sr-act" data-rm="1" aria-label="Remover">\u2715</button>':'<button class="star sr-star'+(srIsFav(it)?" on":"")+'" data-star="1" aria-label="Favoritar">'+Me()+'</button>';
  return'<div class="sr-item" data-it="'+data+'"><a class="sr-main" href="'+h(srHref(it))+'"><span class="sr-pic">'+pic+'</span><span class="grow"><strong>'+h(it.name)+'</strong><small class="sr-meta">'+srMeta(it)+'</small></span></a>'+act+'</div>';
}
function srParse(data){
  var arr=[];
  if(data&&Array.isArray(data.items))arr=arr.concat(data.items);
  if(data&&Array.isArray(data.results))data.results.forEach(function(g){(g.contents||g.items||[]).forEach(function(c){if(c&&!c.type&&g.type)c.type=g.type;arr.push(c)})});
  return arr;
}
function srNormApi(c){
  if(!c)return null;
  var uid=String(c.uid||""),sport=String(c.sport||"").toLowerCase(),web=String((c.link&&c.link.web)||(typeof c.link==="string"?c.link:"")||"");
  var soccer=sport==="soccer"||/(^|~)s:600(~|$)/.test(uid)||/\/(soccer|futebol)\//.test(web);
  if(!soccer)return null;
  var mm=uid.match(/~([atl]):(\d+)/),type=String(c.type||"").toLowerCase();
  var k=type==="player"||type==="athlete"?"player":type==="team"?"team":mm?(mm[1]==="a"?"player":mm[1]==="t"?"team":""):"";
  if(k!=="player"&&k!=="team")return null;
  var id=String(c.id||(mm&&mm[2])||"");if(!id)return null;
  var img=c.image&&typeof c.image==="object"?(c.image.default||c.image.defaultDark||""):(typeof c.image==="string"?c.image:"");
  if(!img&&c.headshot)img=c.headshot.href||"";
  var lg=String(c.defaultLeagueSlug||c.leagueSlug||(typeof c.league==="string"?c.league:"")||"");
  if(!/^[a-z0-9][a-z0-9._-]*$/i.test(lg))lg="";
  var sub=String(c.subtitle||c.description||"");
  var it={k:k,id:id,lg:lg,name:String(c.displayName||c.name||c.title||""),img:k==="player"?"":String(img||"").replace(/^http:/,"https:")};
  if(!it.name)return null;
  if(k==="player")it.sub=sub;else{it.country=sub&&!/futebol|soccer/i.test(sub)?sub:""}
  if(k==="team"&&!it.img)it.img=_(id);
  if(k==="player"&&!it.img)it.img=Be(id);
  return it;
}
async function srApi(query,type){
  var e=encodeURIComponent(query);
  var urls=["/apis/search/v2?query="+e+"&limit=30","/apis/common/v3/search?query="+e+"&limit=30"+(type?"&type="+type:"")];
  var rs=await Promise.allSettled(urls.map(function(u){return q(u,"search")}));
  if(rs.every(function(r){return r.status==="rejected"}))throw rs[0].reason;
  var out=[],seen={};
  rs.forEach(function(r){
    if(r.status!=="fulfilled")return;
    srParse(r.value).forEach(function(c){var it=srNormApi(c);if(!it)return;var key=it.k+":"+it.id;if(seen[key])return;seen[key]=1;out.push(it)});
  });
  return out;
}
async function srMatches(nq){
  var base=K(),days=[$e(base,-1),base,$e(base,1)];
  var rs=await Promise.allSettled(days.map(function(d){return pn(d)}));
  var out=[],seen={};
  rs.forEach(function(r){
    if(r.status!=="fulfilled")return;
    r.value.forEach(function(g){g.matches.forEach(function(m){
      if(seen[m.id])return;
      var hay=nn(m.home.name+" "+m.away.name+" "+m.leagueName+" "+m.leagueShortName);
      if(hay.indexOf(nq)>=0){seen[m.id]=1;out.push(m)}
    })});
  });
  out.sort(function(a,b){return a.date.localeCompare(b.date)});
  return out;
}
async function srTopPlayers(){
  var lgs=["eng.1","esp.1","bra.1","ita.1","ger.1","fra.1"];
  var rs=await Promise.allSettled(lgs.map(function(s){return q("/apis/site/v2/sports/soccer/"+s+"/statistics?","stats").then(function(d){return{s:s,l:cn(d)}})}));
  var out=[];
  rs.forEach(function(r){
    if(r.status!=="fulfilled")return;
    r.value.l.goals.slice(0,4).forEach(function(p){out.push({k:"player",id:p.athleteId,lg:r.value.s,name:p.name,sub:p.teamName,img:p.headshot,v:p.value})});
  });
  out.sort(function(a,b){return b.v-a.v});
  return out.slice(0,14);
}
function srMatchCard(m){return Se(m,true)}

async function srPage(){
  var st={k:"all",q:""},seq=0,tm=null;
  var chips=[["all","Todos"],["team","Equipe"],["player","Jogador"],["match","Partida"],["league","Campeonato"]];
  M.innerHTML=R("search",
    '<div class="sr-top"><button class="sr-back" id="srb" aria-label="Voltar">'+srBackIco()+'</button><label class="sr-box">'+srIco()+'<input id="srq" type="search" placeholder="Procurar" autocomplete="off" autocapitalize="off" spellcheck="false"/></label></div>'+
    '<div class="chips sr-chips" id="srch">'+chips.map(function(c,i){return'<button data-k="'+c[0]+'" class="'+(i===0?"on":"")+'">'+c[1]+'</button>'}).join("")+'</div><div id="srl"></div>');
  var box=S("#srl"),inp=S("#srq");
  var secH=function(t){return'<h2 class="sec sr-sec">'+t+'</h2>'};
  var list=function(items,mode){return'<div class="sr-list">'+items.map(function(it){return srRow(it,mode)}).join("")+'</div>'};

  var emptyView=async function(my){
    var rec=srRecent().filter(function(x){return st.k==="all"||x.k===st.k});
    var html="";
    if(rec.length)html+=secH("Recente")+list(rec,"recent");
    var pop="",loader="";
    if(st.k==="all")pop=list(srPopAll(),"pop");
    else if(st.k==="team")pop=list(SR_TEAMS.map(srTeamItem),"pop");
    else if(st.k==="league")pop=list(we.filter(function(l){return l.featured}).map(srLeagueItem),"pop");
    else if(st.k==="player")loader="players";
    else if(st.k==="match")loader="matches";
    html+=secH("Popular");
    if(pop){box.innerHTML=html+pop;return}
    box.innerHTML=html+Ee(3);
    try{
      if(loader==="players"){
        var ps=await srTopPlayers();if(my!==seq)return;
        box.innerHTML=html+(ps.length?list(ps,"pop"):'<p class="empty">Digite o nome de um jogador para buscar.</p>');
      }else{
        var ms=await srMatches("");if(my!==seq)return;
        box.innerHTML=html+(ms.length?'<div class="cards">'+ms.slice(0,12).map(srMatchCard).join("")+'</div>':'<p class="empty">Digite o nome de um time para buscar partidas (ontem, hoje e amanhã).</p>');
      }
    }catch(x){if(my===seq)box.innerHTML=html+'<p class="empty">Não foi possível carregar agora.</p>'}
  };

  var resultsView=async function(qy,my){
    var nq=nn(qy),k=st.k,lim=k==="all"?5:25;
    var wantTeam=k==="all"||k==="team",wantPl=k==="all"||k==="player",wantLg=k==="all"||k==="league",wantMt=k==="all"||k==="match";
    box.innerHTML=Ee(4);
    var apiP=wantTeam||wantPl?srApi(qy,k==="player"?"player":k==="team"?"team":"").catch(function(){return null}):Promise.resolve([]);
    var mtP=wantMt?srMatches(nq).catch(function(){return[]}):Promise.resolve([]);
    var res=await Promise.all([apiP,mtP]);
    if(my!==seq)return;
    var api=res[0],mts=res[1],apiFail=api===null;api=api||[];
    var teams=[],seenT={};
    if(wantTeam){
      SR_TEAMS.filter(function(t){return nn(t[2]).indexOf(nq)>=0}).forEach(function(t){seenT[t[0]]=1;teams.push(srTeamItem(t))});
      api.filter(function(i){return i.k==="team"&&!seenT[i.id]}).forEach(function(i){seenT[i.id]=1;teams.push(i)});
    }
    var pls=wantPl?api.filter(function(i){return i.k==="player"}):[];
    var lgs=wantLg?we.filter(function(l){return nn(l.name+" "+l.shortName+" "+l.country).indexOf(nq)>=0}).map(srLeagueItem):[];
    var html="";
    if(teams.length)html+=secH("Equipe")+list(teams.slice(0,lim),"res");
    if(pls.length)html+=secH("Jogador")+list(pls.slice(0,lim),"res");
    if(mts.length)html+=secH("Partida")+'<div class="cards">'+mts.slice(0,lim).map(srMatchCard).join("")+'</div>';
    if(lgs.length)html+=secH("Campeonato")+list(lgs.slice(0,lim),"res");
    if(!html)html='<p class="empty">'+(apiFail&&(wantTeam||wantPl)?"Não foi possível buscar agora. Verifique a internet e tente de novo.":"Nada encontrado para “"+h(qy)+"”.")+'</p>';
    else if(apiFail&&(wantTeam||wantPl))html+='<p class="tm-note">A busca online de times e jogadores está indisponível agora.</p>';
    box.innerHTML=html;
  };

  var draw=function(){
    var my=++seq,qy=st.q.trim();
    if(qy.length<2){emptyView(my);return}
    resultsView(qy,my);
  };
  draw();

  inp.addEventListener("input",function(){st.q=inp.value;clearTimeout(tm);tm=setTimeout(draw,280)});
  S("#srb").addEventListener("click",srGoBack);
  S("#srch").addEventListener("click",function(ev){
    var b=ev.target.closest("button");if(!b)return;
    S("#srch").querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
    b.classList.add("on");st.k=b.dataset.k;draw();
    try{b.scrollIntoView({inline:"center",block:"nearest"})}catch(x){}
  });
  box.addEventListener("click",function(ev){
    var row=ev.target.closest(".sr-item");if(!row)return;
    var it={};try{it=JSON.parse(row.getAttribute("data-it")||"{}")}catch(x){}
    if(ev.target.closest("[data-rm]")){ev.preventDefault();srRemove(it);draw();return}
    var sb=ev.target.closest("[data-star]");
    if(sb){
      ev.preventDefault();
      if(it.k==="team")Ce({league:it.lg||"all",id:String(it.id),name:it.name,logo:it.img||_(it.id)});
      else if(it.k==="league")Ne(it.id);
      else if(it.k==="player")plToggle({id:it.id,league:it.lg,name:it.name,img:it.img,team:/futebol|soccer/i.test(it.sub||"")?"":(it.sub||"")});
      sb.classList.toggle("on",srIsFav(it));
      return;
    }
    if(ev.target.closest(".sr-main")){
      srPush(it);
      if(it.k==="player")plSeed({id:it.id,lg:it.lg,name:it.name,img:it.img,team:it.sub});
    }
  });
  setTimeout(function(){try{inp.focus()}catch(x){}},60);
}

/* ---------------- Página do jogador ---------------- */
function plAge(dob){if(!dob)return null;var d=new Date(dob);if(isNaN(d.getTime()))return null;var n=new Date(),a=n.getFullYear()-d.getFullYear(),m=n.getMonth()-d.getMonth();if(m<0||(m===0&&n.getDate()<d.getDate()))a--;return a>0&&a<70?a:null}
function plDate(dob){try{var d=new Date(dob);if(isNaN(d.getTime()))return"";return new Intl.DateTimeFormat(DBZ_I18N.locale,{day:"numeric",month:"short",year:"numeric",timeZone:"UTC"}).format(d)}catch(x){return""}}
function plHeight(a){
  var hh=a.height;
  if(typeof hh==="number"&&hh>0)return Math.round(hh<100?hh*2.54:hh)+" cm";
  var s=String(a.displayHeight||"");if(!s)return"";
  var m=s.match(/(\d+)'\s*(\d+)/);if(m)return Math.round((+m[1]*12+ +m[2])*2.54)+" cm";
  return s;
}
function plNorm(d,seed){
  var a=(d&&d.athlete)||d||{},pos=a.position||{},tm=a.team||{},fl=a.flag||{},hs=a.headshot||{};
  var dob=a.dateOfBirth||a.birthDate||"",age=a.age!=null?Number(a.age):plAge(dob);
  if(age==null&&seed.age!=null)age=seed.age;
  var teamName=(tm&&(tm.displayName||tm.name))||seed.team||"",teamId=(tm&&tm.id)||seed.teamId||"";
  var logo=(tm&&((tm.logos&&tm.logos[0]&&tm.logos[0].href)||tm.logo))||seed.teamLogo||(teamId?_(teamId):"");
  var foot=a.preferredFoot||a.foot||a.strongFoot||"";
  if(typeof foot==="object")foot=foot.displayValue||foot.text||"";
  return{
    id:String(a.id||seed.id||""),
    name:a.displayName||a.fullName||seed.name||"Jogador",
    img:"",
    team:teamName,teamId:String(teamId||""),teamLogo:logo,
    jersey:a.jersey||seed.jersey||"",
    pos:pos.displayName||pos.name||seed.pos||"",
    nat:a.citizenship||seed.nat||"",
    flag:fl.href||seed.flag||"",
    dob:dob,age:age,
    height:plHeight(a)||seed.height||"",
    foot:String(foot||"")
  };
}
async function plFirst(urls,kind){for(var i=0;i<urls.length;i++){try{var d=await q(urls[i],kind);if(d)return d}catch(x){}}return null}
function plRows(d){
  var out=[];
  var cats=d&&Array.isArray(d.categories)?d.categories:[];
  cats.forEach(function(c){
    var labels=c.labels||c.names||[],disp=c.displayNames||c.labels||c.names||[];
    var rows=(c.statistics||[]).map(function(s){return{season:String((s.season&&(s.season.displayName||s.season.year))||s.displayName||""),team:s.teamSlug||"",vals:s.stats||[]}});
    rows.sort(function(a,b){return b.season.localeCompare(a.season)});
    out.push({name:c.displayName||c.name||"",labels:labels,disp:disp,rows:rows,totals:c.totals||[]});
  });
  var st=d&&d.statistics;
  if(st&&!Array.isArray(st)&&Array.isArray(st.splits)){
    out.push({name:st.displayName||"Temporada",labels:st.labels||st.names||[],disp:st.displayNames||st.labels||st.names||[],rows:st.splits.map(function(s){return{season:s.displayName||"",team:"",vals:s.stats||[]}}),totals:[]});
  }
  return out.filter(function(c){return c.labels.length&&(c.rows.length||c.totals.length)});
}
function plGames(d){
  var evs=d&&d.events&&!Array.isArray(d.events)?d.events:{},labels=(d&&(d.labels||d.names))||[],list=[];
  ((d&&d.seasonTypes)||[]).forEach(function(stp){(stp.categories||[]).forEach(function(c){(c.events||[]).forEach(function(r){list.push({id:String(r.eventId),m:evs[r.eventId]||{},stats:r.stats||[],labels:c.labels||labels})})})});
  list.sort(function(a,b){return String(b.m.gameDate||"").localeCompare(String(a.m.gameDate||""))});
  return list;
}

/* ---------------- Transfermarkt: valor de mercado, contrato, agente e pé preferido ----------------
   A fonte é o Transfermarkt (página do jogador). No app Android a requisição sai pelo próprio app
   (proxy nativo, sem CORS). No site/iPhone tenta direto e, se o navegador bloquear, usa proxies públicos. */
var TFK="dbzscore-tf1",TF_BASE="https://www.transfermarkt.com.br",TF_TTL=12*3600*1000;
var TFC=(function(){try{return JSON.parse(localStorage.getItem(TFK)||"{}")||{}}catch(x){return{}}})();
var tfRoute=0;
function tfSave(){try{var ks=Object.keys(TFC);if(ks.length>150){ks.sort(function(a,b){return(TFC[a].ts||0)-(TFC[b].ts||0)});ks.slice(0,ks.length-120).forEach(function(k){delete TFC[k]})}localStorage.setItem(TFK,JSON.stringify(TFC))}catch(x){}}
var tfPend={},tfSeq=0,tfErr=[];
window.__tfNative=function(id,html){var f=tfPend[id];if(f){delete tfPend[id];f(html)}};
/* página de verdade do Transfermarkt (e não bloqueio, desafio ou página de erro) */
function tfReal(t){return!!t&&t.length>1500&&/<title[^>]*>[^<]*transfermarkt/i.test(t)&&!/just a moment|attention required|access denied|verifying you are human/i.test(t.slice(0,4000))}
function tfNative(path){
  return new Promise(function(res){
    var id="t"+(++tfSeq),to=setTimeout(function(){if(tfPend[id]){delete tfPend[id];res("")}},40000);
    tfPend[id]=function(h){clearTimeout(to);res(h||"")};
    try{window.AndroidTM.fetch(path,id)}catch(x){clearTimeout(to);delete tfPend[id];res("")}
  });
}
async function tfHtml(path){
  var url=TF_BASE+path;
  /* Android: um WebView escondido abre a página como o Chrome faria (o Transfermarkt barra requisições "cruas") */
  if(window.AndroidTM&&typeof window.AndroidTM.fetch!=="undefined"){
    var nh=await tfNative(path);
    if(tfReal(nh))return nh;
    tfErr.push("app: "+(nh?"página inválida":"sem resposta"));
  }
  var routes=[url,"https://api.allorigins.win/raw?url="+encodeURIComponent(url),"https://corsproxy.io/?url="+encodeURIComponent(url)];
  var order=[tfRoute].concat([0,1,2].filter(function(i){return i!==tfRoute}));
  for(var k=0;k<order.length;k++){
    var i=order[k],ctl=typeof AbortController==="function"?new AbortController():null,tid=ctl?setTimeout(function(){ctl.abort()},12000):0;
    try{
      var r=await fetch(routes[i],ctl?{signal:ctl.signal}:undefined);
      if(!r.ok){tfErr.push("rota "+i+": HTTP "+r.status);continue}
      var t=await r.text();
      if(tfReal(t)){tfRoute=i;return t}
      tfErr.push("rota "+i+": página inválida");
    }catch(x){tfErr.push("rota "+i+": bloqueada")}finally{if(tid)clearTimeout(tid)}
  }
  return"";
}
function tfNorm(s){return String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g," ").trim()}
function tfToks(s){return tfNorm(s).split(" ").filter(Boolean).map(function(w){return w==="jr"?"junior":w})}
function tfNameScore(a,b){
  var A=tfToks(a),B=tfToks(b);if(!A.length||!B.length)return 0;
  if(A.join(" ")===B.join(" "))return 6;
  var inter=A.filter(function(w){return B.indexOf(w)>=0}).length;
  return 5*inter/(A.length+B.length-inter);
}
function tfClub(s){return tfNorm(s).replace(/\b(fc|cf|sc|ac|afc|club|clube|de|do|da|futebol)\b/g," ").replace(/\s+/g," ").trim()}
function tfSameClub(a,b){var x=tfClub(a),y=tfClub(b);return!!(x&&y&&(x===y||x.indexOf(y)>=0||y.indexOf(x)>=0))}
var TF_MES={jan:1,fev:2,feb:2,mar:3,abr:4,apr:4,mai:5,may:5,jun:6,jul:7,ago:8,aug:8,set:9,sep:9,out:10,oct:10,nov:11,dez:12,dec:12};
function tfIso(y,m,d){return y+"-"+("0"+m).slice(-2)+"-"+("0"+d).slice(-2)}
function tfDate(s){
  s=String(s||"");
  var m=s.match(/(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/);
  if(m)return tfIso(m[3],m[2],m[1]);
  m=s.match(/(\d{1,2})\s+(?:de\s+)?([A-Za-z\u00e7\u00c7]{3,})\.?\s+(?:de\s+)?(\d{4})/);
  if(m){var a=TF_MES[tfNorm(m[2]).slice(0,3)];if(a)return tfIso(m[3],a,m[1])}
  m=s.match(/([A-Za-z]{3,})\.?\s+(\d{1,2}),?\s+(\d{4})/);
  if(m){var b=TF_MES[tfNorm(m[1]).slice(0,3)];if(b)return tfIso(m[3],b,m[2])}
  return"";
}
function tfFmtDate(iso){
  if(!iso)return"";var p=iso.split("-");if(p.length!==3)return"";
  try{return new Intl.DateTimeFormat(DBZ_I18N.locale,{day:"numeric",month:"short",year:"numeric",timeZone:"UTC"}).format(new Date(Date.UTC(+p[0],+p[1]-1,+p[2])))}catch(x){return""}
}
function tfSameDay(a,b){var x=Date.parse(a+"T00:00:00Z"),y=Date.parse(b+"T00:00:00Z");return isFinite(x)&&isFinite(y)&&Math.abs(x-y)<=86400000}
var TF_U="(bi|bn|mil|mi|th|m|k)";
function tfMoney(s){
  s=String(s||"").replace(/\s+/g," ").trim();
  var m=s.match(new RegExp("^([\u20ac\u00a3$])?\\s*(\\d[\\d.,]*)\\s*"+TF_U+"?(?![a-z])","i"))||s.match(new RegExp("([\u20ac\u00a3$])\\s*(\\d[\\d.,]*)\\s*"+TF_U+"?(?![a-z])","i"));
  if(!m)return null;
  var raw=m[2],u=(m[3]||"").toLowerCase(),hc=raw.indexOf(",")>=0,hd=raw.indexOf(".")>=0,n;
  if(hc&&hd)n=raw.lastIndexOf(",")>raw.lastIndexOf(".")?raw.replace(/\./g,"").replace(",","."):raw.replace(/,/g,"");
  else if(hc)n=raw.replace(",",".");
  else if(hd&&/^\d{1,3}(\.\d{3})+$/.test(raw))n=raw.replace(/\./g,"");
  else n=raw;
  n=parseFloat(n);if(!isFinite(n))return null;
  var mult=u==="bi"||u==="bn"?1e9:u==="mil"||u==="th"||u==="k"?1e3:u==="mi"||u==="m"?1e6:1;
  return{eur:n*mult,cur:m[1]||"\u20ac",text:s};
}
function tfFmtMoney(v){
  var e=v.eur,c=v.cur||"\u20ac",f=function(x){return String(Math.round(x*100)/100).replace(".",",")};
  if(e>=1e9)return c+f(e/1e9)+" bi";
  if(e>=1e6)return c+f(e/1e6)+" mi";
  if(e>=1e3)return c+Math.round(e/1e3)+" mil";
  return c+Math.round(e);
}
function tfFoot(v){var n=tfNorm(v);return/esq|left/.test(n)?"Esquerdo":/dir|right/.test(n)?"Direito":/amb|both/.test(n)?"Ambidestro":""}
function tfCandidates(html,name,team){
  var doc=new DOMParser().parseFromString(html,"text/html"),seen={},out=[];
  doc.querySelectorAll('a[href*="/profil/spieler/"]').forEach(function(a){
    var m=(a.getAttribute("href")||"").match(/^(\/[^\/?#]+\/profil\/spieler\/(\d+))/),nm=(a.textContent||"").trim();
    if(!m||!nm||seen[m[2]])return;
    seen[m[2]]=1;
    var row=a.closest("tr.odd,tr.even")||a.closest("tr")||a.parentNode,club="";
    var cl=row&&row.querySelector('a[href*="/startseite/verein/"]');
    if(cl){var im=cl.querySelector("img");club=(cl.getAttribute("title")||(im&&(im.getAttribute("alt")||im.getAttribute("title")))||cl.textContent||"").trim()}
    var cm=!!(team&&club&&tfSameClub(team,club)),A=tfToks(name),B=tfToks(nm),ov=A.filter(function(w){return B.indexOf(w)>=0}).length;
    out.push({id:m[2],path:m[1],name:nm,club:club,cm:cm,ov:ov,score:tfNameScore(name,nm)+(cm?2:0),idx:out.length});
  });
  if(!out.length){
    var re=/href="(\/[^"\/?#]+\/profil\/spieler\/(\d+))"[^>]*>\s*([^<\s][^<]*?)\s*</g,mm;
    while((mm=re.exec(html))){
      if(seen[mm[2]])continue;seen[mm[2]]=1;
      var A2=tfToks(name),B2=tfToks(mm[3]),ov2=A2.filter(function(w){return B2.indexOf(w)>=0}).length;
      out.push({id:mm[2],path:mm[1],name:mm[3],club:"",cm:false,ov:ov2,score:tfNameScore(name,mm[3]),idx:out.length});
    }
  }
  out.sort(function(x,y){return y.score-x.score||x.idx-y.idx});
  return out.slice(0,10);
}
function tfParseProfile(html,path,id){
  var doc=new DOMParser().parseFromString(html,"text/html"),kv={},lk={};
  var put=function(k,v,href){k=tfNorm(k);v=String(v||"").replace(/\s+/g," ").trim();if(!k||!v||kv[k]!==undefined)return;kv[k]=v;if(href)lk[k]=href};
  doc.querySelectorAll("li.data-header__label").forEach(function(li){
    var sp=li.querySelector(".data-header__content");if(!sp)return;
    var lab="";li.childNodes.forEach(function(n){if(n.nodeType===3)lab+=n.textContent});
    var a=sp.querySelector("a");put(lab,sp.textContent,a&&a.getAttribute("href"));
  });
  doc.querySelectorAll(".info-table__content--regular").forEach(function(r){
    var b=r.nextElementSibling;if(!b||!/info-table__content--bold/.test(b.className))return;
    var a=b.querySelector("a");put(r.textContent,b.textContent,a&&a.getAttribute("href"));
  });
  var key=function(list){var ks=Object.keys(kv);for(var i=0;i<list.length;i++){for(var j=0;j<ks.length;j++){if(ks[j]===list[i]||ks[j].indexOf(list[i]+" ")===0)return ks[j]}}return""};
  var get=function(list){var k=key(list);return k?kv[k]:""};
  var mw=doc.querySelector(".data-header__market-value-wrapper"),value=null,upd="";
  if(mw){var c=mw.cloneNode(true),lu=c.querySelector(".data-header__last-update");if(lu){upd=tfDate(lu.textContent);lu.parentNode.removeChild(lu)}value=tfMoney(c.textContent)}
  if(!Object.keys(kv).length&&!value)return null;
  var ck=key(["contrato ate","contract expires"]),contractRaw=ck?kv[ck]:"",contract=tfDate(contractRaw);
  var ak=key(["agente","player agent","agent"]),ah=ak&&lk[ak]&&/^\/[^\s"'<>]+$/.test(lk[ak])?lk[ak]:"";
  var hgt=get(["altura","height"]),hm=hgt.match(/(\d)[,.](\d{2})/);
  var img=doc.querySelector("img.data-header__profile-image"),photo=img?(img.getAttribute("src")||img.getAttribute("data-src")||""):"";
  if(!photo){var og=doc.querySelector('meta[property="og:image"]');photo=og?og.getAttribute("content")||"":""}
  if(!/^https:\/\/[a-z0-9.-]*transfermarkt[a-z0-9.-]*\//i.test(photo))photo="";
  var sh=doc.querySelector(".data-header__shirt-number"),club=doc.querySelector(".data-header__club a");
  var nat=doc.querySelector('[itemprop="nationality"]');
  return{
    id:String(id||""),url:TF_BASE+path,value:value,upd:upd,
    contract:contract,contractTxt:contract?"":(contractRaw&&contractRaw!=="-"?contractRaw:""),
    loanFrom:get(["emprestado de","on loan from"]),parentContract:tfDate(get(["contract there expires","contrato la"])),
    foot:tfFoot(get(["pe","foot"])),agent:ak&&kv[ak]&&!/^-$/.test(kv[ak])?kv[ak]:"",agentUrl:ah?TF_BASE+ah:"",
    dob:tfDate((doc.querySelector('[itemprop="birthDate"]')||{}).textContent||get(["data de nascimento","data de nasc","date of birth"])),
    height:hm?hm[1]*100+ +hm[2]+" cm":"",nat:nat?nat.textContent.replace(/\s+/g," ").trim():get(["cidadania","citizenship"]),
    pos:get(["posicao","position"]),jersey:sh?sh.textContent.replace(/\D/g,""):"",
    club:club?club.textContent.replace(/\s+/g," ").trim():get(["clube atual","current club"]),photo:photo
  };
}
/* devolve os dados, ou {fail:"net"} (sem conexão/bloqueio) ou {fail:"nf",dbg:"..."} (jogador não encontrado) */
async function tfLoad(a,force){
  var key=String(a.id),c=TFC[key];
  if(!force&&c&&c.data&&Date.now()-c.ts<TF_TTL)return c.data;
  var dobE=a.dob?String(a.dob).slice(0,10):"",net=false,dbg=[];tfErr=[];
  var tryOne=async function(cd,isKnown){
    var ph=await tfHtml(cd.path);
    if(!ph){net=true;return null}
    var d=tfParseProfile(ph,cd.path,cd.id);
    if(!d){net=true;return null}
    var strong=cd.score>=4||(cd.cm&&cd.ov>0);
    var ok=isKnown?true:(dobE&&d.dob?tfSameDay(dobE,d.dob):strong);
    if(!ok)return null;
    TFC[key]={ts:Date.now(),tmId:cd.id,path:cd.path,data:d};tfSave();return d;
  };
  if(c&&c.path){var k=await tryOne({path:c.path,id:c.tmId,score:9},true);if(k)return k;if(c.data)return c.data}
  var toks=String(a.name||"").split(/\s+/).filter(Boolean),queries=[a.name];
  if(toks.length>1)queries.push(toks[toks.length-1]);
  var tried={};
  for(var qi=0;qi<queries.length;qi++){
    var sh=await tfHtml("/schnellsuche/ergebnis/schnellsuche?query="+encodeURIComponent(queries[qi]));
    if(!sh){net=true;dbg.push("busca "+(qi+1)+": sem resposta");continue}
    var cand=tfCandidates(sh,a.name,a.team);
    dbg.push("busca \""+queries[qi]+"\": "+cand.length+" resultado(s)");
    var n=0;
    for(var i=0;i<cand.length&&n<3;i++){
      var cd=cand[i];
      if(tried[cd.id])continue;
      if(!(cd.ov>0||cd.cm))continue;
      if(!dobE&&!cd.cm&&cd.score<4)continue;
      tried[cd.id]=1;n++;
      var d=await tryOne(cd,false);
      if(d)return d;
    }
  }
  if(c&&c.data)return c.data;
  var ex=tfErr.filter(function(x,i,arr){return arr.indexOf(x)===i}).slice(0,4);
  var info=dbg.concat(ex).join(" · ");
  return net&&!Object.keys(tried).length&&dbg.every(function(x){return/sem resposta/.test(x)})?{fail:"net",dbg:info}:{fail:"nf",dbg:info};
}
async function plPage(slug,id){
  var seed=PLC[id]||{};
  if(!seed.id)seed.id=id;
  var lgSlug=/^[a-z0-9][a-z0-9._-]*$/i.test(slug)?slug:"all";
  var skel='<section class="pl-hero"><div class="pl-bar"><button class="sr-back" id="plb" aria-label="Voltar">'+srBackIco()+'</button></div><div class="pl-id"><img class="head pl-photo" src="'+h(seed.img||Be(id))+'" alt="'+h(seed.name||"Jogador")+'" data-ph="'+h(id)+'" data-tm="'+h(seed.team||"")+'" data-jn="'+h(seed.jersey||"")+'"/><div class="grow"><h1>'+h(seed.name||"Carregando…")+'</h1></div></div></section>'+Ee(3);
  M.innerHTML=R("search",skel);
  var bk=S("#plb");bk&&bk.addEventListener("click",srGoBack);

  var bases=[];
  if(lgSlug!=="all")bases.push("/apis/common/v3/sports/soccer/"+lgSlug+"/athletes/"+id);
  bases.push("/apis/common/v3/sports/soccer/all/athletes/"+id,"/apis/common/v3/sports/soccer/athletes/"+id);
  var det=await plFirst(bases.concat(["https://sports.core.api.espn.com/v2/sports/soccer/athletes/"+id+"?"+DBZ_I18N.espn]),"team");
  var a=plNorm(det,seed);
  plSeed({id:id,lg:lgSlug,name:a.name,img:a.img,team:a.team,teamId:a.teamId,teamLogo:a.teamLogo});
  var st={tab:"detalhes",stats:undefined,games:undefined,tf:undefined};

  var star=function(){return plIsFav(id)};
  var teamHref=a.teamId?"#/time/"+(lgSlug!=="all"?lgSlug:"all")+"/"+a.teamId:"";
  var teamBlock=a.team?(teamHref?'<a class="pl-team" href="'+h(teamHref)+'">':'<span class="pl-team">')+(a.teamLogo?D(a.teamLogo,a.team,22):"")+'<span>'+h(a.team)+'</span>'+(teamHref?'</a>':'</span>'):"";
  M.innerHTML=R("search",
    '<section class="pl-hero"><div class="pl-bar"><button class="sr-back" id="plb" aria-label="Voltar">'+srBackIco()+'</button><span class="grow"></span><button class="star pl-star'+(star()?" on":"")+'" id="plf" aria-label="Favoritar">'+Me()+'</button></div>'+
    '<div class="pl-id"><img class="head pl-photo" src="'+h(a.img||Be(id))+'" alt="'+h(a.name)+'" data-ph="'+h(id)+'" data-tm="'+h(a.team||"")+'" data-jn="'+h(a.jersey||"")+'"/><div class="grow"><h1>'+h(a.name)+'</h1>'+teamBlock+'</div></div></section>'+
    '<div class="chips" id="pltabs"><button data-t="detalhes" class="on">Detalhes</button><button data-t="partidas">Partidas</button><button data-t="carreira">Carreira</button><button data-t="temporada">Temporada</button></div>'+
    '<div id="panel"></div>');
  S("#plb").addEventListener("click",srGoBack);
  S("#plf").addEventListener("click",function(){plToggle({id:id,league:lgSlug,name:a.name,img:a.img,team:a.team});S("#plf").classList.toggle("on",star())});

  var cell=function(l,v){return v?'<div class="pl-cell"><small>'+l+'</small><b>'+v+'</b></div>':""};
  var tfOk=function(){return st.tf&&!st.tf.fail?st.tf:null};
  var sk=function(w){return'<span class="pl-sk" style="width:'+(w||70)+'px"></span>'};
  var vDet=function(){
    var t=tfOk(),loading=st.tf===undefined,out="";
    var teamName=a.team||(t&&t.club)||"";
    if(teamName){
      var sub="";
      if(loading)sub='<span class="pl-sub">'+sk(150)+'</span>';
      else if(t){
        var ct=t.contract?"Contrato até "+tfFmtDate(t.contract):(t.contractTxt?"Contrato: "+t.contractTxt:"");
        if(ct)sub+='<span class="pl-sub">'+h(ct)+'</span>';
        if(t.loanFrom)sub+='<span class="pl-sub">Emprestado de '+h(t.loanFrom)+(t.parentContract?" · contrato lá até "+h(tfFmtDate(t.parentContract)):"")+'</span>';
      }
      out+=(teamHref?'<a class="tm-card pl-teamcard" href="'+h(teamHref)+'">':'<div class="tm-card pl-teamcard">')+(a.teamLogo?D(a.teamLogo,teamName,44):"")+'<span class="grow"><strong>'+h(teamName)+'</strong>'+sub+'</span>'+(teamHref?'<span class="pl-chev">\u203A</span></a>':'</div>');
    }
    var nat=a.nat||(t&&t.nat)||"",flag=a.nat?a.flag:"";
    var natv=(flag?'<img class="tm-flag" src="'+h(flag)+'" alt="" onerror="this.style.display=\'none\'"/>':"")+h(nat);
    var dob=a.dob||(t&&t.dob)||"",birth=dob?plDate(dob):"",age=a.age!=null?a.age:plAge(dob);
    var foot=(t&&t.foot)||a.foot||"",footv=foot?h(foot):(loading?sk(60):"");
    var cells=cell("Nacionalidade",nat?natv:"")+cell(birth?birth:"Idade",age!=null?age+" anos":"")+cell("Altura",h(a.height||(t&&t.height)||""))+cell("Pé preferido",footv)+cell("Posição",h(a.pos||(t&&t.pos)||""))+cell("Número da camisa",h(String(a.jersey||(t&&t.jersey)||"")));
    /* valor de mercado (Transfermarkt) */
    var mv;
    if(loading){
      mv='<div class="pl-mv-main"><small>Valor de mercado</small><b class="pl-mv-val">'+sk(96)+'</b></div><div class="pl-mv-side">Buscando no Transfermarkt\u2026</div>';
    }else if(t){
      var has=t.value&&t.value.eur>0;
      mv='<div class="pl-mv-main"><small>Valor de mercado</small><b class="pl-mv-val">'+(has?h(tfFmtMoney(t.value)):"\u2014")+'</b></div><div class="pl-mv-side">'+(has?'Fonte: Transfermarkt'+(t.upd?'<br>Atualizado em '+h(tfFmtDate(t.upd)):""):'Sem valor de mercado no Transfermarkt.')+'<br><a href="'+h(t.url)+'" target="_blank" rel="noopener">Ver no Transfermarkt \u203A</a></div>';
    }else{
      var nf=st.tf&&st.tf.fail==="nf",su=TF_BASE+"/schnellsuche/ergebnis/schnellsuche?query="+encodeURIComponent(a.name);
      mv='<div class="pl-mv-main"><small>Valor de mercado</small><b class="pl-mv-val">\u2014</b></div><div class="pl-mv-side">'+(nf?'Sem perfil deste jogador no Transfermarkt (ou o nome é diferente lá).<br><a href="'+h(su)+'" target="_blank" rel="noopener">Buscar no Transfermarkt \u203A</a>'+(st.tf.dbg?'<small class="pl-dbg">'+h(st.tf.dbg)+'</small>':""):'Não foi possível consultar o Transfermarkt agora.<br><a href="#" id="tfretry">Tentar de novo</a>'+(st.tf&&st.tf.dbg?'<small class="pl-dbg">'+h(st.tf.dbg)+'</small>':""))+'</div>';
    }
    var agent;
    if(loading)agent=sk(90);
    else if(t&&t.agent)agent=t.agentUrl?'<a class="pl-chip" href="'+h(t.agentUrl)+'" target="_blank" rel="noopener">'+h(t.agent)+' \u203A</a>':'<span class="pl-chip">'+h(t.agent)+'</span>';
    else agent='<span class="pl-chip">Desconhecido</span>';
    out+='<section class="tm-card">'+(cells?'<div class="pl-grid">'+cells+'</div>':"")+
      '<div class="pl-mv'+(cells?"":" first")+'">'+mv+'</div>'+
      '<div class="pl-row"><span>'+(t?'Transfermarkt ID: <b>'+h(t.id)+'</b>':"")+'</span><button class="pl-btn" id="pls">Compartilhar</button></div>'+
      ((loading||t)?'<div class="pl-row"><span>Agente:</span>'+agent+'</div>':"")+
      '</section>';
    return out;
  };
  var vPar=function(){
    if(st.games===undefined)return Ee(4);
    var g=st.games;
    if(!g||!g.length)return'<p class="empty">Partidas deste jogador indisponíveis na fonte de dados.</p>';
    var map={W:"V",L:"D",D:"E",T:"E"};
    return'<div class="cards">'+g.slice(0,30).map(function(r){
      var m=r.m,opp=m.opponent||{},res=map[String(m.gameResult||"").toUpperCase()]||"",
        sc=(m.homeTeamScore!=null&&m.awayTeamScore!=null)?m.homeTeamScore+"-"+m.awayTeamScore:"",
        ix=function(n){return r.labels.indexOf(n)},
        parts=[["G","Gols"],["A","Assist."],["YC","Amarelos"],["RC","Vermelhos"]].map(function(p){var i=ix(p[0]);return i>=0&&r.stats[i]!=null&&Number(r.stats[i])>0?p[1]+" "+r.stats[i]:""}).filter(Boolean).join(" · "),
        dt=m.gameDate?new Intl.DateTimeFormat(DBZ_I18N.locale,{day:"2-digit",month:"short",timeZone:"UTC"}).format(new Date(m.gameDate)):"";
      var inner='<div class="mbody"><p class="kicker">'+h((m.leagueAbbreviation||m.leagueName||"")+(dt?" · "+dt:""))+'</p><div class="side">'+(opp.logo?D(opp.logo,opp.displayName||"",22):"")+'<span class="tname">'+h((m.atVs||"vs")+" "+(opp.displayName||opp.abbreviation||"Adversário"))+'</span></div>'+(parts?'<p class="tm-note" style="margin:0">'+h(parts)+'</p>':"")+'</div><div class="mmeta">'+(res?'<span class="pill '+res+'" style="width:64px">'+h(sc||res)+'</span>':'<span class="muted-lab">'+h(sc)+'</span>')+'</div>';
      return lgSlug!=="all"&&r.id?'<a class="mcard" href="#/jogo/'+h(lgSlug)+'/'+h(r.id)+'">'+inner+'</a>':'<div class="mcard">'+inner+'</div>';
    }).join("")+'</div>';
  };
  var noStats='<p class="empty">Estatísticas deste jogador indisponíveis na fonte de dados.</p>';
  var vCar=function(){
    if(st.stats===undefined)return Ee(4);
    var cats=st.stats?plRows(st.stats):[];
    cats=cats.filter(function(c){return c.rows.length});
    if(!cats.length)return noStats;
    return cats.map(function(c){
      return'<section class="tm-card"><h3 class="tm-h">'+h(c.name||"Carreira")+'</h3><div class="table-wrap"><table class="stand tm-stand"><thead><tr><th>Temporada</th>'+c.disp.map(function(l){return'<th>'+h(l)+'</th>'}).join("")+'</tr></thead><tbody>'+c.rows.map(function(r){return'<tr><td><b>'+h(r.season)+'</b></td>'+c.disp.map(function(_l,i){return'<td>'+h(r.vals[i]!=null?r.vals[i]:"—")+'</td>'}).join("")+'</tr>'}).join("")+'</tbody></table></div></section>';
    }).join("");
  };
  var vTem=function(){
    if(st.stats===undefined)return Ee(4);
    var cats=st.stats?plRows(st.stats):[];
    if(!cats.length)return noStats;
    return cats.map(function(c){
      var vals=c.totals.length&&!c.rows.length?c.totals:(c.rows.length?c.rows[0].vals:c.totals);
      var season=c.rows.length?c.rows[0].season:"";
      return'<section class="tm-card"><h3 class="tm-h">'+h((c.name||"Temporada")+(season?" · "+season:""))+'</h3>'+c.disp.map(function(l,i){return vals[i]!=null?'<div class="tm-line"><span>'+h(l)+'</span><b>'+h(vals[i])+'</b></div>':""}).join("")+'</section>';
    }).join("");
  };
  var panel=S("#panel");
  var draw=function(){
    var f={detalhes:vDet,partidas:vPar,carreira:vCar,temporada:vTem}[st.tab]||vDet;
    try{panel.innerHTML=f()}catch(x){panel.innerHTML='<p class="empty">Não foi possível montar esta aba.</p>'}
  };
  var loadStats=async function(){
    if(st.stats!==undefined)return;
    var urls=[];
    bases.forEach(function(b){urls.push(b+"/stats");urls.push(b+"/overview")});
    st.stats=await plFirst(urls,"stats");
  };
  var loadGames=async function(){
    if(st.games!==undefined)return;
    var d=await plFirst(bases.map(function(b){return b+"/gamelog"}),"stats");
    try{st.games=d?plGames(d):null}catch(x){st.games=null}
  };
  var applyTf=function(){
    var t=tfOk();
    /* a foto do jogador vem da API-Football (afpApply); o Transfermarkt não troca mais a foto, pois podia achar um homônimo */
    if(st.tab==="detalhes")draw();
  };
  var loadTf=async function(force){
    var c=TFC[id];
    if(c&&c.data&&!force){st.tf=c.data;applyTf();if(Date.now()-c.ts<TF_TTL)return}
    else if(force||st.tf===undefined){st.tf=undefined;if(st.tab==="detalhes")draw()}
    var d=await tfLoad(a,!!force);
    if(d&&d.fail){if(!tfOk())st.tf=d}else st.tf=d;
    applyTf();
  };
  draw();
  loadTf(false);
  panel.addEventListener("click",function(ev){
    if(ev.target.closest("#tfretry")){ev.preventDefault();loadTf(true);return}
    if(!ev.target.closest("#pls"))return;
    var t=tfOk(),txt=a.name+(a.team?" · "+a.team:"")+(t&&t.value&&t.value.eur>0?" · "+DBZ_I18N.tr("Valor de mercado")+" "+tfFmtMoney(t.value)+" (Transfermarkt)":""),url=t?t.url:"https://www.espn.com.br/futebol/jogador/_/id/"+id;
    if(navigator.share){navigator.share({title:a.name,text:txt,url:url}).catch(function(){})}
    else if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt+" "+url).then(function(){var b=S("#pls");if(b){b.textContent="Link copiado";setTimeout(function(){b.textContent="Compartilhar"},1800)}}).catch(function(){})}
  });
  S("#pltabs").addEventListener("click",async function(ev){
    var b=ev.target.closest("button");if(!b||!b.dataset.t)return;
    S("#pltabs").querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
    b.classList.add("on");st.tab=b.dataset.t;draw();
    try{b.scrollIntoView({inline:"center",block:"nearest"})}catch(x){}
    var t=st.tab;
    if(t==="partidas"&&st.games===undefined){await loadGames();if(st.tab===t)draw()}
    else if((t==="carreira"||t==="temporada")&&st.stats===undefined){await loadStats();if(st.tab===t)draw()}
  });
}

/* clique em jogadores (elenco, artilheiros, escalação) abre a página do jogador */
document.addEventListener("click",function(ev){
  var el=ev.target.closest&&ev.target.closest("[data-pid]");
  if(!el)return;
  var d={};try{d=JSON.parse(el.getAttribute("data-pd")||"{}")}catch(x){}
  d.id=String(d.id||el.getAttribute("data-pid")||"");
  if(!d.id)return;
  plSeed(d);
  location.hash="#/jogador/"+(el.getAttribute("data-lg")||"all")+"/"+d.id;
});


/* ===== Conta: login com Google + favoritos na nuvem (Supabase) ===== */
var AU_URL="https://fsbedhkjjockdjgrhrjd.supabase.co",
    AU_KEY="sb_publishable_c98Pz8-_wDvdKlpA8X1AJg_IifrGN7e",
    AU_SK="dbzscore-auth",AU_KK="dbzscore-auth-keys",AU_DK="dbzscore-auth-dirty",AU_TS="dbzscore-auth-ts",
    auBusy=false,auMsg="",auPT=0,auPend={},auRefP=null,auLast=0;

function auEsc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
function auGet(){try{return JSON.parse(localStorage.getItem(AU_SK)||"null")}catch(e){return null}}
function auSet(s){try{if(s)localStorage.setItem(AU_SK,JSON.stringify(s));else localStorage.removeItem(AU_SK)}catch(e){}}
function auSession(r,old){
  var u=r.user||{},m=u.user_metadata||{},o=(old&&old.user)||{};
  return{access_token:r.access_token,refresh_token:r.refresh_token,
    expires_at:r.expires_at||Math.floor(Date.now()/1000)+(r.expires_in||3600),
    user:{id:u.id||o.id,email:u.email||m.email||o.email||"",name:m.full_name||m.name||o.name||"",avatar:m.avatar_url||m.picture||o.avatar||""}}
}

/* devolve uma sessao valida (renovando se preciso) ou null */
async function auToken(){
  var s=auGet();if(!s)return null;
  if(s.expires_at-60>Date.now()/1000)return s;
  if(auRefP)return auRefP;
  auRefP=(async function(){
    try{
      var r=await fetch(AU_URL+"/auth/v1/token?grant_type=refresh_token",{method:"POST",headers:{"apikey":AU_KEY,"Content-Type":"application/json"},body:JSON.stringify({refresh_token:s.refresh_token})});
      if(r.status===400||r.status===401||r.status===403){auSet(null);return null}
      if(!r.ok)return null;
      var j=await r.json(),n=auSession(j,s);
      if(!n.access_token)return null;
      auSet(n);return n
    }catch(e){return null}
  })();
  try{return await auRefP}finally{auRefP=null}
}

async function auRest(path,opt){
  var s=await auToken();if(!s)throw new Error("sem sessao");
  opt=opt||{};
  var h=Object.assign({"apikey":AU_KEY,"Authorization":"Bearer "+s.access_token},opt.headers||{});
  var r=await fetch(AU_URL+"/rest/v1/"+path,{method:opt.method||"GET",headers:h,body:opt.body});
  var tx="";try{tx=await r.text()}catch(e){}
  if(!r.ok)throw new Error("HTTP "+r.status+" "+tx.slice(0,160));
  return tx?JSON.parse(tx):null
}

/* favoritos locais <-> linhas da tabela */
function auRows(f){
  var o=[];
  (f.leagues||[]).forEach(function(l){o.push({tipo:"league",item_id:String(l),dados:null})});
  (f.teams||[]).forEach(function(t){o.push({tipo:"team",item_id:t.league+":"+t.id,dados:t})});
  (f.players||[]).forEach(function(p){o.push({tipo:"player",item_id:String(p.id),dados:p})});
  return o
}
function auKey(r){return r.tipo+"|"+r.item_id}
function auFromRows(rows,base){
  var f=Object.assign({},base||{});f.leagues=[];f.teams=[];f.players=[];
  rows.forEach(function(r){
    if(r.tipo==="league")f.leagues.push(r.item_id);
    else if(r.tipo==="team"&&r.dados)f.teams.push(r.dados);
    else if(r.tipo==="player"&&r.dados)f.players.push(r.dados)
  });
  return f
}
function auSetLocal(f){
  try{localStorage.setItem("dbzscore-favs",JSON.stringify(f))}catch(e){}
  try{fxSync()}catch(e){}
}
async function auUpsert(rows){
  var s=auGet(),uid=s&&s.user&&s.user.id;
  if(!uid)throw new Error("sem usuario");
  for(var i=0;i<rows.length;i+=200){
    var part=rows.slice(i,i+200).map(function(r){return{user_id:uid,tipo:r.tipo,item_id:r.item_id,dados:r.dados==null?null:r.dados}});
    await auRest("favoritos?on_conflict=user_id,tipo,item_id",{method:"POST",headers:{"Content-Type":"application/json","Prefer":"resolution=merge-duplicates,return=minimal"},body:JSON.stringify(part)})
  }
}

/* nuvem -> aparelho. mode "merge" (primeiro login: junta) ou "replace" (nuvem manda) */
async function auPull(mode){
  var cloud=await auRest("favoritos?select=tipo,item_id,dados&limit=5000");
  cloud=Array.isArray(cloud)?cloud:[];
  var local=U(),map={},order=[],novos=[];
  cloud.forEach(function(r){var k=auKey(r);if(!map[k]){map[k]=r;order.push(k)}});
  if(mode==="merge"||!cloud.length){
    auRows(local).forEach(function(r){var k=auKey(r);if(!map[k]){map[k]=r;order.push(k);novos.push(r)}})
  }
  var rows=order.map(function(k){return map[k]}),f=auFromRows(rows,local);
  var changed=JSON.stringify(f)!==JSON.stringify(local);
  if(novos.length)await auUpsert(novos);
  if(changed)auSetLocal(f);
  try{localStorage.setItem(AU_KK,JSON.stringify(order));localStorage.removeItem(AU_DK);localStorage.setItem(AU_TS,String(Date.now()))}catch(e){}
  return changed
}

/* aparelho -> nuvem (chamado a cada mudanca em favoritos) */
function auPush(){
  if(!auGet())return;
  try{localStorage.setItem(AU_DK,"1")}catch(e){}
  clearTimeout(auPT);auPT=setTimeout(auPushNow,1500)
}
async function auPushNow(){
  if(!auGet())return;
  try{
    var rows=auRows(U()),keys=rows.map(auKey),old=[];
    try{old=JSON.parse(localStorage.getItem(AU_KK)||"[]")}catch(e){}
    var gone=old.filter(function(k){return keys.indexOf(k)<0});
    await auUpsert(rows);
    for(var i=0;i<gone.length;i++){
      var ix=gone[i].indexOf("|");
      await auRest("favoritos?tipo=eq."+encodeURIComponent(gone[i].slice(0,ix))+"&item_id=eq."+encodeURIComponent(gone[i].slice(ix+1)),{method:"DELETE"})
    }
    localStorage.setItem(AU_KK,JSON.stringify(keys));localStorage.removeItem(AU_DK);localStorage.setItem(AU_TS,String(Date.now()));
    if(auMsg){auMsg=""}
  }catch(e){auMsg="Não foi possível sincronizar agora. Tentaremos de novo."}
  auRefresh()
}

/* abrir o app / voltar para ele: se nada pendente, a nuvem manda */
async function auStart(){
  if(!auGet()||auBusy)return;
  if(Date.now()-auLast<60000)return;
  auLast=Date.now();
  try{
    if(localStorage.getItem(AU_DK)){await auPushNow();return}
    if(await auPull("replace")){try{H()}catch(e){}}
    if(auMsg){auMsg="";auRefresh()}
  }catch(e){}
}

/* login */
function auRand(n){var a=new Uint8Array(n||16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return("0"+x.toString(16)).slice(-2)}).join("")}
function auSignIn(){
  if(auBusy)return;
  if(!window.AndroidAuth){auMsg="O login com Google funciona no app Android.";auRefresh();return}
  auBusy=true;auMsg="";auRefresh();
  var id=auRand(8),nonce=auRand(16),changed=false;
  new Promise(function(res){
    auPend[id]=res;
    setTimeout(function(){if(auPend[id]){delete auPend[id];res({error:"Tempo esgotado"})}},120000);
    try{window.AndroidAuth.signIn(id,nonce)}catch(e){delete auPend[id];res({error:"Login indisponível neste aparelho"})}
  }).then(async function(r){
    if(r.error){if(r.error!=="cancelado")auMsg=r.error;return}
    var x=await fetch(AU_URL+"/auth/v1/token?grant_type=id_token",{method:"POST",headers:{"apikey":AU_KEY,"Content-Type":"application/json"},body:JSON.stringify({provider:"google",id_token:r.idToken,nonce:nonce})});
    var j={};try{j=await x.json()}catch(e){}
    if(!x.ok||!j.access_token){auMsg="O Supabase recusou o login: "+(j.msg||j.error_description||j.error||x.status);return}
    auSet(auSession(j));
    try{changed=await auPull("merge")}catch(e){auMsg="Login feito, mas a sincronização falhou: "+e.message}
  }).catch(function(e){auMsg="Falha no login: "+(e&&e.message||e)}).then(function(){
    auBusy=false;auLast=Date.now();auRefresh();
    if(changed){try{H()}catch(e){}}
  })
}
window.__auNative=function(id,json){
  var f=auPend[id];if(!f)return;delete auPend[id];
  var o={};try{o=JSON.parse(json)}catch(e){o={error:"Resposta inválida"}}
  f(o)
};
function auSignOut(){
  var s=auGet();auSet(null);
  try{localStorage.removeItem(AU_KK);localStorage.removeItem(AU_DK);localStorage.removeItem(AU_TS)}catch(e){}
  if(s)fetch(AU_URL+"/auth/v1/logout",{method:"POST",headers:{"apikey":AU_KEY,"Authorization":"Bearer "+s.access_token}}).catch(function(){});
  auMsg="";auRefresh()
}

/* sincronizar agora (botao da pagina Conta) */
async function auSyncNow(){
  if(auBusy||!auGet())return;
  auBusy=true;auMsg="";auRefresh();
  var changed=false;
  try{
    if(localStorage.getItem(AU_DK)){await auPushNow()}
    else{changed=await auPull("replace")}
    auLast=Date.now()
  }catch(e){auMsg="N\u00e3o foi poss\u00edvel sincronizar agora."}
  auBusy=false;auRefresh();
  if(changed){try{H()}catch(e){}}
}

/* tela */
function auIco(){return'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>'}
function auTopInner(){var s=auGet(),u=s&&s.user;return u&&u.avatar?'<img class="auav" src="'+auEsc(u.avatar)+'" alt="" referrerpolicy="no-referrer">':auIco()}
function auTopBtn(){return'<a class="bell-btn" id="autop" href="#/conta" aria-label="Conta">'+auTopInner()+'</a>'}
function auStamp(){var t=+localStorage.getItem(AU_TS)||0;if(!t)return"";var d=new Date(t);return d.toLocaleDateString(DBZ_I18N.locale)+" "+DBZ_I18N.tr("às")+" "+d.toLocaleTimeString(DBZ_I18N.locale,{hour:"2-digit",minute:"2-digit"})}
function auCount(){try{var f=U();return(f.leagues||[]).length+" ligas \u00b7 "+(f.teams||[]).length+" times \u00b7 "+(f.players||[]).length+" jogadores"}catch(e){return""}}
function auHtml(){
  var s=auGet(),t="";
  if(s){
    var u=s.user||{},st=auStamp();
    t+='<div class="aur"><span class="aua big">'+(u.avatar?'<img src="'+auEsc(u.avatar)+'" alt="" referrerpolicy="no-referrer">':"")+'</span><span class="aut"><b>'+auEsc(u.name||"Conectado")+'</b><small>'+auEsc(u.email||"")+'</small></span></div>'
     +'<h2 class="sec">Favoritos na nuvem</h2>'
     +'<p class="empty aust">'+auEsc(auCount())+(st?'<br>\u00daltima sincroniza\u00e7\u00e3o: '+auEsc(st):"")+'</p>'
     +'<div class="aub"><button type="button" class="aubtn pri" data-au="sync"'+(auBusy?" disabled":"")+'>'+(auBusy?"Sincronizando\u2026":"Sincronizar agora")+'</button> <button type="button" class="aubtn" data-au="out">Sair da conta</button></div>'
     +'<p class="empty">Seus favoritos s\u00e3o salvos automaticamente e aparecem em qualquer aparelho em que voc\u00ea entrar com esta conta.</p>'
  }else{
    t+='<h2 class="sec">Entrar</h2>'
     +'<p class="empty">Entre com sua conta Google para guardar seus favoritos (ligas, times e jogadores) na nuvem e us\u00e1-los em outros aparelhos.</p>'
     +'<div class="aub"><button type="button" class="aubtn pri" data-au="in"'+(auBusy?" disabled":"")+'>'+(auBusy?"Abrindo\u2026":"Entrar com Google")+'</button></div>'
     +'<p class="empty">Sem entrar, tudo continua funcionando e os favoritos ficam s\u00f3 neste aparelho.</p>'
  }
  if(auMsg)t+='<p class="empty aumsg">'+auEsc(auMsg)+'</p>';
  return t
}
function auRefresh(){
  var el=document.getElementById("aupanel");if(el)el.innerHTML=auHtml();
  var tb=document.getElementById("autop");if(tb)tb.innerHTML=auTopInner()
}
function auPage(){
  M.innerHTML=R("conta",'<section class="hud-panel hero"><p class="tag">Sua conta</p><h1 class="display">Conta</h1></section><section class="hud-panel" id="aupanel">'+auHtml()+'</section>')
}
document.addEventListener("click",function(ev){
  var b=ev.target&&ev.target.closest&&ev.target.closest("[data-au]");if(!b)return;
  ev.preventDefault();
  if(b.dataset.au==="in")auSignIn();else if(b.dataset.au==="out")auSignOut();else if(b.dataset.au==="sync")auSyncNow()
});
(function(){
  var st=document.createElement("style");
  st.textContent=".aur{display:flex;align-items:center;gap:12px;padding:6px 0}.aua{width:44px;height:44px;border-radius:50%;overflow:hidden;background:var(--card-lo);border:1px solid var(--border);flex:none;display:inline-block}.aua.big{width:64px;height:64px}.top-actions .auav{width:26px;height:26px;border-radius:50%;object-fit:cover;display:block}.aust{padding:4px 0 8px}.aua img{width:100%;height:100%;object-fit:cover;display:block}.aut{display:flex;flex-direction:column;min-width:0}.aut b{font-size:16px}.aut small{color:var(--muted);overflow:hidden;text-overflow:ellipsis}.aub{margin-top:10px}.aubtn{font:inherit;font-weight:700;padding:10px 16px;border-radius:12px 4px 12px 4px;border:1px solid var(--border);background:var(--card);color:var(--fg)}.aubtn.pri{background:var(--ember);color:var(--accent-fg);border-color:transparent}.aubtn[disabled]{opacity:.6}.aumsg{color:var(--live)}";
  document.head.appendChild(st)
})();
setTimeout(auStart,1500);
document.addEventListener("visibilitychange",function(){if(document.visibilityState==="visible")auStart()});

})();
